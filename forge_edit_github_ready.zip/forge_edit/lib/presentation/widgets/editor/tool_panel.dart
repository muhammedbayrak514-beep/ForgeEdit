import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;

import '../../../core/theme/app_theme.dart';
import '../../../data/services/audio_import_service.dart';
import '../../providers/editor_provider.dart';
import '../../providers/project_list_provider.dart';
import '../../screens/editor/media_picker_screen.dart';
import 'effects_sheet.dart';

class ToolPanel extends ConsumerWidget {
  final String projectId;

  const ToolPanel({super.key, required this.projectId});

  Future<void> _openMediaPicker(BuildContext context) async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => MediaPickerScreen(projectId: projectId),
        fullscreenDialog: true,
      ),
    );
  }

  Future<void> _addText(BuildContext context, WidgetRef ref) async {
    final controller = TextEditingController(text: 'Metin');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Metin ekle'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'Metin içeriği'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('İptal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Ekle'),
          ),
        ],
      ),
    );
    if (result == null || result.isEmpty) return;
    await ref.read(editorProvider(projectId).notifier).addTextClip(
          content: result,
          durationMs: 3000,
        );
  }

  Future<void> _addAudio(BuildContext context, WidgetRef ref) async {
    try {
      final pick = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: AudioImportService.supportedAudio,
        allowMultiple: false,
      );
      if (pick == null || pick.files.isEmpty) return;
      final file = pick.files.single;
      final path = file.path;
      if (path == null) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Dosya yolu alınamadı')),
          );
        }
        return;
      }

      final service = AudioImportService(ref.read(projectRepositoryProvider));
      final project = ref.read(editorProvider(projectId)).value;
      final start = project?.durationMs ?? 0;

      final clip = await service.importAudioFile(
        projectId: projectId,
        sourcePath: path,
        displayName: file.name.isNotEmpty ? file.name : p.basename(path),
        timelineStartMs: start,
      );
      if (clip == null) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Ses dosyası eklenemedi')),
          );
        }
        return;
      }
      await ref.read(editorProvider(projectId).notifier).addAudioClip(clip);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ses eklendi: ${clip.displayName}')),
        );
      }
    } on FormatException catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message), backgroundColor: AppTheme.danger),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ses seçilemedi: $e'),
            backgroundColor: AppTheme.danger,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(left: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Araçlar',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8),
              children: [
                _ToolTile(
                  icon: Icons.video_library_outlined,
                  label: 'Medya',
                  subtitle: 'Video / Fotoğraf',
                  enabled: true,
                  onTap: () => _openMediaPicker(context),
                ),
                _ToolTile(
                  icon: Icons.music_note_outlined,
                  label: 'Ses',
                  subtitle: 'Ses dosyası ekle',
                  enabled: true,
                  onTap: () => _addAudio(context, ref),
                ),
                _ToolTile(
                  icon: Icons.text_fields,
                  label: 'Metin',
                  subtitle: 'Yazı ekle',
                  enabled: true,
                  onTap: () => _addText(context, ref),
                ),
                _ToolTile(
                  icon: Icons.auto_awesome,
                  label: 'Efekt / Filtre',
                  subtitle: 'Filtre ve geçiş',
                  enabled: true,
                  onTap: () => EffectsSheet.open(context, projectId),
                ),
                _ToolTile(
                  icon: Icons.transition,
                  label: 'Geçiş',
                  subtitle: 'Sonraki klibe',
                  enabled: true,
                  onTap: () => EffectsSheet.open(context, projectId),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ToolTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final bool enabled;
  final VoidCallback? onTap;

  const _ToolTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      enabled: enabled,
      leading: Icon(
        icon,
        color: enabled ? AppTheme.primary : AppTheme.textSecondary,
      ),
      title: Text(
        label,
        style: TextStyle(
          color: enabled ? AppTheme.textPrimary : AppTheme.textSecondary,
          fontWeight: FontWeight.w500,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
      ),
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }
}
