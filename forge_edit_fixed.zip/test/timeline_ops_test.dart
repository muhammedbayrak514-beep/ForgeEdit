import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/domain/models/clip_model.dart';
import 'package:forge_edit/domain/models/project_model.dart';
import 'package:forge_edit/domain/timeline_ops.dart';

ClipModel _video({
  required String id,
  required int sourceMs,
  int trimStart = 0,
  int? trimEnd,
  int timelineStart = 0,
  String name = 'v',
}) {
  final end = trimEnd ?? sourceMs;
  return ClipModel(
    id: id,
    type: ClipType.video,
    filePath: '/tmp/$id.mp4',
    displayName: name,
    sourceDurationMs: sourceMs,
    trimStartMs: trimStart,
    trimEndMs: end,
    timelineStartMs: timelineStart,
    trackIndex: 0,
  );
}

void main() {
  group('TimelineOps.packMainTrack', () {
    test('closes gaps and preserves order', () {
      final p = ProjectModel.create(name: 't').copyWith(
        clips: [
          _video(id: 'a', sourceMs: 5000, timelineStart: 0),
          _video(id: 'b', sourceMs: 3000, timelineStart: 8000), // gap
        ],
      );
      final packed = TimelineOps.packMainTrack(p);
      expect(packed.clips[0].timelineStartMs, 0);
      expect(packed.clips[1].timelineStartMs, 5000);
      expect(packed.durationMs, 8000);
    });
  });

  group('TimelineOps.trimClip', () {
    test('updates trim and repacks duration', () {
      final a = _video(id: 'a', sourceMs: 10000);
      final b = _video(id: 'b', sourceMs: 4000, timelineStart: 10000);
      final p = ProjectModel.create().copyWith(clips: [a, b]);

      final next = TimelineOps.trimClip(
        project: p,
        clipId: 'a',
        newTrimStartMs: 1000,
        newTrimEndMs: 6000,
      );
      final a2 = next.clips.firstWhere((c) => c.id == 'a');
      expect(a2.trimStartMs, 1000);
      expect(a2.trimEndMs, 6000);
      expect(a2.durationMs, 5000);
      final b2 = next.clips.firstWhere((c) => c.id == 'b');
      expect(b2.timelineStartMs, 5000); // closed gap after shorter a
      expect(next.durationMs, 9000);
    });

    test('enforces minimum duration', () {
      final a = _video(id: 'a', sourceMs: 5000);
      final p = ProjectModel.create().copyWith(clips: [a]);
      final next = TimelineOps.trimClip(
        project: p,
        clipId: 'a',
        newTrimStartMs: 2000,
        newTrimEndMs: 2050, // < 100ms
      );
      final a2 = next.clips.first;
      expect(a2.durationMs >= TimelineOps.minTrimDurationMs, isTrue);
    });
  });

  group('TimelineOps.splitClip', () {
    test('splits in middle into two clips with correct trims', () {
      final a = _video(id: 'a', sourceMs: 10000, name: 'clip');
      final p = ProjectModel.create().copyWith(clips: [a]);
      // Split at 4000ms project time
      final next = TimelineOps.splitClip(
        project: p,
        clipId: 'a',
        projectTimeMs: 4000,
      );
      expect(next, isNotNull);
      expect(next!.clips.length, 2);
      final left = next.clips.firstWhere((c) => c.id == 'a');
      final right = next.clips.firstWhere((c) => c.id != 'a');
      expect(left.trimStartMs, 0);
      expect(left.trimEndMs, 4000);
      expect(left.durationMs, 4000);
      expect(right.trimStartMs, 4000);
      expect(right.trimEndMs, 10000);
      expect(right.durationMs, 6000);
      expect(right.filePath, left.filePath);
      expect(next.durationMs, 10000); // total unchanged
    });

    test('rejects split at edges', () {
      final a = _video(id: 'a', sourceMs: 5000);
      final p = ProjectModel.create().copyWith(clips: [a]);
      expect(
        TimelineOps.splitClip(project: p, clipId: 'a', projectTimeMs: 0),
        isNull,
      );
      expect(
        TimelineOps.splitClip(project: p, clipId: 'a', projectTimeMs: 5000),
        isNull,
      );
      expect(
        TimelineOps.splitClip(project: p, clipId: 'a', projectTimeMs: 50),
        isNull,
      ); // too close to start
    });
  });

  group('TimelineOps.deleteClip', () {
    test('removes and closes gap', () {
      final clips = [
        _video(id: 'a', sourceMs: 3000),
        _video(id: 'b', sourceMs: 4000, timelineStart: 3000),
        _video(id: 'c', sourceMs: 2000, timelineStart: 7000),
      ];
      final p = ProjectModel.create().copyWith(clips: clips);
      final next = TimelineOps.deleteClip(project: p, clipId: 'b');
      expect(next.clips.length, 2);
      expect(next.clips.map((c) => c.id).toList(), ['a', 'c']);
      expect(next.clips[1].timelineStartMs, 3000);
      expect(next.durationMs, 5000);
    });
  });

  group('TimelineOps.moveClip', () {
    test('moves right and left on main track', () {
      final clips = [
        _video(id: 'a', sourceMs: 1000),
        _video(id: 'b', sourceMs: 2000, timelineStart: 1000),
        _video(id: 'c', sourceMs: 3000, timelineStart: 3000),
      ];
      final p = ProjectModel.create().copyWith(clips: clips);
      final right = TimelineOps.moveClip(
        project: p,
        clipId: 'a',
        direction: 1,
      );
      expect(right.clips.map((c) => c.id).toList(), ['b', 'a', 'c']);
      expect(right.clips[0].timelineStartMs, 0);
      expect(right.clips[1].timelineStartMs, 2000);
      expect(right.clips[2].timelineStartMs, 3000);

      final left = TimelineOps.moveClip(
        project: right,
        clipId: 'a',
        direction: -1,
      );
      expect(left.clips.map((c) => c.id).toList(), ['a', 'b', 'c']);
    });

    test('no-op at boundaries', () {
      final clips = [
        _video(id: 'a', sourceMs: 1000),
        _video(id: 'b', sourceMs: 1000, timelineStart: 1000),
      ];
      final p = ProjectModel.create().copyWith(clips: clips);
      final same = TimelineOps.moveClip(project: p, clipId: 'a', direction: -1);
      expect(same.clips.map((c) => c.id).toList(), ['a', 'b']);
    });
  });

  test('reorderMainTrack moves clip index and repacks', () {
    final p = ProjectModel.create(name: 'r').copyWith(
      clips: [
        _video(id: 'a', sourceMs: 1000, timelineStart: 0, name: 'a'),
        _video(id: 'b', sourceMs: 2000, timelineStart: 1000, name: 'b'),
        _video(id: 'c', sourceMs: 1000, timelineStart: 3000, name: 'c'),
      ],
    );
    final next = TimelineOps.reorderMainTrack(
      project: p,
      clipId: 'c',
      newIndex: 0,
    );
    final main = TimelineOps.mainTrackClips(next);
    expect(main.map((e) => e.displayName).toList(), ['c', 'a', 'b']);
    expect(main[0].timelineStartMs, 0);
    expect(main[1].timelineStartMs, 1000);
    expect(main[2].timelineStartMs, 2000);
  });
}

  test('setClipTimelineStart moves audio without packing video', () {
    final v = _video(id: 'v', sourceMs: 3000, timelineStart: 0);
    final a = ClipModel(
      id: 'a',
      type: ClipType.audio,
      filePath: '/a.mp3',
      displayName: 'a',
      sourceDurationMs: 5000,
      trimEndMs: 5000,
      timelineStartMs: 0,
      trackIndex: TrackIndex.audio,
    );
    var p = ProjectModel.create().copyWith(clips: [v, a]);
    p = TimelineOps.setClipTimelineStart(
      project: p,
      clipId: 'a',
      timelineStartMs: 1500,
    );
    final audio = p.clips.firstWhere((c) => c.id == 'a');
    expect(audio.timelineStartMs, 1500);
    expect(p.clips.firstWhere((c) => c.id == 'v').timelineStartMs, 0);
  });
