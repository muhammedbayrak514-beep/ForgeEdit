/// Catalog of filters / transitions supported in the *data model*.
/// Preview applies a subset via ColorFilter; full export is Stage 9 (FFmpeg).

enum FilterId {
  none,
  grayscale,
  sepia,
  warm,
  cool,
  highContrast,
  muted,
}

enum TransitionId {
  none,
  crossfade,
  fadeBlack,
  /// Not implemented in export yet – stored but flagged in UI
  wipeLeft,
}

class FilterDef {
  final FilterId id;
  final String label;
  final String description;
  /// Whether ColorFiltered preview can approximate it.
  final bool previewSupported;

  const FilterDef({
    required this.id,
    required this.label,
    required this.description,
    this.previewSupported = true,
  });
}

class TransitionDef {
  final TransitionId id;
  final String label;
  final String description;
  final bool exportReady;

  const TransitionDef({
    required this.id,
    required this.label,
    required this.description,
    this.exportReady = false,
  });
}

class EffectCatalog {
  static const filters = <FilterDef>[
    FilterDef(id: FilterId.none, label: 'Yok', description: 'Filtre yok'),
    FilterDef(
      id: FilterId.grayscale,
      label: 'Siyah-beyaz',
      description: 'Gri tonlama',
    ),
    FilterDef(
      id: FilterId.sepia,
      label: 'Sepya',
      description: 'Sıcak kahverengi ton',
    ),
    FilterDef(
      id: FilterId.warm,
      label: 'Sıcak',
      description: 'Turuncu vurgu',
    ),
    FilterDef(
      id: FilterId.cool,
      label: 'Soğuk',
      description: 'Mavi vurgu',
    ),
    FilterDef(
      id: FilterId.highContrast,
      label: 'Kontrast',
      description: 'Yüksek kontrast',
    ),
    FilterDef(
      id: FilterId.muted,
      label: 'Soluk',
      description: 'Düşük doygunluk',
    ),
  ];

  static const transitions = <TransitionDef>[
    TransitionDef(
      id: TransitionId.none,
      label: 'Yok',
      description: 'Kesme geçiş',
      exportReady: true,
    ),
    TransitionDef(
      id: TransitionId.crossfade,
      label: 'Çapraz geçiş',
      description: 'İki klip arasında dissolve',
      exportReady: false, // Stage 9
    ),
    TransitionDef(
      id: TransitionId.fadeBlack,
      label: 'Siyaha sol',
      description: 'Siyah üzerinden geçiş',
      exportReady: false,
    ),
    TransitionDef(
      id: TransitionId.wipeLeft,
      label: 'Sola sil',
      description: 'Henüz desteklenmiyor (export)',
      exportReady: false,
    ),
  ];

  static FilterDef filterById(FilterId id) =>
      filters.firstWhere((f) => f.id == id, orElse: () => filters.first);

  static TransitionDef transitionById(TransitionId id) =>
      transitions.firstWhere((t) => t.id == id, orElse: () => transitions.first);
}
