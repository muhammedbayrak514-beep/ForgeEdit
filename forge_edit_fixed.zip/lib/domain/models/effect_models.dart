/// Catalog of filters / transitions (preview + export).

enum FilterId {
  none,
  grayscale,
  sepia,
  warm,
  cool,
  highContrast,
  muted,
  vivid,
  vintage,
  bright,
  noir,
  fade,
}

enum TransitionId {
  none,
  crossfade,
  fadeBlack,
  wipeLeft,
}

class FilterDef {
  final FilterId id;
  final String label;
  final String description;
  final bool previewSupported;

  const FilterDef({
    required this.id,
    required this.label,
    required this.description,
    this.previewSupported = true,
  });
}

class TransitionDef {
  final TransitionId id;
  final String label;
  final String description;
  final bool exportReady;

  const TransitionDef({
    required this.id,
    required this.label,
    required this.description,
    this.exportReady = false,
  });
}

class EffectCatalog {
  static const filters = <FilterDef>[
    FilterDef(id: FilterId.none, label: 'Yok', description: 'Filtre yok'),
    FilterDef(id: FilterId.grayscale, label: 'Siyah-beyaz', description: 'Gri tonlama'),
    FilterDef(id: FilterId.sepia, label: 'Sepya', description: 'Sıcak kahverengi'),
    FilterDef(id: FilterId.warm, label: 'Sıcak', description: 'Turuncu vurgu'),
    FilterDef(id: FilterId.cool, label: 'Soğuk', description: 'Mavi vurgu'),
    FilterDef(id: FilterId.highContrast, label: 'Kontrast', description: 'Yüksek kontrast'),
    FilterDef(id: FilterId.muted, label: 'Soluk', description: 'Düşük doygunluk'),
    FilterDef(id: FilterId.vivid, label: 'Canlı', description: 'Yüksek doygunluk'),
    FilterDef(id: FilterId.vintage, label: 'Vintage', description: 'Eski film hissi'),
    FilterDef(id: FilterId.bright, label: 'Parlak', description: 'Aydınlık'),
    FilterDef(id: FilterId.noir, label: 'Noir', description: 'Koyu siyah-beyaz'),
    FilterDef(id: FilterId.fade, label: 'Solgun', description: 'Yumuşak soluk'),
  ];

  static const transitions = <TransitionDef>[
    TransitionDef(
      id: TransitionId.none,
      label: 'Kesme',
      description: 'Anında geçiş',
      exportReady: true,
    ),
    TransitionDef(
      id: TransitionId.crossfade,
      label: 'Çapraz geçiş',
      description: 'Dissolve',
      exportReady: true,
    ),
    TransitionDef(
      id: TransitionId.fadeBlack,
      label: 'Siyaha sol',
      description: 'Siyah üzerinden',
      exportReady: true,
    ),
    TransitionDef(
      id: TransitionId.wipeLeft,
      label: 'Sola sil',
      description: 'Soldan sağa silme',
      exportReady: true,
    ),
  ];

  static FilterDef filterById(FilterId id) =>
      filters.firstWhere((f) => f.id == id, orElse: () => filters.first);

  static TransitionDef transitionById(TransitionId id) =>
      transitions.firstWhere((t) => t.id == id, orElse: () => transitions.first);

  static FilterDef filterByName(String name) {
    final id = FilterId.values.asNameMap()[name] ?? FilterId.none;
    return filterById(id);
  }

  static TransitionDef transitionByName(String name) {
    final id = TransitionId.values.asNameMap()[name] ?? TransitionId.none;
    return transitionById(id);
  }
}
