import 'dart:io';

import '../models/clip_model.dart';
import '../models/project_model.dart';
import 'export_filter_map.dart';

class ExportSettings {
  final int width;
  final int height;
  final int fps;
  /// 'h264' software libx264 (GPL full kit)
  final String videoCodec;

  const ExportSettings({
    this.width = 1280,
    this.height = 720,
    this.fps = 30,
    this.videoCodec = 'libx264',
  });
}

class ExportValidationIssue {
  final String message;
  const ExportValidationIssue(this.message);
}

class ExportPlan {
  final ProjectModel project;
  final ExportSettings settings;
  final List<ClipModel> videoTrack;
  final List<ClipModel> audioTrack;
  final List<ClipModel> textTrack;
  final List<ExportValidationIssue> issues;

  ExportPlan({
    required this.project,
    required this.settings,
    required this.videoTrack,
    required this.audioTrack,
    required this.textTrack,
    required this.issues,
  });

  bool get canExport =>
      issues.isEmpty && (videoTrack.isNotEmpty || textTrack.isNotEmpty);

  /// Build a pure plan + validate media files exist.
  static Future<ExportPlan> build(
    ProjectModel project, {
    ExportSettings settings = const ExportSettings(),
  }) async {
    final issues = <ExportValidationIssue>[];
    if (project.clips.isEmpty) {
      issues.add(const ExportValidationIssue('Proje boş — klip ekleyin'));
    }

    final video = project.clips
        .where((c) =>
            c.trackIndex == TrackIndex.video &&
            (c.type == ClipType.video || c.type == ClipType.image))
        .toList()
      ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));

    final audio = project.clips
        .where((c) => c.type == ClipType.audio)
        .toList()
      ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));

    final text = project.clips
        .where((c) => c.type == ClipType.text)
        .toList();

    for (final c in [...video, ...audio]) {
      if (c.filePath.isEmpty) {
        issues.add(ExportValidationIssue('Dosya yolu boş: ${c.displayName}'));
        continue;
      }
      final f = File(c.filePath);
      if (!await f.exists()) {
        issues.add(ExportValidationIssue(
          'Dosya bulunamadı: ${c.displayName}\n${c.filePath}',
        ));
      } else if (await f.length() == 0) {
        issues.add(ExportValidationIssue('Dosya boş: ${c.displayName}'));
      }
    }

    if (video.isEmpty && text.isEmpty) {
      issues.add(const ExportValidationIssue(
        'Dışa aktarılacak video veya metin klibi yok',
      ));
    }

    // Unsupported transitions — warn only, still export hard cuts
    for (final c in video) {
      if (c.transitionId != 'none' &&
          c.transitionId != 'crossfade' &&
          c.transitionId != 'fadeBlack') {
        issues.add(ExportValidationIssue(
          'Geçiş "${c.transitionId}" desteklenmiyor; kesme kullanılacak '
          '(${c.displayName})',
        ));
      }
    }
    // Treat unsupported transition as soft warning — remove from blocking
    // Only hard-fail on missing files / empty project
    final hard = issues
        .where((i) =>
            i.message.contains('bulunamadı') ||
            i.message.contains('boş') ||
            i.message.contains('Proje boş') ||
            i.message.contains('Dışa aktarılacak'))
        .toList();

    return ExportPlan(
      project: project,
      settings: settings,
      videoTrack: video,
      audioTrack: audio,
      textTrack: text,
      issues: hard.isNotEmpty ? hard : [],
    );
  }

  /// FFmpeg scale+pad to target size without stretching.
  String get scalePadVf =>
      'scale=${settings.width}:${settings.height}:force_original_aspect_ratio=decrease,'
      'pad=${settings.width}:${settings.height}:(ow-iw)/2:(oh-ih)/2';

  /// Timeline end = max of all clips' timelineEndMs (gaps included).
  int get timelineDurationMs {
    var maxEnd = 0;
    for (final c in [...videoTrack, ...audioTrack, ...textTrack]) {
      if (c.timelineEndMs > maxEnd) maxEnd = c.timelineEndMs;
    }
    return maxEnd;
  }

  /// Build per-clip intermediate commands.
  /// Video segments keep source audio (trimmed); image segments get silent aac
  /// so concat has a consistent A/V layout.
  List<String> buildSegmentCommands({
    required String workDir,
    required List<String> segmentPathsOut,
  }) {
    final cmds = <String>[];
    segmentPathsOut.clear();
    for (var i = 0; i < videoTrack.length; i++) {
      final c = videoTrack[i];
      final out = '$workDir/seg_$i.mp4';
      segmentPathsOut.add(out);

      final filters = <String>[scalePadVf];
      final color = ExportFilterMap.videoFilter(c.filterId, c.filterIntensity);
      if (color.isNotEmpty) filters.add(color);

      if (c.type == ClipType.image) {
        final durSec = (c.durationMs / 1000.0).clamp(0.1, 3600.0);
        final d = durSec.toStringAsFixed(3);
        final vf = filters.join(',');
        // Silent stereo track matching duration (no -an on final; consistent for concat)
        cmds.add(
          '-loop 1 -t $d -i "${c.filePath}" '
          '-f lavfi -t $d -i anullsrc=channel_layout=stereo:sample_rate=44100 '
          '-vf "$vf" -r ${settings.fps} '
          '-c:v ${settings.videoCodec} -pix_fmt yuv420p '
          '-c:a aac -b:a 128k -shortest -y "$out"',
        );
      } else {
        final ss = (c.trimStartMs / 1000.0).toStringAsFixed(3);
        final tSec = (c.durationMs / 1000.0).clamp(0.1, 3600.0);
        final tStr = tSec.toStringAsFixed(3);
        final speedFilter = c.speed != 1.0
            ? 'setpts=PTS/${c.speed.toStringAsFixed(3)}'
            : null;
        final fullVf = [
          if (speedFilter != null) speedFilter,
          ...filters,
        ].join(',');
        // Preserve source audio when present (-map 0:a?).
        // -ss/-t only on this input. ExportService ensures every segment
        // has an audio stream before concat (see ensureSegmentAudio).
        cmds.add(
          '-ss $ss -t $tStr -i "${c.filePath}" '
          '-vf "$fullVf" -r ${settings.fps} '
          '-map 0:v:0 -map 0:a? '
          '-c:v ${settings.videoCodec} -pix_fmt yuv420p '
          '-c:a aac -b:a 128k -ar 44100 -ac 2 '
          '-t $tStr -y "$out"',
        );
      }
    }
    return cmds;
  }

  String buildConcatListFile(List<String> segmentPaths) {
    final b = StringBuffer();
    for (final p in segmentPaths) {
      final escaped = p.replaceAll("'", r"'\''");
      b.writeln("file '$escaped'");
    }
    return b.toString();
  }

  /// Drawtext filters; [fontFile] must be path with ':' escaped for filtergraph.
  String? buildDrawtextFilter({String? fontFile}) {
    if (textTrack.isEmpty) return null;
    final parts = <String>[];
    for (final t in textTrack) {
      final start = (t.timelineStartMs / 1000.0).toStringAsFixed(3);
      final end = (t.timelineEndMs / 1000.0).toStringAsFixed(3);
      final text = t.textContent
          .replaceAll(r'\', r'\\')
          .replaceAll(':', r'\:')
          .replaceAll("'", r"\'")
          .replaceAll('%', r'\%');
      final x = (t.posX * settings.width).round();
      final y = (t.posY * settings.height).round();
      final fontSize = t.fontSize.round().clamp(12, 200);
      final argb = t.textColorArgb;
      final rgb =
          '#${((argb >> 16) & 0xFF).toRadixString(16).padLeft(2, '0')}'
          '${((argb >> 8) & 0xFF).toRadixString(16).padLeft(2, '0')}'
          '${(argb & 0xFF).toRadixString(16).padLeft(2, '0')}';
      final fontPart =
          (fontFile != null && fontFile.isNotEmpty) ? ":fontfile=$fontFile" : '';
      parts.add(
        "drawtext=text='$text':fontsize=$fontSize:fontcolor=$rgb:"
        "x=$x:y=$y$fontPart:enable='between(t\\,$start\\,$end)'",
      );
    }
    return parts.join(',');
  }

  static const supportedTransitionExport = {
    'none',
  };
}
