import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../core/constants/app_constants.dart';
import '../../domain/models/project_model.dart';

/// Handles reading/writing project JSON files and their media folders.
///
/// Layout:
///   documents/projects/{projectId}/
///     project.json
///     media/
///       {clipId}.mp4 / .jpg ...
class ProjectRepository {
  Future<Directory> _projectsRoot() async {
    final docs = await getApplicationDocumentsDirectory();
    final root = Directory(p.join(docs.path, AppConstants.projectsFolder));
    if (!await root.exists()) {
      await root.create(recursive: true);
    }
    return root;
  }

  Future<Directory> projectDir(String projectId) async {
    final root = await _projectsRoot();
    final dir = Directory(p.join(root.path, projectId));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  Future<Directory> mediaDir(String projectId) async {
    final proj = await projectDir(projectId);
    final media = Directory(p.join(proj.path, AppConstants.mediaFolder));
    if (!await media.exists()) {
      await media.create(recursive: true);
    }
    return media;
  }

  Future<File> _projectJsonFile(String projectId) async {
    final dir = await projectDir(projectId);
    return File(p.join(dir.path, 'project.json'));
  }

  Future<List<ProjectModel>> getAllProjects() async {
    final root = await _projectsRoot();
    final projects = <ProjectModel>[];

    await for (final entity in root.list()) {
      if (entity is Directory) {
        final jsonFile = File(p.join(entity.path, 'project.json'));
        if (await jsonFile.exists()) {
          try {
            final content = await jsonFile.readAsString();
            final map = jsonDecode(content) as Map<String, dynamic>;
            projects.add(ProjectModel.fromJson(map));
          } catch (_) {
            // Skip corrupted project folders – do not crash the whole list
          }
        }
      }
    }

    projects.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return projects;
  }

  Future<ProjectModel?> getProject(String id) async {
    final file = await _projectJsonFile(id);
    if (!await file.exists()) return null;
    try {
      final content = await file.readAsString();
      return ProjectModel.fromJson(
        jsonDecode(content) as Map<String, dynamic>,
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> saveProject(ProjectModel project) async {
    final file = await _projectJsonFile(project.id);
    final json = const JsonEncoder.withIndent('  ').convert(project.toJson());
    await file.writeAsString(json);
  }

  Future<void> deleteProject(String id) async {
    final dir = await projectDir(id);
    if (await dir.exists()) {
      await dir.delete(recursive: true);
    }
  }
}
