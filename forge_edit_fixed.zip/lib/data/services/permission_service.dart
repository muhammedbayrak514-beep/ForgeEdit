import 'package:permission_handler/permission_handler.dart';
import 'package:photo_manager/photo_manager.dart';

/// Centralized permission handling for media access.
class PermissionService {
  /// Request gallery / media library access via photo_manager.
  /// Returns true if we have enough access to list and pick media.
  static Future<PermissionState> requestPhotoAccess() async {
    final state = await PhotoManager.requestPermissionExtend();
    return state;
  }

  /// Whether we can proceed with media picking.
  static bool canAccessMedia(PermissionState state) {
    return state.isAuth || state.hasAccess;
  }

  /// Open system settings if user permanently denied.
  static Future<void> openSettings() async {
    await PhotoManager.openSetting();
  }

  /// Optional: also check permission_handler for storage on older Android.
  static Future<bool> ensureLegacyStorageIfNeeded() async {
    // On Android 13+ photo_manager handles READ_MEDIA_*.
    // On older versions we may still need storage.
    final status = await Permission.storage.status;
    if (status.isGranted || status.isLimited) return true;
    if (status.isDenied) {
      final result = await Permission.storage.request();
      return result.isGranted || result.isLimited;
    }
    return false;
  }
}
