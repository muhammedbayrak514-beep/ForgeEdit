import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Shared project-time clock used by timeline UI and (later) multi-clip playback.
///
/// Stage 4:
/// - Single source of truth for "where are we on the project timeline"
/// - Playhead position in milliseconds from project start
/// - Zoom scale (pixels per millisecond)
/// - isPlaying flag (UI only for now; full multi-clip play is Stage 5+)
///
/// Preview still owns the actual VideoPlayerController for the *selected* clip.
/// When the selected clip is playing, preview reports position back into this clock
/// as: clock = clip.timelineStartMs + controller.position (clamped to clip range).
class TimelineClock {
  /// Current playhead position in project time (ms from 0).
  final int positionMs;

  /// Visual scale: how many logical pixels represent 1 ms.
  /// Default ~0.04 → 1 second ≈ 40 px (same as previous clip width formula).
  final double pixelsPerMs;

  /// Whether the user intends playback (UI state). Real multi-clip play not wired yet.
  final bool isPlaying;

  const TimelineClock({
    this.positionMs = 0,
    this.pixelsPerMs = 0.04,
    this.isPlaying = false,
  });

  double get pixelsPerSecond => pixelsPerMs * 1000;

  TimelineClock copyWith({
    int? positionMs,
    double? pixelsPerMs,
    bool? isPlaying,
  }) {
    return TimelineClock(
      positionMs: positionMs ?? this.positionMs,
      pixelsPerMs: pixelsPerMs ?? this.pixelsPerMs,
      isPlaying: isPlaying ?? this.isPlaying,
    );
  }
}

final timelineClockProvider =
    StateNotifierProvider.family<TimelineClockNotifier, TimelineClock, String>(
  (ref, projectId) => TimelineClockNotifier(),
);

class TimelineClockNotifier extends StateNotifier<TimelineClock> {
  TimelineClockNotifier() : super(const TimelineClock());

  void setPosition(int ms) {
    final clamped = ms < 0 ? 0 : ms;
    if (clamped == state.positionMs) return;
    state = state.copyWith(positionMs: clamped);
  }

  void setPlaying(bool playing) {
    if (playing == state.isPlaying) return;
    state = state.copyWith(isPlaying: playing);
  }

  void setZoom(double pixelsPerMs) {
    final z = pixelsPerMs.clamp(0.01, 0.2);
    state = state.copyWith(pixelsPerMs: z);
  }

  void zoomIn() => setZoom(state.pixelsPerMs * 1.25);
  void zoomOut() => setZoom(state.pixelsPerMs / 1.25);

  /// Nudge playhead by delta ms (e.g. from keyboard or buttons later).
  void nudge(int deltaMs) => setPosition(state.positionMs + deltaMs);
}
