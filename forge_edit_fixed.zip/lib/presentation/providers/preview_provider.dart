import 'package:collection/collection.dart';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:video_player/video_player.dart';

import '../../domain/models/clip_model.dart';
import 'editor_provider.dart';
import 'timeline_clock_provider.dart';

/// Holds the currently selected clip id for preview / timeline highlight.
final selectedClipIdProvider =
    StateProvider.family<String?, String>((ref, projectId) => null);

/// Manages VideoPlayerController lifecycle for the editor preview.
///
/// What works in Stage 3:
/// - Load video from clip.filePath (app-private absolute path)
/// - Play / pause
/// - Show current position & duration
/// - Switch clip when selection changes
/// - Dispose controller on provider dispose / clip change
///
/// Stage 4 additions:
/// - While selected clip plays, controller position is mapped into TimelineClock
/// - Timeline playhead drag seeks the selected clip if playhead is inside it
///
/// What does NOT work yet:
/// - Continuous play across multiple clips (playlist / auto-advance)
/// - Full bidirectional sync when playhead is outside the selected clip
class PreviewControllerNotifier extends FamilyAsyncNotifier<PreviewState, String> {
  VideoPlayerController? _controller;
  String? _loadedClipId;

  String get projectId => arg;

  @override
  Future<PreviewState> build(String projectId) async {
    ref.onDispose(() {
      _disposeController();
    });

    // When project clips change, keep selection valid
    ref.listen(editorProvider(projectId), (prev, next) {
      final clips = next.value?.clips ?? [];
      final selectedId = ref.read(selectedClipIdProvider(projectId));
      if (selectedId != null && !clips.any((c) => c.id == selectedId)) {
        ref.read(selectedClipIdProvider(projectId).notifier).state =
            clips.isNotEmpty ? clips.first.id : null;
      } else if (selectedId == null && clips.isNotEmpty) {
        // Auto-select first clip when media is first added
        ref.read(selectedClipIdProvider(projectId).notifier).state =
            clips.first.id;
      }
    });

    // React to selection changes — MUST assign state (otherwise stuck on loading)
    ref.listen(selectedClipIdProvider(projectId), (prev, next) async {
      if (next != null && next != _loadedClipId) {
        final result = await _loadClipById(next);
        // Guard against race if selection changed again while loading
        if (ref.read(selectedClipIdProvider(projectId)) == next) {
          state = AsyncData(result);
        }
      } else if (next == null) {
        await _disposeController();
        state = const AsyncData(PreviewState.empty());
      }
    });

    final selectedId = ref.read(selectedClipIdProvider(projectId));
    if (selectedId != null) {
      return _loadClipById(selectedId);
    }

    // Prefer first video, otherwise first clip of any type (image/audio/text)
    final project = ref.read(editorProvider(projectId)).value;
    final clips = project?.clips ?? const <ClipModel>[];
    final firstVideo = clips.where((c) => c.type == ClipType.video).firstOrNull;
    final firstAny = firstVideo ?? (clips.isNotEmpty ? clips.first : null);
    if (firstAny != null) {
      ref.read(selectedClipIdProvider(projectId).notifier).state = firstAny.id;
      return _loadClipById(firstAny.id);
    }

    return const PreviewState.empty();
  }

  Future<PreviewState> _loadClipById(String clipId) async {
    final project = ref.read(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) {
      return const PreviewState.empty();
    }
    return _loadClip(clip);
  }

  Future<PreviewState> _loadClip(ClipModel clip) async {
    state = const AsyncLoading();

    await _disposeController();

    if (clip.type == ClipType.image) {
      final imageFile = File(clip.filePath);
      if (!await imageFile.exists()) {
        _loadedClipId = clip.id;
        return PreviewState(
          clipId: clip.id,
          displayName: clip.displayName,
          isImage: true,
          error: 'Görsel dosyası bulunamadı:\n${clip.filePath}',
          controller: null,
        );
      }
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        isImage: true,
        error: null,
        controller: null,
      );
    }

    if (clip.type != ClipType.video) {
      // Audio / text: no video surface
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        isImage: false,
        error: null,
        controller: null,
      );
    }

    final file = File(clip.filePath);
    if (!await file.exists()) {
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        isImage: false,
        error: 'Video dosyası bulunamadı:\n${clip.filePath}',
        controller: null,
      );
    }

    try {
      final controller = VideoPlayerController.file(file);
      await controller.initialize();

      // Apply trim start as initial position
      if (clip.trimStartMs > 0) {
        await controller.seekTo(Duration(milliseconds: clip.trimStartMs));
      }

      controller.addListener(_onControllerUpdate);

      _controller = controller;
      _loadedClipId = clip.id;

      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        isImage: false,
        error: null,
        controller: controller,
      );
    } catch (e, st) {
      debugPrint('Preview load error: $e\n$st');
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        isImage: false,
        error: 'Video yüklenemedi: $e',
        controller: null,
      );
    }
  }

  void _onControllerUpdate() {
    // Trigger rebuild so position text updates
    final current = state.value;
    if (current != null && current.controller != null) {
      state = AsyncData(current.copyWith(tick: current.tick + 1));

      // Map local controller position → project timeline time (selected clip only)
      final clipId = current.clipId;
      if (clipId != null) {
        final project = ref.read(editorProvider(projectId)).value;
        final clip = project?.clips.where((c) => c.id == clipId).firstOrNull;
        if (clip != null) {
          final localMs = current.controller!.value.position.inMilliseconds;
          // controller is relative to file start; account for trimStart
          final withinClip = (localMs - clip.trimStartMs).clamp(0, clip.durationMs);
          final projectMs = clip.timelineStartMs + withinClip;
          ref.read(timelineClockProvider(projectId).notifier).setPosition(projectMs);
          ref.read(timelineClockProvider(projectId).notifier).setPlaying(
                current.controller!.value.isPlaying,
              );
        }
      }
    }
  }

  Future<void> play() async {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    await c.play();
  }

  Future<void> pause() async {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    await c.pause();
  }

  Future<void> togglePlay() async {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    if (c.value.isPlaying) {
      await c.pause();
    } else {
      await c.play();
    }
  }

  Future<void> seek(Duration position) async {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    await c.seekTo(position);
  }

  Future<void> _disposeController() async {
    final c = _controller;
    _controller = null;
    _loadedClipId = null;
    if (c != null) {
      c.removeListener(_onControllerUpdate);
      await c.dispose();
    }
  }
}

final previewProvider =
    AsyncNotifierProvider.family<PreviewControllerNotifier, PreviewState, String>(
  PreviewControllerNotifier.new,
);

class PreviewState {
  final String? clipId;
  final String? displayName;
  final bool isImage;
  final String? error;
  final VideoPlayerController? controller;
  /// Increments on controller listener to force UI rebuild for position.
  final int tick;

  const PreviewState({
    this.clipId,
    this.displayName,
    this.isImage = false,
    this.error,
    this.controller,
    this.tick = 0,
  });

  const PreviewState.empty()
      : clipId = null,
        displayName = null,
        isImage = false,
        error = null,
        controller = null,
        tick = 0;

  bool get hasVideo =>
      controller != null &&
      controller!.value.isInitialized &&
      error == null &&
      !isImage;

  bool get isPlaying => controller?.value.isPlaying ?? false;

  Duration get position => controller?.value.position ?? Duration.zero;

  Duration get duration => controller?.value.duration ?? Duration.zero;

  PreviewState copyWith({
    String? clipId,
    String? displayName,
    bool? isImage,
    String? error,
    VideoPlayerController? controller,
    int? tick,
  }) {
    return PreviewState(
      clipId: clipId ?? this.clipId,
      displayName: displayName ?? this.displayName,
      isImage: isImage ?? this.isImage,
      error: error ?? this.error,
      controller: controller ?? this.controller,
      tick: tick ?? this.tick,
    );
  }
}
