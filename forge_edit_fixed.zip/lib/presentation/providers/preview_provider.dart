import 'dart:async';
import 'dart:io';

import 'package:collection/collection.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:video_player/video_player.dart';

import '../../domain/models/clip_model.dart';
import '../../domain/timeline_playback.dart';
import 'editor_provider.dart';
import 'timeline_clock_provider.dart';

/// Selected clip id for preview / timeline highlight.
final selectedClipIdProvider =
    StateProvider.family<String?, String>((ref, projectId) => null);

/// Preview surface + multi-clip continuous playback.
///
/// Playback model:
/// - [TimelineClock] is the source of truth for project time.
/// - Play starts at the current playhead, loads the visual clip under it,
///   seeks into the clip, and plays.
/// - When a video reaches its trim end (or an image's duration elapses),
///   we advance to the next visual clip automatically until the timeline ends.
class PreviewControllerNotifier
    extends FamilyAsyncNotifier<PreviewState, String> {
  VideoPlayerController? _controller;
  String? _loadedClipId;

  /// User pressed play; keep advancing until pause or end.
  bool _userWantsPlay = false;

  /// Guard against double-advance from multiple listener ticks.
  bool _advancing = false;

  Timer? _imageTimer;

  String get projectId => arg;

  @override
  Future<PreviewState> build(String projectId) async {
    ref.onDispose(() {
      _imageTimer?.cancel();
      _userWantsPlay = false;
      _disposeController();
    });

    // Keep selection valid when clips change.
    ref.listen(editorProvider(projectId), (prev, next) {
      final clips = next.value?.clips ?? [];
      final selectedId = ref.read(selectedClipIdProvider(projectId));
      if (selectedId != null && !clips.any((c) => c.id == selectedId)) {
        ref.read(selectedClipIdProvider(projectId).notifier).state =
            clips.isNotEmpty ? clips.first.id : null;
      } else if (selectedId == null && clips.isNotEmpty) {
        ref.read(selectedClipIdProvider(projectId).notifier).state =
            clips.first.id;
      }
    });

    // Selection change → load that clip (preserve play intent).
    // Skip while continuous-play advance owns the load (avoids double init).
    ref.listen(selectedClipIdProvider(projectId), (prev, next) async {
      if (next != null && next != _loadedClipId) {
        if (_advancing) return;
        final result = await _loadClipById(next);
        if (ref.read(selectedClipIdProvider(projectId)) == next) {
          state = AsyncData(result);
          if (_userWantsPlay) {
            await _playLoadedClipFromClock();
          }
        }
      } else if (next == null) {
        await _disposeController();
        state = const AsyncData(PreviewState.empty());
      }
    });

    // Playhead scrub while paused → show the clip under the playhead.
    ref.listen(timelineClockProvider(projectId), (prev, next) async {
      if (_userWantsPlay) return;
      if (prev?.positionMs == next.positionMs) return;
      final project = ref.read(editorProvider(projectId)).value;
      if (project == null || project.clips.isEmpty) return;
      final under =
          TimelinePlayback.visualClipAt(project.clips, next.positionMs);
      if (under == null) return;
      if (under.id == _loadedClipId) {
        // Same clip: seek video to match playhead.
        if (!under.type.isVideo || _controller == null) return;
        if (!_controller!.value.isInitialized) return;
        final local =
            TimelinePlayback.projectToLocalMs(under, next.positionMs);
        final cur = _controller!.value.position.inMilliseconds;
        if ((cur - local).abs() > 120) {
          await _controller!.seekTo(Duration(milliseconds: local));
        }
        return;
      }
      ref.read(selectedClipIdProvider(projectId).notifier).state = under.id;
    });

    final selectedId = ref.read(selectedClipIdProvider(projectId));
    if (selectedId != null) {
      return _loadClipById(selectedId);
    }

    final project = ref.read(editorProvider(projectId)).value;
    final clips = project?.clips ?? const <ClipModel>[];
    final first = TimelinePlayback.visualClipsSorted(clips).firstOrNull ??
        (clips.isNotEmpty ? clips.first : null);
    if (first != null) {
      ref.read(selectedClipIdProvider(projectId).notifier).state = first.id;
      return _loadClipById(first.id);
    }

    return const PreviewState.empty();
  }

  Future<PreviewState> _loadClipById(String clipId) async {
    final project = ref.read(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return const PreviewState.empty();
    return _loadClip(clip);
  }

  Future<PreviewState> _loadClip(ClipModel clip) async {
    state = const AsyncLoading();
    _imageTimer?.cancel();
    await _disposeController();

    if (clip.type == ClipType.image) {
      final imageFile = File(clip.filePath);
      if (!await imageFile.exists()) {
        _loadedClipId = clip.id;
        return PreviewState(
          clipId: clip.id,
          displayName: clip.displayName,
          isImage: true,
          error: 'Görsel dosyası bulunamadı:\n${clip.filePath}',
        );
      }
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        isImage: true,
      );
    }

    if (clip.type != ClipType.video) {
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
      );
    }

    final file = File(clip.filePath);
    if (!await file.exists()) {
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        error: 'Video dosyası bulunamadı:\n${clip.filePath}',
      );
    }

    try {
      final controller = VideoPlayerController.file(file);
      await controller.initialize();

      final startLocal = clip.trimStartMs.clamp(0, clip.trimEndMs);
      if (startLocal > 0) {
        await controller.seekTo(Duration(milliseconds: startLocal));
      }

      controller.addListener(_onControllerUpdate);
      _controller = controller;
      _loadedClipId = clip.id;

      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        controller: controller,
      );
    } catch (e, st) {
      debugPrint('Preview load error: $e\n$st');
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        error: 'Video yüklenemedi: $e',
      );
    }
  }

  void _onControllerUpdate() {
    final current = state.value;
    final controller = current?.controller;
    if (current == null || controller == null) return;

    state = AsyncData(current.copyWith(tick: current.tick + 1));

    final clipId = current.clipId;
    if (clipId == null) return;
    final project = ref.read(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return;

    final localMs = controller.value.position.inMilliseconds;
    final projectMs = TimelinePlayback.localToProjectMs(clip, localMs);
    final clock = ref.read(timelineClockProvider(projectId).notifier);
    clock.setPosition(projectMs);

    if (!_userWantsPlay) {
      clock.setPlaying(controller.value.isPlaying);
      return;
    }

    clock.setPlaying(true);

    // End of this video clip → advance (only while user wants play).
    if (!_userWantsPlay || _advancing) return;
    final duration = controller.value.duration.inMilliseconds;
    final atTrimEnd = TimelinePlayback.isAtClipEnd(clip, localMs);
    final nearFileEnd =
        duration > 0 && localMs >= duration - 120;
    if (atTrimEnd || nearFileEnd) {
      // Ignore spurious end events if still actively playing mid-clip
      if (controller.value.isPlaying && localMs < clip.trimEndMs - 200) {
        return;
      }
      _advanceFrom(clip);
    }
  }

  Future<void> _advanceFrom(ClipModel finished) async {
    if (_advancing || !_userWantsPlay) return;
    _advancing = true;
    try {
      final project = ref.read(editorProvider(projectId)).value;
      if (project == null) {
        await pausePlayback();
        return;
      }
      final next = TimelinePlayback.nextAfter(project.clips, finished.id);
      if (next == null) {
        // Timeline finished.
        ref
            .read(timelineClockProvider(projectId).notifier)
            .setPosition(finished.timelineEndMs);
        await pausePlayback();
        return;
      }

      // Move playhead to the start of the next clip and load it.
      ref
          .read(timelineClockProvider(projectId).notifier)
          .setPosition(next.timelineStartMs);
      ref.read(selectedClipIdProvider(projectId).notifier).state = next.id;

      // Selection listener loads the clip; if already loaded path is sync-ish:
      if (_loadedClipId != next.id) {
        final result = await _loadClip(next);
        if (!_userWantsPlay) return;
        state = AsyncData(result);
      }
      await _playLoadedClipFromClock();
    } finally {
      _advancing = false;
    }
  }

  /// Seek + play the currently loaded clip according to the timeline clock.
  Future<void> _playLoadedClipFromClock() async {
    final project = ref.read(editorProvider(projectId)).value;
    if (project == null || !_userWantsPlay) return;

    final pos = ref.read(timelineClockProvider(projectId)).positionMs;
    final clip = project.clips.where((c) => c.id == _loadedClipId).firstOrNull;
    if (clip == null) return;

    if (clip.type == ClipType.image) {
      _scheduleImageAdvance(clip, pos);
      return;
    }

    final c = _controller;
    if (c == null || !c.value.isInitialized) return;

    final local = TimelinePlayback.projectToLocalMs(clip, pos);
    await c.seekTo(Duration(milliseconds: local));
    if (!_userWantsPlay) return;
    await c.play();
    ref.read(timelineClockProvider(projectId).notifier).setPlaying(true);
  }

  void _scheduleImageAdvance(ClipModel clip, int projectPosMs) {
    _imageTimer?.cancel();
    final remaining =
        (clip.timelineEndMs - projectPosMs).clamp(50, clip.durationMs);
    // Tick the clock while the image is "playing".
    final started = DateTime.now();
    final startPos = projectPosMs;
    _imageTimer = Timer.periodic(const Duration(milliseconds: 50), (t) {
      if (!_userWantsPlay) {
        t.cancel();
        return;
      }
      final elapsed = DateTime.now().difference(started).inMilliseconds;
      final now = (startPos + elapsed).clamp(startPos, clip.timelineEndMs);
      ref.read(timelineClockProvider(projectId).notifier).setPosition(now);
      if (elapsed >= remaining) {
        t.cancel();
        _advanceFrom(clip);
      }
    });
  }

  // ── Public transport API ──────────────────────────────────────────

  Future<void> startPlayback() async {
    final project = ref.read(editorProvider(projectId)).value;
    if (project == null || project.clips.isEmpty) return;

    _userWantsPlay = true;
    ref.read(timelineClockProvider(projectId).notifier).setPlaying(true);

    var pos = ref.read(timelineClockProvider(projectId)).positionMs;
    // If we're at/past the end, restart from the beginning.
    if (pos >= project.durationMs - 40) {
      pos = 0;
      ref.read(timelineClockProvider(projectId).notifier).setPosition(0);
    }

    var clip = TimelinePlayback.visualClipAt(project.clips, pos);
    clip ??= TimelinePlayback.nextVisualAtOrAfter(project.clips, pos);
    if (clip == null) {
      await pausePlayback();
      return;
    }

    if (pos < clip.timelineStartMs) {
      pos = clip.timelineStartMs;
      ref.read(timelineClockProvider(projectId).notifier).setPosition(pos);
    }

    if (_loadedClipId != clip.id) {
      ref.read(selectedClipIdProvider(projectId).notifier).state = clip.id;
      final result = await _loadClip(clip);
      if (!_userWantsPlay) return;
      state = AsyncData(result);
    }

    await _playLoadedClipFromClock();
  }

  Future<void> pausePlayback() async {
    _userWantsPlay = false;
    _imageTimer?.cancel();
    _imageTimer = null;
    final c = _controller;
    if (c != null && c.value.isInitialized && c.value.isPlaying) {
      await c.pause();
    }
    ref.read(timelineClockProvider(projectId).notifier).setPlaying(false);
  }

  Future<void> togglePlay() async {
    final playing = ref.read(timelineClockProvider(projectId)).isPlaying ||
        _userWantsPlay;
    if (playing) {
      await pausePlayback();
    } else {
      await startPlayback();
    }
  }

  Future<void> play() => startPlayback();
  Future<void> pause() => pausePlayback();

  /// Seek within the *loaded* video (transport slider). Also updates clock.
  Future<void> seek(Duration position) async {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    await c.seekTo(position);
    final project = ref.read(editorProvider(projectId)).value;
    final clip =
        project?.clips.where((c) => c.id == _loadedClipId).firstOrNull;
    if (clip != null) {
      final projectMs =
          TimelinePlayback.localToProjectMs(clip, position.inMilliseconds);
      ref.read(timelineClockProvider(projectId).notifier).setPosition(projectMs);
    }
  }

  Future<void> _disposeController() async {
    final c = _controller;
    _controller = null;
    _loadedClipId = null;
    if (c != null) {
      c.removeListener(_onControllerUpdate);
      await c.dispose();
    }
  }
}

final previewProvider = AsyncNotifierProvider.family<PreviewControllerNotifier,
    PreviewState, String>(
  PreviewControllerNotifier.new,
);

class PreviewState {
  final String? clipId;
  final String? displayName;
  final bool isImage;
  final String? error;
  final VideoPlayerController? controller;
  final int tick;

  const PreviewState({
    this.clipId,
    this.displayName,
    this.isImage = false,
    this.error,
    this.controller,
    this.tick = 0,
  });

  const PreviewState.empty()
      : clipId = null,
        displayName = null,
        isImage = false,
        error = null,
        controller = null,
        tick = 0;

  bool get hasVideo =>
      controller != null &&
      controller!.value.isInitialized &&
      error == null &&
      !isImage;

  bool get isPlaying => controller?.value.isPlaying ?? false;

  Duration get position => controller?.value.position ?? Duration.zero;

  Duration get duration => controller?.value.duration ?? Duration.zero;

  PreviewState copyWith({
    String? clipId,
    String? displayName,
    bool? isImage,
    String? error,
    VideoPlayerController? controller,
    int? tick,
  }) {
    return PreviewState(
      clipId: clipId ?? this.clipId,
      displayName: displayName ?? this.displayName,
      isImage: isImage ?? this.isImage,
      error: error ?? this.error,
      controller: controller ?? this.controller,
      tick: tick ?? this.tick,
    );
  }
}

extension on ClipType {
  bool get isVideo => this == ClipType.video;
}
