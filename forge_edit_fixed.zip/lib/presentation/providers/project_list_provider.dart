import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/repositories/project_repository.dart';
import '../../domain/models/project_model.dart';

final projectRepositoryProvider = Provider<ProjectRepository>((ref) {
  return ProjectRepository();
});

final projectListProvider =
    AsyncNotifierProvider<ProjectListNotifier, List<ProjectModel>>(
  ProjectListNotifier.new,
);

class ProjectListNotifier extends AsyncNotifier<List<ProjectModel>> {
  ProjectRepository get _repo => ref.read(projectRepositoryProvider);

  @override
  Future<List<ProjectModel>> build() async {
    return _repo.getAllProjects();
  }

  Future<ProjectModel> createProject({String? name}) async {
    final project = ProjectModel.create(name: name);
    await _repo.saveProject(project);
    state = AsyncData([project, ...?state.value]);
    return project;
  }

  Future<void> deleteProject(String id) async {
    await _repo.deleteProject(id);
    state = AsyncData(
      state.value?.where((p) => p.id != id).toList() ?? [],
    );
  }

  Future<void> renameProject(String id, String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    final list = state.value ?? [];
    final idx = list.indexWhere((p) => p.id == id);
    if (idx < 0) return;
    final updated = list[idx].copyWith(name: trimmed, updatedAt: DateTime.now());
    await _repo.saveProject(updated);
    final next = [...list];
    next[idx] = updated;
    state = AsyncData(next);
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = AsyncData(await _repo.getAllProjects());
  }
}
