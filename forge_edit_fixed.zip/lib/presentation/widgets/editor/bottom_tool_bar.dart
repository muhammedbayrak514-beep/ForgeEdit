import 'package:file_picker/file_picker.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/clip_model.dart';
import '../../../data/services/audio_import_service.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../providers/project_list_provider.dart';
import '../../screens/editor/media_picker_screen.dart';
import 'clip_inspector_sheet.dart';
import 'text_style_sheet.dart';
import 'effects_sheet.dart';

/// PicsArt-style bottom icon toolbar.
class BottomToolBar extends ConsumerWidget {
  final String projectId;

  const BottomToolBar({super.key, required this.projectId});

  Future<void> _openMedia(BuildContext context) async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => MediaPickerScreen(projectId: projectId),
        fullscreenDialog: true,
      ),
    );
  }

  Future<void> _addText(BuildContext context, WidgetRef ref) async {
    final controller = TextEditingController(text: 'Metin');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Metin ekle'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'Metin içeriği'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('İptal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Ekle'),
          ),
        ],
      ),
    );
    if (result == null || result.isEmpty) return;
    await ref.read(editorProvider(projectId).notifier).addTextClip(
          content: result,
          durationMs: 3000,
        );
  }

  Future<void> _addAudio(BuildContext context, WidgetRef ref) async {
    try {
      final pick = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: AudioImportService.supportedAudio,
        allowMultiple: false,
      );
      if (pick == null || pick.files.isEmpty) return;
      final path = pick.files.single.path;
      if (path == null) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Dosya yolu alınamadı')),
          );
        }
        return;
      }
      final service = AudioImportService(ref.read(projectRepositoryProvider));
      final project = ref.read(editorProvider(projectId)).value;
      final startMs = project?.durationMs ?? 0;
      final clip = await service.importAudioFile(
        projectId: projectId,
        sourcePath: path,
        displayName: p.basename(path),
        timelineStartMs: startMs,
      );
      if (clip == null) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Ses içe aktarılamadı')),
          );
        }
        return;
      }
      await ref.read(editorProvider(projectId).notifier).addAudioClip(clip);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ses eklendi: ${clip.displayName}')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ses hatası: $e')),
        );
      }
    }
  }

  void _openEffects(BuildContext context, WidgetRef ref) {
    final sel = ref.read(selectedClipIdProvider(projectId));
    final project = ref.read(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == sel).firstOrNull;

    if (clip != null && clip.type == ClipType.text) {
      TextStyleSheet.open(
        context,
        projectId: projectId,
        clipId: clip.id,
        currentStyleId: clip.textStyleId,
      );
      return;
    }

    EffectsSheet.open(context, projectId);
  }

  Future<void> _openTextStylesOrAdd(BuildContext context, WidgetRef ref) async {
    final sel = ref.read(selectedClipIdProvider(projectId));
    final project = ref.read(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == sel).firstOrNull;
    if (clip != null && clip.type == ClipType.text) {
      await TextStyleSheet.open(
        context,
        projectId: projectId,
        clipId: clip.id,
        currentStyleId: clip.textStyleId,
      );
      return;
    }
    await _addText(context, ref);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Material(
      color: AppTheme.surface,
      elevation: 8,
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _Item(
                icon: Icons.photo_library_outlined,
                label: 'Medya',
                onTap: () => _openMedia(context),
              ),
              _Item(
                icon: Icons.music_note_outlined,
                label: 'Ses',
                onTap: () => _addAudio(context, ref),
              ),
              _Item(
                icon: Icons.text_fields,
                label: 'Metin',
                onTap: () => _openTextStylesOrAdd(context, ref),
              ),
              _Item(
                icon: Icons.auto_awesome,
                label: 'Efekt',
                onTap: () => _openEffects(context, ref),
              ),
              _Item(
                icon: Icons.content_cut,
                label: 'Düzenle',
                onTap: () {
                  final sel = ref.read(selectedClipIdProvider(projectId));
                  if (sel == null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Önce timeline’dan bir klip seç'),
                      ),
                    );
                    return;
                  }
                  ClipInspectorSheet.show(context, projectId);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Item extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _Item({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        width: 64,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppTheme.textPrimary, size: 24),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(
                fontSize: 11,
                color: AppTheme.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
