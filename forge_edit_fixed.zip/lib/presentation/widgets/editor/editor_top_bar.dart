import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/project_model.dart';
import '../../providers/editor_provider.dart';
import '../../providers/project_list_provider.dart';
import '../../screens/editor/export_screen.dart';

class EditorTopBar extends ConsumerWidget {
  final ProjectModel project;
  final String projectId;

  const EditorTopBar({
    super.key,
    required this.project,
    required this.projectId,
  });

  Future<void> _rename(BuildContext context, WidgetRef ref) async {
    final controller = TextEditingController(text: project.name);
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Proje adı'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 48,
          decoration: const InputDecoration(hintText: 'Proje adı'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('İptal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );
    if (result == null || result.isEmpty) return;
    await ref.read(editorProvider(projectId).notifier).renameProject(result);
    await ref.read(projectListProvider.notifier).renameProject(projectId, result);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(historyUiProvider(projectId));
    final live = ref.watch(editorProvider(projectId)).value ?? project;

    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(bottom: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back),
            tooltip: 'Geri',
            onPressed: () => Navigator.of(context).pop(),
          ),
          Expanded(
            child: InkWell(
              onTap: () => _rename(context, ref),
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                child: Row(
                  children: [
                    Flexible(
                      child: Text(
                        live.name,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Icon(
                      Icons.edit,
                      size: 14,
                      color: AppTheme.textSecondary,
                    ),
                  ],
                ),
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.undo),
            tooltip: history.canUndo ? 'Geri al' : 'Geri al',
            onPressed: history.canUndo
                ? () => ref.read(editorProvider(projectId).notifier).undo()
                : null,
          ),
          IconButton(
            icon: const Icon(Icons.redo),
            tooltip: history.canRedo ? 'Yinele' : 'Yinele',
            onPressed: history.canRedo
                ? () => ref.read(editorProvider(projectId).notifier).redo()
                : null,
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => ExportScreen(projectId: projectId),
                ),
              );
            },
            icon: const Icon(Icons.file_upload_outlined, size: 18),
            label: const Text('Dışa Aktar'),
          ),
        ],
      ),
    );
  }
}
