import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/project_model.dart';
import '../../providers/editor_provider.dart';
import '../../screens/editor/export_screen.dart';

class EditorTopBar extends ConsumerWidget {
  final ProjectModel project;
  final String projectId;

  const EditorTopBar({
    super.key,
    required this.project,
    required this.projectId,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(historyUiProvider(projectId));

    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(
          bottom: BorderSide(color: AppTheme.border, width: 1),
        ),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back),
            tooltip: 'Geri',
            onPressed: () => Navigator.of(context).pop(),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              project.name,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // Stage 8 foundation: working undo/redo
          IconButton(
            icon: const Icon(Icons.undo),
            tooltip: history.canUndo
                ? 'Geri al (${history.undoCount})'
                : 'Geri al',
            onPressed: history.canUndo
                ? () => ref.read(editorProvider(projectId).notifier).undo()
                : null,
          ),
          IconButton(
            icon: const Icon(Icons.redo),
            tooltip: history.canRedo
                ? 'Yinele (${history.redoCount})'
                : 'Yinele',
            onPressed: history.canRedo
                ? () => ref.read(editorProvider(projectId).notifier).redo()
                : null,
          ),
          const SizedBox(width: 8),
          // Export – Stage 9 (not implemented)
          ElevatedButton.icon(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => ExportScreen(projectId: projectId),
                ),
              );
            },
            icon: const Icon(Icons.file_upload_outlined, size: 18),
            label: const Text('Dışa Aktar'),
          ),
        ],
      ),
    );
  }
}
