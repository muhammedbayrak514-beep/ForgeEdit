import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/clip_model.dart';
import 'text_style_sheet.dart';
import '../../../domain/models/clip_model.dart';
import '../../../domain/models/effect_models.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import 'package:collection/collection.dart';

/// Bottom sheet / panel to set filter on selected clip and transition to next.
class EffectsSheet extends ConsumerWidget {
  final String projectId;

  const EffectsSheet({super.key, required this.projectId});

  static Future<void> open(BuildContext context, String projectId) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => EffectsSheet(projectId: projectId),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedId = ref.watch(selectedClipIdProvider(projectId));
    final project = ref.watch(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == selectedId).firstOrNull;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        child: clip == null
            ? const Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Filtre / geçiş için video veya foto klip seç.\n'
                  'Yazı stilleri için metin klip seç → Metin veya Efekt.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppTheme.textSecondary, height: 1.4),
                ),
              )
            : clip.type == ClipType.text
                ? Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          'Yazı stilleri (~100 adet)',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () {
                            Navigator.pop(context);
                            TextStyleSheet.open(
                              context,
                              projectId: projectId,
                              clipId: clip.id,
                              currentStyleId: clip.textStyleId,
                            );
                          },
                          icon: const Icon(Icons.style),
                          label: const Text('Stilleri aç'),
                        ),
                      ],
                    ),
                  )
                : _EffectsBody(projectId: projectId, clip: clip),
      ),
    );
  }
}

class _EffectsBody extends ConsumerWidget {
  final String projectId;
  final ClipModel clip;

  const _EffectsBody({required this.projectId, required this.clip});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isVideo =
        clip.type == ClipType.video || clip.type == ClipType.image;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: AppTheme.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Text(
            'Filtre & Geçiş — ${clip.displayName}',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 4),
          const Text(
            'Önizleme: ColorFilter yaklaşık görünüm. Export (Aşama 9) ayrıdır.',
            style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 16),
          if (!isVideo)
            const Text(
              'Filtreler şu an yalnızca video/görsel kliplerde anlamlı.',
              style: TextStyle(color: AppTheme.warning, fontSize: 12),
            )
          else ...[
            const Text('Filtre', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final f in EffectCatalog.filters)
                  ChoiceChip(
                    label: Text(f.label),
                    selected: clip.filterId == f.id.name,
                    onSelected: (_) {
                      ref.read(editorProvider(projectId).notifier).updateClip(
                            clip.copyWith(filterId: f.id.name),
                          );
                    },
                  ),
              ],
            ),
            if (clip.filterId != 'none') ...[
              const SizedBox(height: 8),
              Text(
                'Yoğunluk: ${(clip.filterIntensity * 100).round()}%',
                style: const TextStyle(
                  fontSize: 12,
                  color: AppTheme.textSecondary,
                ),
              ),
              Slider(
                value: clip.filterIntensity.clamp(0.0, 1.0),
                onChangeStart: (_) {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .beginContinuousEdit('filter_${clip.id}');
                },
                onChanged: (v) {
                  ref.read(editorProvider(projectId).notifier).updateClip(
                        clip.copyWith(filterIntensity: v),
                        continuous: true,
                      );
                },
                onChangeEnd: (_) {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .endContinuousEdit();
                },
              ),
              TextButton(
                onPressed: () {
                  ref.read(editorProvider(projectId).notifier).updateClip(
                        clip.copyWith(
                          filterId: 'none',
                          filterIntensity: 1.0,
                        ),
                      );
                },
                child: const Text('Filtreyi kaldır'),
              ),
            ],
          ],
          const Divider(height: 32),
          const Text('Sonraki klibe geçiş',
              style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          const Text(
            'Geçiş bu klibin bitişinde uygulanır (model). '
            'Geçiş export’ta uygulanır (crossfade / fadeBlack / wipeLeft).',
            style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final tr in EffectCatalog.transitions)
                ChoiceChip(
                  label: Text(
                    tr.exportReady ? tr.label : '${tr.label} *',
                  ),
                  selected: clip.transitionId == tr.id.name,
                  onSelected: (_) {
                    ref.read(editorProvider(projectId).notifier).updateClip(
                          clip.copyWith(transitionId: tr.id.name),
                        );
                    if (!tr.exportReady && tr.id != TransitionId.none) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            '${tr.label}',
                          ),
                        ),
                      );
                    }
                  },
                ),
            ],
          ),
          if (clip.transitionId != 'none') ...[
            const SizedBox(height: 8),
            Text(
              'Süre: ${clip.transitionDurationMs} ms',
              style: const TextStyle(
                fontSize: 12,
                color: AppTheme.textSecondary,
              ),
            ),
            Slider(
              min: 100,
              max: 2000,
              divisions: 19,
              value: clip.transitionDurationMs.toDouble().clamp(100, 2000),
              onChangeStart: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .beginContinuousEdit('trdur_${clip.id}');
              },
              onChanged: (v) {
                ref.read(editorProvider(projectId).notifier).updateClip(
                      clip.copyWith(transitionDurationMs: v.round()),
                      continuous: true,
                    );
              },
              onChangeEnd: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .endContinuousEdit();
              },
            ),
          ],
        ],
      ),
    );
  }
}
