import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:video_player/video_player.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/time_formatter.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../providers/timeline_clock_provider.dart';
import '../../../domain/models/clip_model.dart';
import '../../../domain/models/text_style_catalog.dart';
import 'filter_matrix.dart';

/// Real video preview using video_player.
///
/// Stage 3 capabilities:
/// - Plays the selected clip from its copied file path
/// - Play / pause
/// - Position + duration text
/// - Loading and error states
/// - Proper controller dispose via provider
///
/// Not yet:
/// - Multi-clip continuous playback
/// - Timeline drag → seek (scrubbing from timeline)
/// - Shared playhead clock across tracks
class PreviewPanel extends ConsumerWidget {
  final String projectId;

  const PreviewPanel({super.key, required this.projectId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final editorState = ref.watch(editorProvider(projectId));
    final previewAsync = ref.watch(previewProvider(projectId));
    final hasClips = editorState.value?.clips.isNotEmpty ?? false;

    return Container(
      color: Colors.black,
      child: Column(
        children: [
          Expanded(
            child: !hasClips
                ? const _EmptyPreview()
                : previewAsync.when(
                    loading: () => const Center(
                      child: CircularProgressIndicator(color: AppTheme.primary),
                    ),
                    error: (e, _) => _ErrorPreview(message: e.toString()),
                    data: (preview) {
                      if (preview.error != null) {
                        return _ErrorPreview(message: preview.error!);
                      }
                      if (preview.isImage) {
                        final project = editorState.value;
                        final clip = project?.clips
                            .where((c) => c.id == preview.clipId)
                            .firstOrNull;
                        if (clip == null) {
                          return const Center(
                            child: Text(
                              'Görsel seçilmedi',
                              style: TextStyle(color: AppTheme.textSecondary),
                            ),
                          );
                        }
                        return Stack(
                          fit: StackFit.expand,
                          children: [
                            Center(
                              child: Image.file(
                                File(clip.filePath),
                                fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) => _ErrorPreview(
                                  message:
                                      'Görsel yüklenemedi\n${clip.displayName}',
                                ),
                              ),
                            ),
                            _TextOverlays(projectId: projectId),
                          ],
                        );
                      }
                      if (!preview.hasVideo) {
                        return const Center(
                          child: Text(
                            'Önizlenecek video yok',
                            style: TextStyle(color: AppTheme.textSecondary),
                          ),
                        );
                      }
                      final project = editorState.value;
                      final sel = preview.clipId;
                      final clip = project?.clips
                          .where((c) => c.id == sel)
                          .firstOrNull;
                      return Stack(
                        fit: StackFit.expand,
                        children: [
                          FilteredPreview(
                            filterId: clip?.filterId ?? 'none',
                            intensity: clip?.filterIntensity ?? 1.0,
                            child: _VideoSurface(
                              controller: preview.controller!,
                            ),
                          ),
                          _TextOverlays(projectId: projectId),
                        ],
                      );
                    },
                  ),
          ),
          // Transport controls
          if (hasClips) _TransportBar(projectId: projectId),
        ],
      ),
    );
  }
}

class _TextOverlays extends ConsumerWidget {
  final String projectId;

  const _TextOverlays({required this.projectId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final project = ref.watch(editorProvider(projectId)).value;
    final timelineMs =
        ref.watch(timelineClockProvider(projectId)).positionMs;

    final overlays = (project?.clips ?? const <ClipModel>[])
        .where((clip) =>
            clip.type == ClipType.text &&
            timelineMs >= clip.timelineStartMs &&
            timelineMs < clip.timelineEndMs)
        .toList();

    if (overlays.isEmpty) {
      return const SizedBox.shrink();
    }

    return Stack(
      children: overlays.map((clip) {
        final x = (clip.posX * 2 - 1).clamp(-1.0, 1.0).toDouble();
        final y = (clip.posY * 2 - 1).clamp(-1.0, 1.0).toDouble();

        final alignment = clip.textAlign == 0
            ? TextAlign.left
            : clip.textAlign == 2
                ? TextAlign.right
                : TextAlign.center;

        final styleDef = TextStyleCatalog.byId(clip.textStyleId);

        return Positioned.fill(
          child: Align(
            alignment: Alignment(x, y),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                TextStyleResolver.displayText(clip.textContent, styleDef),
                textAlign: alignment,
                style: TextStyleResolver.resolve(
                  def: styleDef,
                  fontSize: clip.fontSize.clamp(8.0, 200.0).toDouble(),
                  colorArgb: clip.textColorArgb,
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _VideoSurface extends StatelessWidget {
  final VideoPlayerController controller;

  const _VideoSurface({required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const Center(
        child: CircularProgressIndicator(color: AppTheme.primary),
      );
    }

    return Center(
      child: AspectRatio(
        aspectRatio: controller.value.aspectRatio,
        child: VideoPlayer(controller),
      ),
    );
  }
}

class _TransportBar extends ConsumerWidget {
  final String projectId;

  const _TransportBar({required this.projectId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final previewAsync = ref.watch(previewProvider(projectId));
    final preview = previewAsync.value;
    final controller = preview?.controller;
    final isReady = preview?.hasVideo ?? false;
    final isPlaying = preview?.isPlaying ?? false;
    final position = preview?.position ?? Duration.zero;
    final duration = preview?.duration ?? Duration.zero;

    return Container(
      height: 48,
      color: AppTheme.surface,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          IconButton(
            icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow),
            color: AppTheme.textPrimary,
            onPressed: isReady
                ? () => ref.read(previewProvider(projectId).notifier).togglePlay()
                : null,
          ),
          Text(
            TimeFormatter.formatMs(position.inMilliseconds),
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 12,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
          Expanded(
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                trackHeight: 2,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 12),
                activeTrackColor: AppTheme.primary,
                inactiveTrackColor: AppTheme.border,
                thumbColor: AppTheme.primary,
              ),
              child: Slider(
                value: duration.inMilliseconds == 0
                    ? 0
                    : (position.inMilliseconds / duration.inMilliseconds)
                        .clamp(0.0, 1.0),
                onChanged: isReady
                    ? (v) {
                        final ms = (v * duration.inMilliseconds).round();
                        ref
                            .read(previewProvider(projectId).notifier)
                            .seek(Duration(milliseconds: ms));
                      }
                    : null,
              ),
            ),
          ),
          Text(
            TimeFormatter.formatMs(duration.inMilliseconds),
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 12,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
    );
  }
}

class _EmptyPreview extends StatelessWidget {
  const _EmptyPreview();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.videocam_off_outlined, size: 64, color: AppTheme.textSecondary),
          SizedBox(height: 12),
          Text('Henüz medya yok', style: TextStyle(color: AppTheme.textSecondary)),
          SizedBox(height: 4),
          Text(
            'Araç panelinden medya ekle',
            style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class _ErrorPreview extends StatelessWidget {
  final String message;

  const _ErrorPreview({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48, color: AppTheme.danger),
            const SizedBox(height: 12),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}


extension _FirstOrNullPreview<E> on Iterable<E> {
  E? get firstOrNull {
    final it = iterator;
    if (it.moveNext()) return it.current;
    return null;
  }
}
