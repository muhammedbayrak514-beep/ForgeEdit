import 'dart:io';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/time_formatter.dart';
import '../../../domain/models/clip_model.dart';
import '../../../domain/models/project_model.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../providers/timeline_clock_provider.dart';
import 'clip_thumbnail.dart';

/// Timeline with time ruler, positioned clips, and shared playhead.
///
/// Stage 4:
/// - Clips laid out by timelineStartMs * pixelsPerMs (model-accurate)
/// - Time ruler with second/major ticks
/// - Draggable playhead (updates TimelineClock)
/// - Horizontal scroll for long timelines
/// - Tap clip → select + load preview (unchanged)
///
/// Compact filmstrip style for phone/tablet bottom chrome.
/// Continuous multi-clip playback is handled by PreviewControllerNotifier.
class TimelinePanel extends ConsumerStatefulWidget {
  final String projectId;

  const TimelinePanel({super.key, required this.projectId});

  @override
  ConsumerState<TimelinePanel> createState() => _TimelinePanelState();
}

class _TimelinePanelState extends ConsumerState<TimelinePanel> {
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final editorState = ref.watch(editorProvider(widget.projectId));
    final clock = ref.watch(timelineClockProvider(widget.projectId));
    final selectedId = ref.watch(selectedClipIdProvider(widget.projectId));
    final project = editorState.value;
    final clips = project?.clips ?? [];
    final durationMs = project?.durationMs ?? 0;

    // Extra padding so playhead can sit past last clip
    final contentWidth = _contentWidth(durationMs, clock.pixelsPerMs);

    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(top: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _TimelineHeader(
            projectId: widget.projectId,
            durationMs: durationMs,
            positionMs: clock.positionMs,
          ),
          Expanded(
            child: clips.isEmpty
                ? const Center(
                    child: Text(
                      'Alttan Medya ile klip ekle',
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                  )
                : LayoutBuilder(
                    builder: (context, constraints) {
                      return SingleChildScrollView(
                        controller: _scrollController,
                        scrollDirection: Axis.horizontal,
                        child: SizedBox(
                          width: contentWidth.clamp(
                            constraints.maxWidth,
                            double.infinity,
                          ),
                          height: constraints.maxHeight,
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              // Ruler
                              Positioned(
                                top: 0,
                                left: 0,
                                right: 0,
                                height: 18,
                                child: _TimeRuler(
                                  durationMs: durationMs,
                                  pixelsPerMs: clock.pixelsPerMs,
                                  width: contentWidth,
                                ),
                              ),
                              // Clip track
                              Positioned(
                                top: 28,
                                left: 0,
                                right: 0,
                                bottom: 0,
                                child: _ClipTrack(
                                  projectId: widget.projectId,
                                  clips: clips,
                                  selectedId: selectedId,
                                  pixelsPerMs: clock.pixelsPerMs,
                                  scrollController: _scrollController,
                                  onSelect: (id) {
                                    ref
                                        .read(selectedClipIdProvider(
                                                widget.projectId)
                                            .notifier)
                                        .state = id;
                                  },
                                ),
                              ),
                              // Playhead
                              Positioned(
                                top: 0,
                                bottom: 0,
                                left: clock.positionMs * clock.pixelsPerMs,
                                child: _Playhead(
                                  onDrag: (dx) {
                                    final newMs = (clock.positionMs +
                                            (dx / clock.pixelsPerMs))
                                        .round()
                                        .clamp(0, durationMs > 0 ? durationMs : 0);
                                    ref
                                        .read(timelineClockProvider(
                                                widget.projectId)
                                            .notifier)
                                        .setPosition(newMs);
                                    _seekPreviewToProjectTime(
                                      ref,
                                      widget.projectId,
                                      project,
                                      newMs,
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  double _contentWidth(int durationMs, double pixelsPerMs) {
    final base = durationMs * pixelsPerMs;
    // Minimum comfortable width + trailing space for playhead
    return (base + 120).clamp(400.0, 200000.0);
  }

  /// If playhead falls inside a video clip, seek that clip's controller.
  /// Does not auto-switch selection (avoids surprising jumps). Only seeks
  /// when the currently selected clip contains [projectMs].
  void _seekPreviewToProjectTime(
    WidgetRef ref,
    String projectId,
    ProjectModel? project,
    int projectMs,
  ) {
    if (project == null) return;
    final selectedId = ref.read(selectedClipIdProvider(projectId));
    if (selectedId == null) return;
    final clip = project.clips.where((c) => c.id == selectedId).firstOrNull;
    if (clip == null || clip.type != ClipType.video) return;

    if (projectMs < clip.timelineStartMs || projectMs >= clip.timelineEndMs) {
      return; // outside selected clip – no seek
    }

    final localMs = projectMs - clip.timelineStartMs + clip.trimStartMs;
    ref
        .read(previewProvider(projectId).notifier)
        .seek(Duration(milliseconds: localMs.clamp(0, clip.trimEndMs)));
  }
}

class _TimelineHeader extends ConsumerWidget {
  final String projectId;
  final int durationMs;
  final int positionMs;

  const _TimelineHeader({
    required this.projectId,
    required this.durationMs,
    required this.positionMs,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 2, 4, 0),
      child: Row(
        children: [
          Text(
            '${TimeFormatter.formatMs(positionMs)} / ${TimeFormatter.formatMs(durationMs)}',
            style: const TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 11,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(Icons.zoom_out, size: 20),
            tooltip: 'Uzaklaştır',
            onPressed: () =>
                ref.read(timelineClockProvider(projectId).notifier).zoomOut(),
            visualDensity: VisualDensity.compact,
          ),
          IconButton(
            icon: const Icon(Icons.zoom_in, size: 20),
            tooltip: 'Yakınlaştır',
            onPressed: () =>
                ref.read(timelineClockProvider(projectId).notifier).zoomIn(),
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }
}

class _TimeRuler extends StatelessWidget {
  final int durationMs;
  final double pixelsPerMs;
  final double width;

  const _TimeRuler({
    required this.durationMs,
    required this.pixelsPerMs,
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(width, 18),
      painter: _RulerPainter(
        durationMs: durationMs,
        pixelsPerMs: pixelsPerMs,
      ),
    );
  }
}

class _RulerPainter extends CustomPainter {
  final int durationMs;
  final double pixelsPerMs;

  _RulerPainter({required this.durationMs, required this.pixelsPerMs});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.border
      ..strokeWidth = 1;

    final labelStyle = TextStyle(
      color: AppTheme.textSecondary.withValues(alpha: 0.9),
      fontSize: 10,
    );

    // Major tick every 1s or 5s depending on zoom
    final pxPerSec = pixelsPerMs * 1000;
    final majorEverySec = pxPerSec >= 60 ? 1 : (pxPerSec >= 20 ? 5 : 10);
    final majorMs = majorEverySec * 1000;
    final minorMs = majorEverySec <= 1 ? 200 : 1000;

    final end = durationMs + 5000; // draw a bit past end
    for (var t = 0; t <= end; t += minorMs) {
      final x = t * pixelsPerMs;
      if (x > size.width) break;
      final isMajor = t % majorMs == 0;
      final h = isMajor ? 14.0 : 6.0;
      canvas.drawLine(
        Offset(x, size.height - h),
        Offset(x, size.height),
        paint,
      );
      if (isMajor) {
        final tp = TextPainter(
          text: TextSpan(
            text: TimeFormatter.formatMs(t),
            style: labelStyle,
          ),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, Offset(x + 2, 2));
      }
    }

    // Baseline
    canvas.drawLine(
      Offset(0, size.height - 0.5),
      Offset(size.width, size.height - 0.5),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _RulerPainter old) =>
      old.durationMs != durationMs || old.pixelsPerMs != pixelsPerMs;
}

class _ClipTrack extends ConsumerWidget {
  final String projectId;
  final List<ClipModel> clips;
  final String? selectedId;
  final double pixelsPerMs;
  final ScrollController scrollController;
  final void Function(String id) onSelect;

  const _ClipTrack({
    required this.projectId,
    required this.clips,
    required this.selectedId,
    required this.pixelsPerMs,
    required this.scrollController,
    required this.onSelect,
  });

  List<ClipModel> get _videoOrdered =>
      clips.where((c) => c.trackIndex == TrackIndex.video).toList()
        ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));

  Future<void> _dropReorder(WidgetRef ref, String fromId, String ontoId) async {
    if (fromId == ontoId) return;
    final video = _videoOrdered;
    final from = video.indexWhere((c) => c.id == fromId);
    final onto = video.indexWhere((c) => c.id == ontoId);
    if (from < 0 || onto < 0) return;
    await ref.read(editorProvider(projectId).notifier).reorderMainClip(
          fromId,
          onto,
        );
    ref.read(selectedClipIdProvider(projectId).notifier).state = fromId;
  }

  Future<void> _moveToX(
    WidgetRef ref,
    String clipId,
    double localXInContent,
  ) async {
    final ms = (localXInContent / pixelsPerMs).round().clamp(0, 24 * 3600 * 1000);
    await ref.read(editorProvider(projectId).notifier).moveClipToTime(clipId, ms);
    ref.read(selectedClipIdProvider(projectId).notifier).state = clipId;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Stack(
      children: [
        for (final clip in clips)
          Positioned(
            left: clip.timelineStartMs * pixelsPerMs,
            width: (clip.durationMs * pixelsPerMs).clamp(24.0, 100000.0),
            top: 8,
            bottom: 8,
            child: _ClipBlock(
              clip: clip,
              selected: clip.id == selectedId,
              onTap: () => onSelect(clip.id),
              // Video/image on main track: reorder by dropping onto another
              reorderable: clip.trackIndex == TrackIndex.video &&
                  (clip.type == ClipType.video || clip.type == ClipType.image),
              // Audio + text: free horizontal placement on the timeline
              freePlaceable:
                  clip.type == ClipType.audio || clip.type == ClipType.text,
              onAcceptReorder: (fromId) => _dropReorder(ref, fromId, clip.id),
              onFreePlaceEnd: (globalOffset, blockWidth) {
                final box = context.findRenderObject() as RenderBox?;
                if (box == null || !box.hasSize) return;
                final local = box.globalToLocal(globalOffset);
                final scroll = scrollController.hasClients
                    ? scrollController.offset
                    : 0.0;
                // Feedback top-left → approximate center of dragged block
                final contentX = local.dx + scroll + (blockWidth / 2);
                _moveToX(ref, clip.id, contentX);
              },
            ),
          ),
      ],
    );
  }
}

class _ClipBlock extends StatelessWidget {
  final ClipModel clip;
  final bool selected;
  final VoidCallback onTap;
  final bool reorderable;
  final bool freePlaceable;
  final void Function(String fromId)? onAcceptReorder;
  final void Function(Offset globalOffset, double blockWidth)? onFreePlaceEnd;

  const _ClipBlock({
    required this.clip,
    required this.selected,
    required this.onTap,
    this.reorderable = false,
    this.freePlaceable = false,
    this.onAcceptReorder,
    this.onFreePlaceEnd,
  });

  @override
  Widget build(BuildContext context) {
    final Color baseColor;
    switch (clip.type) {
      case ClipType.video:
      case ClipType.image:
        baseColor = AppTheme.primary;
        break;
      case ClipType.audio:
        baseColor = AppTheme.accent;
        break;
      case ClipType.text:
        baseColor = AppTheme.warning;
        break;
    }

    final isVisual =
        clip.type == ClipType.video || clip.type == ClipType.image;

    final body = GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: baseColor.withValues(alpha: selected ? 0.35 : 0.18),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: selected ? baseColor : baseColor.withValues(alpha: 0.5),
            width: selected ? 2 : 1,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Filmstrip fill
            if (isVisual)
              Positioned.fill(
                child: ClipThumbnail(
                  clip: clip,
                  width: 400,
                  height: 80,
                  borderRadius: BorderRadius.zero,
                ),
              )
            else
              Positioned.fill(
                child: ClipThumbnail(clip: clip, width: 400, height: 80),
              ),
            // Gradient for readable label
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              height: 22,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.75),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              left: 4,
              right: 4,
              bottom: 3,
              child: Text(
                clip.displayName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 9,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
            if (clip.type == ClipType.video)
              const Positioned(
                top: 3,
                left: 3,
                child: Icon(Icons.play_arrow, size: 12, color: Colors.white70),
              ),
          ],
        ),
      ),
    );

    if (!reorderable && !freePlaceable) return body;

    Widget draggableChild = body;

    if (freePlaceable) {
      draggableChild = LongPressDraggable<String>(
        data: 'place:${clip.id}',
        delay: const Duration(milliseconds: 180),
        feedback: Material(
          color: Colors.transparent,
          elevation: 6,
          child: SizedBox(
            width: 80,
            height: 48,
            child: Opacity(opacity: 0.9, child: body),
          ),
        ),
        childWhenDragging: Opacity(opacity: 0.35, child: body),
        onDragEnd: (details) {
          onFreePlaceEnd?.call(details.offset, 80);
        },
        child: body,
      );
    }

    if (!reorderable) return draggableChild;

    return DragTarget<String>(
      onWillAcceptWithDetails: (d) {
        final data = d.data;
        if (data.startsWith('place:')) return false;
        return data != clip.id;
      },
      onAcceptWithDetails: (d) {
        if (d.data.startsWith('place:')) return;
        onAcceptReorder?.call(d.data);
      },
      builder: (context, candidate, rejected) {
        final highlight = candidate.isNotEmpty;
        final child = LongPressDraggable<String>(
          data: clip.id,
          delay: const Duration(milliseconds: 180),
          feedback: Material(
            color: Colors.transparent,
            elevation: 6,
            child: SizedBox(
              width: 72,
              height: 48,
              child: Opacity(opacity: 0.9, child: body),
            ),
          ),
          childWhenDragging: Opacity(opacity: 0.35, child: body),
          child: draggableChild,
        );
        if (!highlight) return child;
        return DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: AppTheme.accent, width: 2),
          ),
          child: child,
        );
      },
    );
  }
}

class _Playhead extends StatelessWidget {
  final void Function(double dx) onDrag;

  const _Playhead({required this.onDrag});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onHorizontalDragUpdate: (d) => onDrag(d.delta.dx),
      child: SizedBox(
        width: 20,
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            // Vertical line
            Positioned(
              top: 0,
              bottom: 0,
              child: Container(
                width: 2,
                color: AppTheme.playhead,
              ),
            ),
            // Head handle
            Positioned(
              top: 0,
              child: CustomPaint(
                size: const Size(12, 10),
                painter: _PlayheadHeadPainter(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlayheadHeadPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, Paint()..color = AppTheme.playhead);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
