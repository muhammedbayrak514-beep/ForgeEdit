import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/services/export_service.dart';
import '../../../domain/export/export_plan.dart';
import '../../providers/editor_provider.dart';

class ExportScreen extends ConsumerStatefulWidget {
  final String projectId;

  const ExportScreen({super.key, required this.projectId});

  @override
  ConsumerState<ExportScreen> createState() => _ExportScreenState();
}

class _ExportScreenState extends ConsumerState<ExportScreen> {
  final _service = ExportService();
  ExportSettings _settings = const ExportSettings();
  ExportProgress? _progress;
  bool _running = false;

  Future<void> _start() async {
    if (_service.isBusy || _running) return;
    final project = ref.read(editorProvider(widget.projectId)).value;
    if (project == null) return;

    setState(() {
      _running = true;
      _progress = const ExportProgress(
        phase: ExportPhase.validating,
        message: 'Başlatılıyor…',
      );
    });

    final result = await _service.export(
      project: project,
      settings: _settings,
      onProgress: (p) {
        if (mounted) setState(() => _progress = p);
      },
    );

    if (mounted) {
      setState(() {
        _progress = result;
        _running = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final project = ref.watch(editorProvider(widget.projectId)).value;
    final p = _progress;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Dışa Aktar'),
        actions: [
          if (_running)
            TextButton(
              onPressed: () => _service.requestCancel(),
              child: const Text('İptal'),
            ),
        ],
      ),
      body: project == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Text(
                  project.name,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                Text(
                  'Motor: FFmpeg (ffmpeg_kit_flutter_new) · libx264 · MP4\n'
                  'Geçişler: kesme (concat). crossfade/fadeBlack henüz xfade ile uygulanmıyor.\n'
                  'wipeLeft desteklenmiyor.',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 20),
                const Text('Çözünürlük',
                    style: TextStyle(fontWeight: FontWeight.w600)),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final res in [
                      (1280, 720),
                      (1920, 1080),
                      (854, 480),
                    ])
                      ChoiceChip(
                        label: Text('${res.$1}×${res.$2}'),
                        selected: _settings.width == res.$1,
                        onSelected: _running
                            ? null
                            : (_) => setState(() {
                                  _settings = ExportSettings(
                                    width: res.$1,
                                    height: res.$2,
                                    fps: _settings.fps,
                                  );
                                }),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                const Text('FPS', style: TextStyle(fontWeight: FontWeight.w600)),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final fps in [24, 30])
                      ChoiceChip(
                        label: Text('$fps'),
                        selected: _settings.fps == fps,
                        onSelected: _running
                            ? null
                            : (_) => setState(() {
                                  _settings = ExportSettings(
                                    width: _settings.width,
                                    height: _settings.height,
                                    fps: fps,
                                  );
                                }),
                      ),
                  ],
                ),
                const SizedBox(height: 24),
                if (p != null) ...[
                  Text(p.message),
                  if (p.fraction != null) ...[
                    const SizedBox(height: 8),
                    LinearProgressIndicator(value: p.fraction),
                    Text('${(p.fraction! * 100).toStringAsFixed(0)}%'),
                  ] else if (_running)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: LinearProgressIndicator(),
                    ),
                  if (p.outputPath != null) ...[
                    const SizedBox(height: 12),
                    SelectableText(
                      'Dosya: ${p.outputPath}',
                      style: const TextStyle(color: AppTheme.accent),
                    ),
                  ],
                  if (p.error != null) ...[
                    const SizedBox(height: 8),
                    Text(p.error!, style: const TextStyle(color: AppTheme.danger)),
                  ],
                  if (p.warnings.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    ...p.warnings.map(
                      (w) => Text(w, style: const TextStyle(color: AppTheme.warning, fontSize: 12)),
                    ),
                  ],
                  const SizedBox(height: 16),
                ],
                ElevatedButton.icon(
                  onPressed: _running ? null : _start,
                  icon: const Icon(Icons.file_upload_outlined),
                  label: Text(_running ? 'İşleniyor…' : 'MP4 Olarak Dışa Aktar'),
                ),
              ],
            ),
    );
  }
}
