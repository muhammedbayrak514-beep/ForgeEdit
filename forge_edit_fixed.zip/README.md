# ForgeEdit (stage9_fixed)

Flutter Android tablet editor. Package `com.forgeedit.app`.

## Fixes in this build

- Export cancel via `executeAsync` + live session id + `FFmpegKit.cancel`
- No `-shortest` on audio mix (video length preserved with apad/atrim/`-t`)
- Partial output cleanup on cancel/fail
- Single export at a time (`isBusy`)
- Text overlay: system font probe + explicit warning if drawtext fails
- Multi-audio: only first track mixed (warning, not silent success)
- Save serialization with generation counter (no lost newer state)

## Build

```bash
flutter pub get && flutter test && flutter build apk --release
```

No Flutter SDK in the packaging environment — run tests on your machine.

## Sprint C

- Text styles mapped to FFmpeg drawtext (uppercase, color, shadow, bold font)
- Bundled Roboto Regular/Bold in `assets/fonts/`
- Multi-audio mix (all audio clips + original video audio)
- ABI splits: armeabi-v7a, arm64-v8a, x86_64 (+ universal APK)

```bash
flutter test
flutter build apk --release
# or smaller installs:
flutter build apk --release --split-per-abi
```
