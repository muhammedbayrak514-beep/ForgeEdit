# ForgeEdit

Flutter Android video editor (`com.forgeedit.app`).

## Requirements

- Flutter stable (SDK >= 3.5)
- Android SDK / NDK (Flutter ships defaults)
- Java 17 for Gradle

## Local build

```bash
flutter pub get
flutter test
flutter build apk --release
# smaller installs:
flutter build apk --release --split-per-abi
```

APK path: `build/app/outputs/flutter-apk/`

## GitHub Actions

Workflow: `.github/workflows/android-apk.yml`

- Triggers: push/PR to `main`/`master`, or manual **workflow_dispatch**
- `flutter pub get` → `flutter test` → `flutter build apk --release`
- Uploads all `*.apk` under `flutter-apk/` as artifact **forge-edit-release-apk**

### Signing (optional on CI)

Release signing uses `android/key.properties` + `.jks` **only if present**.

**Do not commit** these files (already in `.gitignore`):

- `*.jks` / `*.keystore`
- `key.properties`

Without them, CI signs with the **debug** keystore (fine for testing, not Play Store).

For Play Store later: store keystore in GitHub Secrets and write `key.properties` in a workflow step.

## Project layout

- `lib/` — Flutter app (editor, templates, export)
- `android/` — Gradle / manifest
- `test/` — unit tests
- `assets/fonts/` — Roboto for export drawtext

## Notes

- FFmpeg via `ffmpeg_kit_flutter_new` (APK size is large ~100MB+)
- Min SDK 24
