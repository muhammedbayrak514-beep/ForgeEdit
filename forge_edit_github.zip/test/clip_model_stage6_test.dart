import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/domain/models/clip_model.dart';
import 'package:forge_edit/domain/models/project_model.dart';
import 'package:forge_edit/domain/timeline_ops.dart';

void main() {
  group('ClipModel text JSON backward compat', () {
    test('old video json without text fields loads', () {
      final json = {
        'id': '1',
        'type': 'video',
        'filePath': '/a.mp4',
        'displayName': 'a',
        'sourceDurationMs': 1000,
        'trimStartMs': 0,
        'trimEndMs': 1000,
        'timelineStartMs': 0,
        'trackIndex': 0,
      };
      final c = ClipModel.fromJson(json);
      expect(c.type, ClipType.video);
      expect(c.textContent, '');
      expect(c.fontSize, 32);
      expect(c.trackIndex, 0);
    });

    test('text clip roundtrip', () {
      final t = ClipModel.text(
        content: 'Merhaba',
        durationMs: 5000,
        timelineStartMs: 1000,
        fontSize: 40,
        textColorArgb: 0xFFFF0000,
      );
      final again = ClipModel.fromJson(t.toJson());
      expect(again.textContent, 'Merhaba');
      expect(again.trackIndex, TrackIndex.text);
      expect(again.durationMs, 5000);
      expect(again.fontSize, 40);
      expect(again.filePath, '');
    });
  });

  group('packMainTrack leaves audio/text', () {
    test('audio and text positions unchanged', () {
      final video = ClipModel.fromImportedMedia(
        filePath: '/v.mp4',
        displayName: 'v',
        type: ClipType.video,
        sourceDurationMs: 5000,
        timelineStartMs: 0,
      );
      final audio = ClipModel.fromImportedMedia(
        filePath: '/a.mp3',
        displayName: 'a',
        type: ClipType.audio,
        sourceDurationMs: 8000,
        timelineStartMs: 2000,
        trackIndex: TrackIndex.audio,
      );
      final text = ClipModel.text(
        content: 'Hi',
        durationMs: 3000,
        timelineStartMs: 1500,
      );
      final p = ProjectModel.create().copyWith(clips: [video, audio, text]);
      // Delete video causes pack - audio/text must stay
      final after = TimelineOps.deleteClip(project: p, clipId: video.id);
      final a = after.clips.firstWhere((c) => c.type == ClipType.audio);
      final tx = after.clips.firstWhere((c) => c.type == ClipType.text);
      expect(a.timelineStartMs, 2000);
      expect(tx.timelineStartMs, 1500);
    });
  });

  group('split with speed', () {
    test('source split accounts for speed 2.0', () {
      // 10s source, speed 2 → 5s on timeline
      final c = ClipModel(
        id: 'x',
        type: ClipType.video,
        filePath: '/x.mp4',
        displayName: 'x',
        sourceDurationMs: 10000,
        trimStartMs: 0,
        trimEndMs: 10000,
        timelineStartMs: 0,
        speed: 2.0,
      );
      expect(c.durationMs, 5000);
      final p = ProjectModel.create().copyWith(clips: [c]);
      // Split at 2500ms timeline → source should be 5000ms
      final next = TimelineOps.splitClip(
        project: p,
        clipId: 'x',
        projectTimeMs: 2500,
      );
      expect(next, isNotNull);
      final left = next!.clips.firstWhere((c) => c.id == 'x');
      final right = next.clips.firstWhere((c) => c.id != 'x');
      expect(left.trimEndMs, 5000);
      expect(right.trimStartMs, 5000);
      expect(left.durationMs + right.durationMs, 5000);
    });
  });

  group('project json roundtrip with mixed tracks', () {
    test('save load preserves all', () {
      final clips = [
        ClipModel.fromImportedMedia(
          filePath: '/v.mp4',
          displayName: 'v',
          type: ClipType.video,
          sourceDurationMs: 3000,
          timelineStartMs: 0,
        ),
        ClipModel.fromImportedMedia(
          filePath: '/a.mp3',
          displayName: 'song',
          type: ClipType.audio,
          sourceDurationMs: 6000,
          timelineStartMs: 500,
          trackIndex: TrackIndex.audio,
        ).copyWith(volume: 0.5),
        ClipModel.text(content: 'Title', durationMs: 2000, timelineStartMs: 0),
      ];
      final p = ProjectModel.create(name: 'mix').copyWith(clips: clips);
      final loaded = ProjectModel.fromJson(p.toJson());
      expect(loaded.clips.length, 3);
      expect(loaded.clips.where((c) => c.type == ClipType.audio).first.volume, 0.5);
      expect(loaded.clips.where((c) => c.type == ClipType.text).first.textContent, 'Title');
    });
  });
}
