#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "==> ForgeEdit APK build"
command -v flutter >/dev/null || { echo "Flutter SDK bulunamadı. https://docs.flutter.dev/get-started/install"; exit 1; }

flutter --version
flutter pub get
flutter analyze --no-fatal-infos || true
flutter test || true

echo "==> Building release APK (arm64 + armeabi-v7a)..."
flutter build apk --release

APK="build/app/outputs/flutter-apk/app-release.apk"
if [[ -f "$APK" ]]; then
  SIZE=$(du -h "$APK" | cut -f1)
  echo ""
  echo "BAŞARILI: $APK ($SIZE)"
  echo "Tablete kopyala ve kur:"
  echo "  adb install -r $APK"
  echo "veya dosya yöneticisi ile aç (bilinmeyen kaynaklara izin ver)."
else
  echo "APK bulunamadı — build logunu kontrol et."
  exit 1
fi
