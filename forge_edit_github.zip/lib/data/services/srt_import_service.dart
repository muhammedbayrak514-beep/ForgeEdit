import 'dart:io';

import 'package:uuid/uuid.dart';

import '../../domain/models/clip_model.dart';

class SrtCue {
  final int startMs;
  final int endMs;
  final String text;
  SrtCue({required this.startMs, required this.endMs, required this.text});
}

class SrtImportService {
  static final _uuid = Uuid();

  /// Parse classic SRT content into cues.
  static List<SrtCue> parse(String content) {
    final cues = <SrtCue>[];
    final blocks = content.replaceAll('\r\n', '\n').split(RegExp(r'\n\s*\n'));
    for (final block in blocks) {
      final lines = block.trim().split('\n');
      if (lines.length < 2) continue;
      // Find time line
      var timeIdx = 0;
      if (RegExp(r'^\d+$').hasMatch(lines[0].trim())) {
        timeIdx = 1;
      }
      if (timeIdx >= lines.length) continue;
      final timeLine = lines[timeIdx];
      final m = RegExp(
        r'(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})',
      ).firstMatch(timeLine);
      if (m == null) continue;
      final start = _toMs(m, 1);
      final end = _toMs(m, 5);
      final text = lines.skip(timeIdx + 1).join('\n').trim();
      if (text.isEmpty || end <= start) continue;
      cues.add(SrtCue(startMs: start, endMs: end, text: text));
    }
    return cues;
  }

  static int _toMs(RegExpMatch m, int i) {
    final h = int.parse(m.group(i)!);
    final min = int.parse(m.group(i + 1)!);
    final s = int.parse(m.group(i + 2)!);
    final ms = int.parse(m.group(i + 3)!);
    return ((h * 3600 + min * 60 + s) * 1000) + ms;
  }

  static List<ClipModel> cuesToTextClips(List<SrtCue> cues) {
    return cues.map((c) {
      final dur = (c.endMs - c.startMs).clamp(100, 60000);
      final label =
          c.text.length > 24 ? '${c.text.substring(0, 24)}…' : c.text;
      return ClipModel.text(
        content: c.text.replaceAll('\n', ' '),
        durationMs: dur,
        timelineStartMs: c.startMs,
        fontSize: 28,
        posY: 0.88,
        textStyleId: 'plain_white',
      ).copyWith(
        displayName: label,
        textAnimId: 'fadeIn',
      );
    }).toList();
  }

  static Future<List<ClipModel>> importFile(String path) async {
    final content = await File(path).readAsString();
    final cues = parse(content);
    return cuesToTextClips(cues);
  }
}
