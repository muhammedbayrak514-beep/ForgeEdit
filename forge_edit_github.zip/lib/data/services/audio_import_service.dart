import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../../core/constants/app_constants.dart';
import '../../domain/models/clip_model.dart';
import '../repositories/project_repository.dart';

/// Copies a user-selected audio file into the project media folder.
class AudioImportService {
  final ProjectRepository _projectRepo;
  static const _uuid = Uuid();

  static const supportedAudio = ['mp3', 'm4a', 'aac', 'wav', 'ogg', 'flac'];

  AudioImportService(this._projectRepo);

  /// [sourcePath] is a local path the app can read (from file_picker / photo_manager).
  Future<ClipModel?> importAudioFile({
    required String projectId,
    required String sourcePath,
    required String displayName,
    required int timelineStartMs,
    int? durationMs,
  }) async {
    final file = File(sourcePath);
    if (!await file.exists()) return null;

    final ext = p.extension(sourcePath).toLowerCase().replaceFirst('.', '');
    if (ext.isEmpty || !supportedAudio.contains(ext)) {
      throw FormatException(
        'Desteklenmeyen ses biçimi: .$ext. Desteklenen: ${supportedAudio.join(", ")}',
      );
    }

    final size = await file.length();
    if (size == 0) throw const FormatException('Ses dosyası boş');

    final mediaDir = await _projectRepo.mediaDir(projectId);
    final id = _uuid.v4();
    final dest = p.join(mediaDir.path, '$id.$ext');
    await file.copy(dest);

    // Duration: caller may pass from metadata; fallback 30s until probed later
    final srcDur = (durationMs != null && durationMs > 0) ? durationMs : 30000;

    return ClipModel.fromImportedMedia(
      filePath: dest,
      displayName: displayName,
      type: ClipType.audio,
      sourceDurationMs: srcDur,
      timelineStartMs: timelineStartMs,
      trackIndex: TrackIndex.audio,
    );
  }
}
