import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';
import 'package:photo_manager/photo_manager.dart';

/// Result of saving a finished export into the system gallery.
class GallerySaveResult {
  final bool success;
  final String? galleryPath;
  final String? assetId;
  final String? error;

  const GallerySaveResult.ok({this.galleryPath, this.assetId})
      : success = true,
        error = null;

  const GallerySaveResult.fail(this.error)
      : success = false,
        galleryPath = null,
        assetId = null;
}

/// Saves exported MP4 files into the device gallery (MediaStore / Photos).
///
/// Export itself writes only to app-private storage. Without this step the
/// user never sees the file in Gallery / Google Photos.
class GallerySaveService {
  /// Ensure we can write into the shared media collection.
  static Future<bool> ensureWriteAccess() async {
    if (Platform.isAndroid) {
      // Android 13+
      final videos = await Permission.videos.status;
      if (videos.isDenied) {
        final r = await Permission.videos.request();
        if (!r.isGranted && !r.isLimited && !r.isRestricted) {
          // Still try MediaStore insert — often works without explicit grant
          // when the app creates its own media entry.
        }
      }
      // Legacy
      final storage = await Permission.storage.status;
      if (storage.isDenied) {
        await Permission.storage.request();
      }
    }
    // photo_manager permission helps on some OEMs
    final pm = await PhotoManager.requestPermissionExtend(
      requestOption: const PermissionRequestOption(
        androidPermission: AndroidPermission(
          type: RequestType.video,
          mediaLocation: false,
        ),
      ),
    );
    return pm.isAuth || pm.hasAccess || Platform.isAndroid;
  }

  /// Copy [filePath] into the public gallery as an MP4 video.
  static Future<GallerySaveResult> saveVideoToGallery({
    required String filePath,
    String? title,
  }) async {
    final file = File(filePath);
    if (!await file.exists()) {
      return const GallerySaveResult.fail('Dışa aktarılan dosya bulunamadı');
    }
    final len = await file.length();
    if (len == 0) {
      return const GallerySaveResult.fail('Dışa aktarılan dosya boş');
    }

    await ensureWriteAccess();

    final baseName = title?.trim().isNotEmpty == true
        ? title!.trim()
        : p.basenameWithoutExtension(filePath);

    try {
      // Title should look like a real media name; relativePath puts it under
      // Movies/ForgeEdit on Android 10+ (MediaStore RELATIVE_PATH).
      final safeTitle = baseName.toLowerCase().endsWith('.mp4')
          ? baseName
          : '$baseName.mp4';

      final entity = await PhotoManager.editor.saveVideo(
        file,
        title: safeTitle,
        desc: 'ForgeEdit export',
        relativePath: 'Movies/ForgeEdit',
      );

      if (entity == null) {
        return const GallerySaveResult.fail(
          'Galeri kaydı başarısız (null asset). İzinleri kontrol et.',
        );
      }

      // Resolve a user-visible path when possible
      String? visiblePath;
      try {
        final f = await entity.file;
        visiblePath = f?.path;
      } catch (_) {}

      return GallerySaveResult.ok(
        assetId: entity.id,
        galleryPath: visiblePath,
      );
    } catch (e) {
      return GallerySaveResult.fail('Galeriye kaydedilemedi: $e');
    }
  }
}
