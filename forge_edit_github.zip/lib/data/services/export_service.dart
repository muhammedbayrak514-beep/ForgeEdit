import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_session.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:ffmpeg_kit_flutter_new/statistics.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../domain/export/export_plan.dart';
import '../../domain/export/export_error_messages.dart';
import '../../domain/export/export_text_style.dart';
import '../../domain/models/clip_model.dart';
import '../../domain/models/project_model.dart';

enum ExportPhase {
  validating,
  encodingSegments,
  concatenating,
  applyingText,
  mixingAudio,
  done,
  failed,
  cancelled,
}

class ExportProgress {
  final ExportPhase phase;
  final String message;
  /// 0–1 when statistics available; null if unknown (no fake %)
  final double? fraction;
  final String? outputPath;
  final String? error;
  final List<String> warnings;

  const ExportProgress({
    required this.phase,
    required this.message,
    this.fraction,
    this.outputPath,
    this.error,
    this.warnings = const [],
  });
}

/// Real MP4 export via ffmpeg_kit_flutter_new.
///
/// Cancel: uses [FFmpegKit.executeAsync] so session id is known while running,
/// then [FFmpegKit.cancel].
class ExportService {
  bool _cancelRequested = false;
  int? _currentSessionId;
  bool _busy = false;
  final List<String> _warnings = [];

  bool get isBusy => _busy;

  void requestCancel() {
    _cancelRequested = true;
    final id = _currentSessionId;
    if (id != null) {
      FFmpegKit.cancel(id);
    } else {
      // Cancel all sessions if id not yet assigned
      FFmpegKit.cancel();
    }
  }

  String _vencode(ExportSettings settings) {
    final codec = settings.videoCodec;
    final q = settings.x264Params;
    if (codec.contains('x264') || codec == 'libx264') {
      return '-c:v $codec -pix_fmt yuv420p $q';
    }
    return '-c:v $codec -pix_fmt yuv420p';
  }

  Future<ExportProgress> export({
    required ProjectModel project,
    required void Function(ExportProgress) onProgress,
    ExportSettings settings = const ExportSettings(),
  }) async {
    if (_busy) {
      return const ExportProgress(
        phase: ExportPhase.failed,
        message: 'Zaten bir dışa aktarma çalışıyor',
        error: 'Başka bir export bitene kadar bekleyin',
      );
    }
    _busy = true;
    _cancelRequested = false;
    _warnings.clear();
    _currentSessionId = null;

    Directory? workDir;
    String? outputPath;

    try {
      onProgress(const ExportProgress(
        phase: ExportPhase.validating,
        message: 'Doğrulanıyor…',
      ));

      final plan = await ExportPlan.build(project, settings: settings);
      if (!plan.canExport) {
        final msg = plan.issues.map((e) => e.message).join('\n');
        return ExportProgress(
          phase: ExportPhase.failed,
          message: 'Doğrulama başarısız',
          error: msg.isEmpty ? 'Proje dışa aktarılamaz' : msg,
        );
      }

      final docs = await getApplicationDocumentsDirectory();
      final exportDir = Directory(p.join(docs.path, 'forge_edit_exports'));
      if (!await exportDir.exists()) await exportDir.create(recursive: true);

      workDir = Directory(p.join(docs.path, 'forge_edit_work', project.id));
      if (await workDir.exists()) {
        await workDir.delete(recursive: true);
      }
      await workDir.create(recursive: true);

      final stamp = DateTime.now().millisecondsSinceEpoch;
      final safeName =
          project.name.replaceAll(RegExp(r'[^\w\-.]'), '_');
      outputPath = p.join(exportDir.path, 'forgeedit_${safeName}_$stamp.mp4');

      // Use real timeline extent (max end), not sum of clip durations
      final totalDurationMs =
          plan.timelineDurationMs > 0 ? plan.timelineDurationMs : 3000;

      // 1) Segments
      final segmentPaths = <String>[];
      final segCmds = plan.buildSegmentCommands(
        workDir: workDir.path,
        segmentPathsOut: segmentPaths,
      );

      for (var i = 0; i < segCmds.length; i++) {
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        onProgress(ExportProgress(
          phase: ExportPhase.encodingSegments,
          message: 'Klip ${i + 1}/${segCmds.length} kodlanıyor…',
          fraction: segCmds.isEmpty ? null : i / segCmds.length,
        ));

        final ok = await _runAsync(
          segCmds[i],
          onStats: (s) {
            final t = s.getTime();
            final dur = plan.videoTrack[i].durationMs;
            if (t > 0 && dur > 0) {
              final local = (t / dur).clamp(0.0, 1.0);
              onProgress(ExportProgress(
                phase: ExportPhase.encodingSegments,
                message: 'Klip ${i + 1}/${segCmds.length}…',
                fraction: (i + local) / segCmds.length,
              ));
            }
          },
        );
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        if (!ok) {
          await _cleanupPartial(outputPath, workDir);
          return ExportProgress(
            phase: ExportPhase.failed,
            message: 'Klip kodlama başarısız',
            error: 'Segment $i FFmpeg hatası',
          );
        }
        final segFile = File(segmentPaths[i]);
        if (!await segFile.exists() || await segFile.length() == 0) {
          await _cleanupPartial(outputPath, workDir);
          return ExportProgress(
            phase: ExportPhase.failed,
            message: 'Segment dosyası boş veya yok',
            error: segmentPaths[i],
          );
        }
        // Guarantee stereo AAC so concat never mixes A/V stream layouts
        final ensured = await _ensureSegmentHasAudio(
          segmentPaths[i],
          durationMs: plan.videoTrack[i].durationMs,
        );
        if (!ensured) {
          await _cleanupPartial(outputPath, workDir);
          return ExportProgress(
            phase: ExportPhase.failed,
            message: 'Segment ses akışı oluşturulamadı',
            error: segmentPaths[i],
          );
        }
      }

      // 2) Concat
      if (_cancelRequested) {
        await _cleanupPartial(outputPath, workDir);
        return const ExportProgress(
          phase: ExportPhase.cancelled,
          message: 'İptal edildi',
        );
      }
      onProgress(const ExportProgress(
        phase: ExportPhase.concatenating,
        message: 'Birleştiriliyor…',
      ));

      var currentVideo = p.join(workDir.path, 'concat.mp4');
      if (segmentPaths.length == 1) {
        await File(segmentPaths.first).copy(currentVideo);
      } else if (segmentPaths.isEmpty) {
        final durSec = (totalDurationMs / 1000.0).clamp(0.5, 3600.0);
        final blackCmd =
            '-f lavfi -i color=c=black:s=${settings.width}x${settings.height}:d=${durSec.toStringAsFixed(2)} '
            '${_vencode(settings)} -y "$currentVideo"';
        if (!await _runAsync(blackCmd)) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.failed,
            message: 'Boş video oluşturulamadı',
            error: 'lavfi color failed',
          );
        }
      } else {
        final merged = await _mergeSegments(
          segmentPaths: segmentPaths,
          videoTrack: plan.videoTrack,
          settings: settings,
          workDir: workDir.path,
          outputPath: currentVideo,
        );
        if (merged == null || _cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return ExportProgress(
            phase: _cancelRequested
                ? ExportPhase.cancelled
                : ExportPhase.failed,
            message: _cancelRequested ? 'İptal edildi' : 'Birleştirme başarısız',
            error: _cancelRequested ? null : 'merge/xfade failed',
          );
        }
        currentVideo = merged;
      }

      // 3) Text
      final draw = plan.buildDrawtextFilter();
      if (draw != null && draw.isNotEmpty) {
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        onProgress(const ExportProgress(
          phase: ExportPhase.applyingText,
          message: 'Metin ekleniyor…',
        ));
        final withText = p.join(workDir.path, 'with_text.mp4');
        final fonts = await _resolveFontFiles();
        final textVf = plan.buildDrawtextFilter(
              fontFileRegular: fonts.regular,
              fontFileBold: fonts.bold,
            ) ??
            draw;
        // Keep existing audio (-map 0:a?); do not use -an
        final textCmd =
            '-i "$currentVideo" -vf "$textVf" '
            '-map 0:v:0 -map 0:a? '
            '${_vencode(settings)} '
            '-c:a aac -b:a 128k -y "$withText"';
        final ok = await _runAsync(textCmd);
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        if (ok && await File(withText).exists() && await File(withText).length() > 0) {
          currentVideo = withText;
        } else {
          _warnings.add(
            'Metin overlay uygulanamadı (font veya drawtext hatası). '
            'Video metinsiz kaydedildi.',
          );
        }
      }

      // 3b) Picture-in-picture overlays
      if (plan.overlayTrack.isNotEmpty) {
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        onProgress(const ExportProgress(
          phase: ExportPhase.applyingText,
          message: 'PiP katmanı ekleniyor…',
        ));
        var base = currentVideo;
        for (var i = 0; i < plan.overlayTrack.length; i++) {
          final o = plan.overlayTrack[i];
          final out = p.join(workDir.path, 'pip_$i.mp4');
          final startSec = (o.timelineStartMs / 1000.0).toStringAsFixed(3);
          final durSec = (o.durationMs / 1000.0).clamp(0.1, 3600.0).toStringAsFixed(3);
          final ss = (o.trimStartMs / 1000.0).toStringAsFixed(3);
          final scale = o.scale.clamp(0.1, 1.0);
          final w = (settings.width * scale).round();
          // Position from normalized pos (0-1 center) → top-left px
          final x = ((o.posX - scale / 2) * settings.width).round().clamp(0, settings.width);
          final y = ((o.posY - scale / 2) * settings.height).round().clamp(0, settings.height);
          final enable =
              "between(t\\,$startSec\\,${(o.timelineStartMs + o.durationMs) / 1000.0})";
          // Simpler: overlay for entire pip duration with setpts offset
          final cmd =
              '-i "$base" -ss $ss -t $durSec -i "${o.filePath}" '
              '-filter_complex "'
              '[1:v]scale=$w:-2,setpts=PTS-STARTPTS+${startSec}/TB[ov];'
              '[0:v][ov]overlay=$x:$y:eof_action=pass[vout]" '
              '-map "[vout]" -map 0:a? '
              '${_vencode(settings)} -c:a aac -b:a 128k '
              '-t ${(totalDurationMs/1000.0).toStringAsFixed(3)} -y "$out"';
          final ok = await _runAsync(cmd);
          if (ok && await File(out).exists() && await File(out).length() > 0) {
            base = out;
          } else {
            _warnings.add('PiP uygulanamadı: ${o.displayName}');
          }
        }
        currentVideo = base;
      }

      // 4) Audio — do NOT use -shortest (would cut video early)
      if (plan.audioTrack.isNotEmpty) {
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        onProgress(const ExportProgress(
          phase: ExportPhase.mixingAudio,
          message: 'Ses ekleniyor…',
        ));
        final mixed = p.join(workDir.path, 'mixed.mp4');
        final videoDurSec =
            (totalDurationMs / 1000.0).clamp(0.1, 3600.0);
        final videoDurStr = videoDurSec.toStringAsFixed(3);
        final audios = plan.audioTrack;

        // -i video + each audio file
        final inputs = StringBuffer('-i "$currentVideo"');
        for (final a in audios) {
          inputs.write(' -i "${a.filePath}"');
        }

        final fc = ExportAudioMix.build(
          clips: audios,
          videoDurSec: videoDurSec,
        );
        final audioCmd =
            '${inputs.toString()} '
            '-filter_complex "$fc" '
            '-map 0:v:0 -map "[aout]" '
            '-c:v copy -c:a aac -b:a 192k -ar 44100 -ac 2 '
            '-t $videoDurStr -y "$mixed"';

        var ok = await _runAsync(audioCmd);
        if (!ok) {
          // Fallback: video may lack an audio stream.
          final fcBg = ExportAudioMix.buildBgOnly(
            clips: audios,
            videoDurSec: videoDurSec,
          );
          final onlyBg =
              '${inputs.toString()} '
              '-filter_complex "$fcBg" '
              '-map 0:v:0 -map "[aout]" '
              '-c:v copy -c:a aac -b:a 192k -ar 44100 -ac 2 '
              '-t $videoDurStr -y "$mixed"';
          ok = await _runAsync(onlyBg);
        }
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        if (ok && await File(mixed).exists() && await File(mixed).length() > 0) {
          currentVideo = mixed;
        } else {
          _warnings.add(
            'Ses karıştırılamadı; kaynak video sesi korunmaya çalışıldı.',
          );
        }
      }

      // Final copy + verify
      final outFile = File(outputPath);
      await File(currentVideo).copy(outputPath);
      if (!await outFile.exists() || await outFile.length() == 0) {
        await _cleanupPartial(outputPath, workDir);
        return const ExportProgress(
          phase: ExportPhase.failed,
          message: 'Çıktı dosyası boş veya yazılamadı',
          error: 'output missing',
        );
      }

      try {
        await workDir.delete(recursive: true);
      } catch (_) {}

      return ExportProgress(
        phase: ExportPhase.done,
        message: _warnings.isEmpty
            ? 'Tamamlandı'
            : 'Tamamlandı (uyarılarla)',
        fraction: 1.0,
        outputPath: outputPath,
        warnings: List.unmodifiable(_warnings),
      );
    } catch (e) {
      if (outputPath != null) {
        await _cleanupPartial(outputPath, workDir);
      }
      return ExportProgress(
        phase: ExportPhase.failed,
        message: 'Dışa aktarma hatası',
        error: e.toString(),
      );
    } finally {
      _busy = false;
      _currentSessionId = null;
    }
  }

  /// Merge segments with hard cuts and/or xfade transitions.
  ///
  /// For each boundary i→i+1, uses [videoTrack[i].transitionId]:
  /// - crossfade / fadeBlack → FFmpeg xfade + acrossfade
  /// - otherwise → concat demuxer (stream copy when possible)
  ///
  /// Returns path to the final merged file, or null on failure.
  Future<String?> _mergeSegments({
    required List<String> segmentPaths,
    required List<ClipModel> videoTrack,
    required ExportSettings settings,
    required String workDir,
    required String outputPath,
  }) async {
    if (segmentPaths.isEmpty) return null;
    if (segmentPaths.length == 1) {
      await File(segmentPaths.first).copy(outputPath);
      return outputPath;
    }

    final needsXfade = <bool>[];
    for (var i = 0; i < segmentPaths.length - 1; i++) {
      final tid = i < videoTrack.length ? videoTrack[i].transitionId : 'none';
      needsXfade.add(ExportPlan.isXfadeTransition(tid));
    }

    // Fast path: no xfade at all → classic concat.
    if (!needsXfade.contains(true)) {
      final listPath = p.join(workDir, 'concat.txt');
      final buf = StringBuffer();
      for (final path in segmentPaths) {
        final escaped = path.replaceAll("'", r"'\''");
        buf.writeln("file '$escaped'");
      }
      await File(listPath).writeAsString(buf.toString());
      var ok = await _runAsync(
        '-f concat -safe 0 -i "$listPath" -c copy -y "$outputPath"',
      );
      if (!ok) {
        ok = await _runAsync(
          '-f concat -safe 0 -i "$listPath" ${_vencode(settings)} '
          '-pix_fmt yuv420p -c:a aac -b:a 128k -y "$outputPath"',
        );
      }
      return ok ? outputPath : null;
    }

    // Pairwise merge left-to-right.
    var current = segmentPaths.first;
    var currentDurSec = (videoTrack.isNotEmpty
            ? videoTrack.first.durationMs
            : 1000) /
        1000.0;

    for (var i = 1; i < segmentPaths.length; i++) {
      if (_cancelRequested) return null;
      final next = segmentPaths[i];
      final nextDurSec = (i < videoTrack.length
              ? videoTrack[i].durationMs
              : 1000) /
          1000.0;
      final out = p.join(workDir, 'merge_$i.mp4');
      final tid =
          (i - 1) < videoTrack.length ? videoTrack[i - 1].transitionId : 'none';

      if (ExportPlan.isXfadeTransition(tid)) {
        final rawTd = (i - 1) < videoTrack.length
            ? videoTrack[i - 1].transitionDurationMs / 1000.0
            : 0.5;
        final maxTd = (currentDurSec < nextDurSec ? currentDurSec : nextDurSec) /
            2.0;
        final td = rawTd.clamp(0.05, maxTd < 0.05 ? 0.05 : maxTd);
        final offset = (currentDurSec - td).clamp(0.0, 86400.0);
        final xname = ExportPlan.xfadeName(tid);
        final cmd =
            '-i "$current" -i "$next" '
            '-filter_complex '
            '"[0:v][1:v]xfade=transition=$xname:duration=${td.toStringAsFixed(3)}:offset=${offset.toStringAsFixed(3)}[v];'
            '[0:a][1:a]acrossfade=d=${td.toStringAsFixed(3)}[a]" '
            '-map "[v]" -map "[a]" '
            '${_vencode(settings)} '
            '-c:a aac -b:a 128k -ar 44100 -ac 2 '
            '-y "$out"';
        final ok = await _runAsync(cmd);
        if (!ok) {
          // Fallback: hard cut between these two
          _warnings.add(
            'Geçiş "$tid" uygulanamadı (klip ${i - 1}→$i); kesme kullanıldı.',
          );
          final listPath = p.join(workDir, 'fallback_$i.txt');
          await File(listPath).writeAsString(
            "file '${current.replaceAll("'", r"'\''")}'\n"
            "file '${next.replaceAll("'", r"'\''")}'\n",
          );
          final ok2 = await _runAsync(
            '-f concat -safe 0 -i "$listPath" ${_vencode(settings)} '
            '-pix_fmt yuv420p -c:a aac -b:a 128k -y "$out"',
          );
          if (!ok2) return null;
          currentDurSec = currentDurSec + nextDurSec;
        } else {
          currentDurSec = currentDurSec + nextDurSec - td;
        }
      } else {
        final listPath = p.join(workDir, 'hard_$i.txt');
        await File(listPath).writeAsString(
          "file '${current.replaceAll("'", r"'\''")}'\n"
          "file '${next.replaceAll("'", r"'\''")}'\n",
        );
        var ok = await _runAsync(
          '-f concat -safe 0 -i "$listPath" -c copy -y "$out"',
        );
        if (!ok) {
          ok = await _runAsync(
            '-f concat -safe 0 -i "$listPath" ${_vencode(settings)} '
            '-pix_fmt yuv420p -c:a aac -b:a 128k -y "$out"',
          );
        }
        if (!ok) return null;
        currentDurSec = currentDurSec + nextDurSec;
      }
      current = out;
    }

    if (current != outputPath) {
      await File(current).copy(outputPath);
    }
    return outputPath;
  }

  Future<bool> _ensureSegmentHasAudio(
    String segmentPath, {
    required int durationMs,
  }) async {
    try {
      final probeSession =
          await FFprobeKit.getMediaInformation(segmentPath);
      final information =
          await probeSession.getMediaInformation();

      if (information == null) return false;

      final hasAudio = information
          .getStreams()
          .any((stream) => stream.getType() == 'audio');

      if (hasAudio) return true;

      final durationSec = (durationMs / 1000.0)
          .clamp(0.1, 3600.0)
          .toStringAsFixed(3);

      final fixedPath = segmentPath.replaceFirst(
        RegExp(r'\.mp4$', caseSensitive: false),
        '_audiofix.mp4',
      );

      final command =
          '-i "$segmentPath" '
          '-f lavfi -t $durationSec '
          '-i anullsrc=channel_layout=stereo:sample_rate=44100 '
          '-map 0:v:0 -map 1:a:0 '
          '-c:v copy -c:a aac -b:a 128k '
          '-ar 44100 -ac 2 -t $durationSec -y "$fixedPath"';

      final ok = await _runAsync(command);
      final fixedFile = File(fixedPath);

      if (!ok ||
          !await fixedFile.exists() ||
          await fixedFile.length() == 0) {
        if (await fixedFile.exists()) {
          await fixedFile.delete();
        }
        return false;
      }

      await fixedFile.copy(segmentPath);
      await fixedFile.delete();
      return true;
    } catch (error) {
      print('Segment audio check failed: $error');
      return false;
    }
  }

  Future<void> _cleanupPartial(String? outputPath, Directory? workDir) async {
    try {
      if (outputPath != null) {
        final f = File(outputPath);
        if (await f.exists()) await f.delete();
      }
    } catch (_) {}
    try {
      if (workDir != null && await workDir.exists()) {
        await workDir.delete(recursive: true);
      }
    } catch (_) {}
  }

  /// Extract bundled fonts (assets) to temp, fall back to system fonts.
  Future<({String? regular, String? bold})> _resolveFontFiles() async {
    String escape(String path) =>
        path.replaceAll('\\', '/').replaceAll(':', '\\:');

    Future<String?> materialize(String asset, String outName) async {
      try {
        final data = await rootBundle.load(asset);
        final dir = await getTemporaryDirectory();
        final f = File(p.join(dir.path, outName));
        if (!await f.exists() || await f.length() == 0) {
          await f.writeAsBytes(
            data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
            flush: true,
          );
        }
        return escape(f.path);
      } catch (e) {
        debugPrint('Font asset $asset load failed: $e');
        return null;
      }
    }

    var regular =
        await materialize('assets/fonts/Roboto-Regular.ttf', 'fe_roboto_reg.ttf');
    var bold =
        await materialize('assets/fonts/Roboto-Bold.ttf', 'fe_roboto_bold.ttf');

    // System fallbacks
    const systemReg = [
      '/system/fonts/Roboto-Regular.ttf',
      '/system/fonts/NotoSans-Regular.ttf',
      '/system/fonts/DroidSans.ttf',
      '/system/fonts/Roboto.ttf',
    ];
    const systemBold = [
      '/system/fonts/Roboto-Bold.ttf',
      '/system/fonts/NotoSans-Bold.ttf',
    ];
    if (regular == null) {
      for (final c in systemReg) {
        if (await File(c).exists()) {
          regular = escape(c);
          break;
        }
      }
    }
    if (bold == null) {
      for (final c in systemBold) {
        if (await File(c).exists()) {
          bold = escape(c);
          break;
        }
      }
    }
    bold ??= regular;
    return (regular: regular, bold: bold);
  }

  /// Async execute so [requestCancel] can target the live session id.
  Future<bool> _runAsync(
    String command, {
    void Function(Statistics)? onStats,
  }) async {
    if (_cancelRequested) return false;

    final completer = Completer<FFmpegSession>();

    final session = await FFmpegKit.executeAsync(
      command,
      (s) {
        if (!completer.isCompleted) completer.complete(s);
      },
      null,
      (Statistics statistics) {
        onStats?.call(statistics);
      },
    );

    _currentSessionId = await session.getSessionId();

    final finished = await completer.future;
    final code = await finished.getReturnCode();
    _currentSessionId = null;

    if (_cancelRequested || ReturnCode.isCancel(code)) {
      return false;
    }
    return ReturnCode.isSuccess(code);
  }
}
