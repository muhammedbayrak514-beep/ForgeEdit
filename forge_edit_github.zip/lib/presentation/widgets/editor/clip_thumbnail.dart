import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/clip_model.dart';

/// In-memory thumbnail cache keyed by path + trimStart.
class _ThumbCache {
  static final Map<String, Uint8List> _mem = {};
  static String key(ClipModel c) =>
      '${c.id}|${c.filePath}|${c.trimStartMs}|${c.type.name}';

  static Uint8List? get(ClipModel c) => _mem[key(c)];
  static void set(ClipModel c, Uint8List bytes) {
    if (_mem.length > 80) {
      // Drop oldest-ish entries
      final keys = _mem.keys.take(20).toList();
      for (final k in keys) {
        _mem.remove(k);
      }
    }
    _mem[key(c)] = bytes;
  }
}

/// Filmstrip-style thumbnail for timeline / lists.
class ClipThumbnail extends StatefulWidget {
  final ClipModel clip;
  final double width;
  final double height;
  final BorderRadius? borderRadius;

  const ClipThumbnail({
    super.key,
    required this.clip,
    this.width = 56,
    this.height = 48,
    this.borderRadius,
  });

  @override
  State<ClipThumbnail> createState() => _ClipThumbnailState();
}

class _ClipThumbnailState extends State<ClipThumbnail> {
  Uint8List? _bytes;
  bool _loading = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  @override
  void didUpdateWidget(covariant ClipThumbnail oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.clip.id != widget.clip.id ||
        oldWidget.clip.filePath != widget.clip.filePath ||
        oldWidget.clip.trimStartMs != widget.clip.trimStartMs) {
      _bytes = null;
      _failed = false;
      _resolve();
    }
  }

  Future<void> _resolve() async {
    final clip = widget.clip;
    if (clip.type == ClipType.audio || clip.type == ClipType.text) {
      return;
    }
    final cached = _ThumbCache.get(clip);
    if (cached != null) {
      setState(() => _bytes = cached);
      return;
    }
    if (clip.type == ClipType.image) {
      // Image.file is used directly in build; nothing to decode here.
      return;
    }
    if (clip.type != ClipType.video || clip.filePath.isEmpty) return;
    final file = File(clip.filePath);
    if (!await file.exists()) {
      setState(() => _failed = true);
      return;
    }
    setState(() => _loading = true);
    try {
      final data = await VideoThumbnail.thumbnailData(
        video: clip.filePath,
        imageFormat: ImageFormat.JPEG,
        maxWidth: 160,
        quality: 55,
        timeMs: clip.trimStartMs.clamp(0, 1 << 30),
      );
      if (!mounted) return;
      if (data == null || data.isEmpty) {
        setState(() {
          _failed = true;
          _loading = false;
        });
        return;
      }
      _ThumbCache.set(clip, data);
      setState(() {
        _bytes = data;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _failed = true;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final radius = widget.borderRadius ?? BorderRadius.circular(4);
    final clip = widget.clip;

    Widget child;
    if (clip.type == ClipType.audio) {
      child = const ColoredBox(
        color: Color(0xFF1F3D36),
        child: Icon(Icons.audiotrack, size: 18, color: AppTheme.accent),
      );
    } else if (clip.type == ClipType.text) {
      child = const ColoredBox(
        color: Color(0xFF3D321F),
        child: Icon(Icons.text_fields, size: 18, color: AppTheme.warning),
      );
    } else if (clip.type == ClipType.image) {
      child = Image.file(
        File(clip.filePath),
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => const ColoredBox(
          color: AppTheme.surfaceElevated,
          child: Icon(Icons.broken_image, size: 16, color: AppTheme.textSecondary),
        ),
      );
    } else if (_bytes != null) {
      child = Image.memory(_bytes!, fit: BoxFit.cover);
    } else if (_loading) {
      child = const ColoredBox(
        color: AppTheme.surfaceElevated,
        child: Center(
          child: SizedBox(
            width: 14,
            height: 14,
            child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.primary),
          ),
        ),
      );
    } else if (_failed) {
      child = const ColoredBox(
        color: AppTheme.surfaceElevated,
        child: Icon(Icons.videocam, size: 18, color: AppTheme.textSecondary),
      );
    } else {
      child = const ColoredBox(
        color: AppTheme.surfaceElevated,
        child: Icon(Icons.videocam, size: 18, color: AppTheme.primary),
      );
    }

    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: ClipRRect(
        borderRadius: radius,
        child: child,
      ),
    );
  }
}
