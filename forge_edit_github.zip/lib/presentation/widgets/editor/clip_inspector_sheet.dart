import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import 'clip_inspector.dart';

/// Opens clip tools in a modal bottom sheet so the preview stays large.
class ClipInspectorSheet {
  static Future<void> show(BuildContext context, String projectId) {
    return showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.surface,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        final h = MediaQuery.sizeOf(ctx).height;
        return SafeArea(
          child: SizedBox(
            height: h * 0.48,
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 4, 16, 8),
                  child: Row(
                    children: [
                      Icon(Icons.tune, size: 18, color: AppTheme.textSecondary),
                      SizedBox(width: 8),
                      Text(
                        'Klip düzenle',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1, color: AppTheme.border),
                Expanded(
                  child: SingleChildScrollView(
                    child: ClipInspector(projectId: projectId),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
