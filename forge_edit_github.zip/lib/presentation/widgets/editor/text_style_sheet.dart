import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/text_style_catalog.dart';
import '../../providers/editor_provider.dart';

/// Bottom sheet: pick one of ~100 text styles for the selected text clip.
class TextStyleSheet extends ConsumerStatefulWidget {
  final String projectId;
  final String clipId;
  final String currentStyleId;

  const TextStyleSheet({
    super.key,
    required this.projectId,
    required this.clipId,
    required this.currentStyleId,
  });

  static Future<void> open(
    BuildContext context, {
    required String projectId,
    required String clipId,
    required String currentStyleId,
  }) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => TextStyleSheet(
        projectId: projectId,
        clipId: clipId,
        currentStyleId: currentStyleId,
      ),
    );
  }

  @override
  ConsumerState<TextStyleSheet> createState() => _TextStyleSheetState();
}

class _TextStyleSheetState extends ConsumerState<TextStyleSheet> {
  late String _category;
  late String _selectedId;

  @override
  void initState() {
    super.initState();
    _selectedId = widget.currentStyleId;
    final current = TextStyleCatalog.byId(widget.currentStyleId);
    _category = current.category;
  }

  List<String> get _categories {
    final cats = TextStyleCatalog.categories;
    // stable order
    const preferred = [
      'Minimal',
      'Modern',
      'Klasik',
      'Kalın',
      'Zarif',
      'Eğlenceli',
      'Neon',
      'Sinematik',
      'El Yazısı',
      'Teknik',
    ];
    final ordered = <String>[];
    for (final p in preferred) {
      if (cats.contains(p)) ordered.add(p);
    }
    for (final c in cats) {
      if (!ordered.contains(c)) ordered.add(c);
    }
    return ordered;
  }

  Future<void> _apply(String styleId) async {
    setState(() => _selectedId = styleId);
    await ref.read(editorProvider(widget.projectId).notifier).updateTextClip(
          clipId: widget.clipId,
          textStyleId: styleId,
        );
  }

  @override
  Widget build(BuildContext context) {
    final styles = TextStyleCatalog.byCategory(_category);
    final height = MediaQuery.sizeOf(context).height * 0.72;

    return SizedBox(
      height: height,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'Yazı Stilleri',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                ),
                Text(
                  '${TextStyleCatalog.all.length} stil',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppTheme.textSecondary,
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 40,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: _categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final cat = _categories[i];
                final selected = cat == _category;
                return ChoiceChip(
                  label: Text(cat),
                  selected: selected,
                  onSelected: (_) => setState(() => _category = cat),
                  selectedColor: AppTheme.primary.withValues(alpha: 0.35),
                  labelStyle: TextStyle(
                    color: selected
                        ? AppTheme.textPrimary
                        : AppTheme.textSecondary,
                    fontWeight:
                        selected ? FontWeight.w600 : FontWeight.w400,
                    fontSize: 13,
                  ),
                  backgroundColor: AppTheme.surfaceElevated,
                  side: BorderSide(
                    color: selected ? AppTheme.primary : AppTheme.border,
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 2.4,
              ),
              itemCount: styles.length,
              itemBuilder: (context, index) {
                final def = styles[index];
                final selected = def.id == _selectedId;
                final previewStyle = TextStyleResolver.resolve(
                  def: def,
                  fontSize: 18,
                  colorArgb: 0xFFFFFFFF,
                );
                return Material(
                  color: selected
                      ? AppTheme.primary.withValues(alpha: 0.2)
                      : AppTheme.surfaceElevated,
                  borderRadius: BorderRadius.circular(10),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: () => _apply(def.id),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: selected
                              ? AppTheme.primary
                              : AppTheme.border,
                          width: selected ? 2 : 1,
                        ),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 8,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            TextStyleResolver.displayText('Örnek Aa', def),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: previewStyle,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            def.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 11,
                              color: AppTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
