import 'package:flutter/material.dart';

import '../../../core/prefs/app_prefs.dart';
import '../../../core/theme/app_theme.dart';

class EditorOnboardingOverlay extends StatefulWidget {
  final VoidCallback onDismissed;

  const EditorOnboardingOverlay({super.key, required this.onDismissed});

  @override
  State<EditorOnboardingOverlay> createState() =>
      _EditorOnboardingOverlayState();
}

class _EditorOnboardingOverlayState extends State<EditorOnboardingOverlay> {
  int _page = 0;

  static const _pages = [
    (
      'Medya ekle',
      'Alttan Medya ile video/foto ekle. Timeline’da V şeridinde görünür.',
      Icons.perm_media_outlined,
    ),
    (
      'Düzenle',
      'Klip seç → kenarlardan kısalt/uzat. Uzun basarak sıra değiştir.',
      Icons.content_cut,
    ),
    (
      'Metin & sticker',
      'Metin stilleri, animasyon ve sticker (S şeridi). Önizlemede sürükle.',
      Icons.text_fields,
    ),
    (
      'Efekt & export',
      'Geçiş/filtre için Efekt. Bitince sağ üstten Dışa Aktar.',
      Icons.auto_awesome,
    ),
  ];

  Future<void> _finish() async {
    await AppPrefs.setEditorOnboardingDone();
    widget.onDismissed();
  }

  @override
  Widget build(BuildContext context) {
    final page = _pages[_page];
    return Material(
      color: Colors.black.withValues(alpha: 0.72),
      child: SafeArea(
        child: Center(
          child: Container(
            margin: const EdgeInsets.all(24),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.border),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(page.$3, size: 40, color: AppTheme.primary),
                const SizedBox(height: 12),
                Text(
                  page.$1,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  page.$2,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    _pages.length,
                    (i) => Container(
                      width: 8,
                      height: 8,
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: i == _page
                            ? AppTheme.primary
                            : AppTheme.border,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    TextButton(
                      onPressed: _finish,
                      child: const Text('Atla'),
                    ),
                    const Spacer(),
                    ElevatedButton(
                      onPressed: () {
                        if (_page >= _pages.length - 1) {
                          _finish();
                        } else {
                          setState(() => _page++);
                        }
                      },
                      child: Text(
                        _page >= _pages.length - 1 ? 'Başla' : 'İleri',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
