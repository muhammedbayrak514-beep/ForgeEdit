import 'dart:ui';

import 'package:flutter/material.dart';

import '../../../domain/models/effect_models.dart';

/// Builds a ColorFilter matrix for preview-only approximation of [filterId].
/// Intensity 0 = identity, 1 = full filter.
class FilterMatrix {
  static ColorFilter? forPreview(String filterId, double intensity) {
    final id = FilterId.values.asNameMap()[filterId] ?? FilterId.none;
    if (id == FilterId.none || intensity <= 0) return null;

    final t = intensity.clamp(0.0, 1.0);
    final full = _matrixFor(id);
    final identity = _identity;
    final blended = List<double>.generate(
      20,
      (i) => identity[i] * (1 - t) + full[i] * t,
    );
    return ColorFilter.matrix(blended);
  }

  static const _identity = <double>[
    1, 0, 0, 0, 0,
    0, 1, 0, 0, 0,
    0, 0, 1, 0, 0,
    0, 0, 0, 1, 0,
  ];

  static List<double> _matrixFor(FilterId id) {
    switch (id) {
      case FilterId.none:
        return _identity;
      case FilterId.grayscale:
        return [
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case FilterId.sepia:
        return [
          0.393, 0.769, 0.189, 0, 0,
          0.349, 0.686, 0.168, 0, 0,
          0.272, 0.534, 0.131, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case FilterId.warm:
        return [
          1.1, 0.05, 0, 0, 10,
          0, 1.0, 0, 0, 0,
          0, 0, 0.9, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case FilterId.cool:
        return [
          0.9, 0, 0, 0, 0,
          0, 1.0, 0, 0, 0,
          0.05, 0.05, 1.15, 0, 10,
          0, 0, 0, 1, 0,
        ];
      case FilterId.highContrast:
        return [
          1.4, 0, 0, 0, -40,
          0, 1.4, 0, 0, -40,
          0, 0, 1.4, 0, -40,
          0, 0, 0, 1, 0,
        ];
      case FilterId.muted:
        return [
          0.7, 0.15, 0.15, 0, 0,
          0.15, 0.7, 0.15, 0, 0,
          0.15, 0.15, 0.7, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case FilterId.vivid:
        return [
          1.25, -0.05, -0.05, 0, 0,
          -0.05, 1.25, -0.05, 0, 0,
          -0.05, -0.05, 1.25, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case FilterId.vintage:
        return [
          0.9, 0.2, 0.1, 0, 5,
          0.1, 0.85, 0.15, 0, 0,
          0.1, 0.15, 0.7, 0, -5,
          0, 0, 0, 1, 0,
        ];
      case FilterId.bright:
        return [
          1.1, 0, 0, 0, 25,
          0, 1.1, 0, 0, 25,
          0, 0, 1.1, 0, 25,
          0, 0, 0, 1, 0,
        ];
      case FilterId.noir:
        return [
          0.3, 0.5, 0.1, 0, -20,
          0.3, 0.5, 0.1, 0, -20,
          0.3, 0.5, 0.1, 0, -20,
          0, 0, 0, 1, 0,
        ];
      case FilterId.chromakey:
        // Preview approximation: slight green suppress (real key is export-only)
        return [
          1, 0, 0, 0, 0,
          0, 0.85, 0, 0, 0,
          0, 0, 1, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case FilterId.fade:
        return [
          0.85, 0.1, 0.1, 0, 15,
          0.1, 0.85, 0.1, 0, 15,
          0.1, 0.1, 0.85, 0, 15,
          0, 0, 0, 1, 0,
        ];
    }
  }
}

/// Wraps [child] with ColorFiltered when a preview filter is active.
class FilteredPreview extends StatelessWidget {
  final String filterId;
  final double intensity;
  final Widget child;

  const FilteredPreview({
    super.key,
    required this.filterId,
    required this.intensity,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final filter = FilterMatrix.forPreview(filterId, intensity);
    if (filter == null) return child;
    return ColorFiltered(colorFilter: filter, child: child);
  }
}
