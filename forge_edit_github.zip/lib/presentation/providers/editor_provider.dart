import 'package:collection/collection.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/repositories/project_repository.dart';
import '../../domain/edit_history.dart';
import '../../domain/models/clip_model.dart';
import '../../domain/models/project_model.dart';
import '../../domain/timeline_ops.dart';
import '../../data/services/freeze_frame_service.dart';
import '../../data/repositories/project_repository.dart';
import 'package:path/path.dart' as p;
import 'dart:io';
import 'preview_provider.dart';
import 'project_list_provider.dart';
import 'timeline_clock_provider.dart';

final editorProvider =
    AsyncNotifierProvider.family<EditorNotifier, ProjectModel, String>(
  EditorNotifier.new,
);

final historyUiProvider =
    StateProvider.family<HistoryUiState, String>((ref, projectId) {
  return const HistoryUiState();
});

class EditorNotifier extends FamilyAsyncNotifier<ProjectModel, String> {
  ProjectRepository get _repo => ref.read(projectRepositoryProvider);
  final EditHistory _history = EditHistory();
  bool _saving = false;
  /// Monotonic generation so a late-finishing save cannot overwrite a newer state.
  int _saveGeneration = 0;
  Future<void>? _saveChain;

  String get projectId => arg;

  @override
  Future<ProjectModel> build(String projectId) async {
    final project = await _repo.getProject(projectId);
    if (project == null) {
      throw Exception('Proje bulunamadı: $projectId');
    }
    _history.clear();
    _publishHistory();
    return project;
  }

  Future<void> load() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => build(projectId));
  }

  /// Serializes disk writes; always persists the *latest* state after the chain.
  Future<void> save() {
    final gen = ++_saveGeneration;
    final previous = _saveChain ?? Future.value();
    _saveChain = previous.then((_) => _saveAt(gen)).catchError((e, st) {
      // Keep chain alive after failure
    });
    return _saveChain!;
  }

  Future<void> _saveAt(int gen) async {
    // Wait until we are the latest requested generation's runner,
    // but still write the current in-memory state once per turn of the chain.
    if (gen < _saveGeneration) {
      // A newer save was requested; the chain will call us again via later link.
      return;
    }
    final current = state.value;
    if (current == null) return;
    // Guard against writing wrong project after notifier rebuild
    if (current.id != projectId) return;
    _saving = true;
    try {
      await _repo.saveProject(current);
      // If state advanced during await, schedule another save
      if (gen < _saveGeneration) {
        return;
      }
      // Re-check: if still same generation, refresh list once
      ref.read(projectListProvider.notifier).refresh();
    } finally {
      _saving = false;
      // If mutations happened while saving, ensure latest is flushed
      if (gen < _saveGeneration && state.value != null) {
        // chain continues via subsequent save() links
      }
    }
  }

  void _publishHistory() {
    ref.read(historyUiProvider(projectId).notifier).state =
        HistoryUiState.from(_history);
  }

  Future<void> _commit(ProjectModel next) async {
    final current = state.value;
    if (current != null) {
      _history.pushBeforeChange(current);
    }
    state = AsyncData(next);
    _publishHistory();
    await save();
  }

  Future<void> applyLive(ProjectModel next) async {
    state = AsyncData(next);
  }

  void beginContinuousEdit(String key) {
    final current = state.value;
    if (current == null) return;
    _history.beginCoalesce(current, key);
    _publishHistory();
  }

  Future<void> endContinuousEdit() async {
    _history.endCoalesce();
    _publishHistory();
    await save();
  }

  Future<void> undo() async {
    final current = state.value;
    if (current == null || !_history.canUndo) return;
    final prev = _history.undo(current);
    if (prev == null) return;
    state = AsyncData(prev);
    _publishHistory();
    await save();
    _clampPlayhead(prev);
    _fixSelection(prev);
  }

  Future<void> redo() async {
    final current = state.value;
    if (current == null || !_history.canRedo) return;
    final next = _history.redo(current);
    if (next == null) return;
    state = AsyncData(next);
    _publishHistory();
    await save();
    _clampPlayhead(next);
    _fixSelection(next);
  }

  void _fixSelection(ProjectModel project) {
    final selected = ref.read(selectedClipIdProvider(projectId));
    if (selected != null && !project.clips.any((c) => c.id == selected)) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          project.clips.isNotEmpty ? project.clips.first.id : null;
    }
  }

  Future<void> addClips(List<ClipModel> clips) async {
    final current = state.value;
    if (current == null) return;
    var updated = current;
    for (final clip in clips) {
      updated = updated.addClip(clip);
    }
    await _commit(updated);
  }

  Future<void> updateClip(ClipModel clip, {bool continuous = false}) async {
    final current = state.value;
    if (current == null) return;
    final next = current.updateClip(clip);
    if (continuous) {
      await applyLive(next);
    } else {
      await _commit(next);
    }
  }

  Future<void> trimClip({
    required String clipId,
    required int trimStartMs,
    required int trimEndMs,
    bool continuous = false,
  }) async {
    final current = state.value;
    if (current == null) return;
    final updated = TimelineOps.trimClip(
      project: current,
      clipId: clipId,
      newTrimStartMs: trimStartMs,
      newTrimEndMs: trimEndMs,
    );
    if (continuous) {
      await applyLive(updated);
    } else {
      await _commit(updated);
      _clampPlayhead(updated);
      _reloadPreviewIfSelected(clipId);
    }
  }

  Future<void> resizeClipEdge({
    required String clipId,
    required bool fromLeft,
    required int deltaTimelineMs,
    bool continuous = false,
  }) async {
    final current = state.value;
    if (current == null || deltaTimelineMs == 0) return;
    final updated = TimelineOps.resizeClipEdge(
      project: current,
      clipId: clipId,
      fromLeft: fromLeft,
      deltaTimelineMs: deltaTimelineMs,
    );
    if (continuous) {
      await applyLive(updated);
    } else {
      await _commit(updated);
      _clampPlayhead(updated);
      _reloadPreviewIfSelected(clipId);
    }
  }

  Future<bool> splitAtPlayhead(String clipId) async {
    final current = state.value;
    if (current == null) return false;
    final playhead = ref.read(timelineClockProvider(projectId)).positionMs;
    final result = TimelineOps.splitClip(
      project: current,
      clipId: clipId,
      projectTimeMs: playhead,
    );
    if (result == null) return false;
    await _commit(result);
    ref.read(selectedClipIdProvider(projectId).notifier).state = clipId;
    _clampPlayhead(result);
    return true;
  }

  Future<void> deleteClip(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final updated = TimelineOps.deleteClip(project: current, clipId: clipId);
    await _commit(updated);
    final selected = ref.read(selectedClipIdProvider(projectId));
    if (selected == clipId) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          updated.clips.isNotEmpty ? updated.clips.first.id : null;
    }
    final multi = ref.read(selectedClipIdsProvider(projectId));
    if (multi.contains(clipId)) {
      ref.read(selectedClipIdsProvider(projectId).notifier).state =
          {...multi}..remove(clipId);
    }
    _clampPlayhead(updated);
  }

  Future<void> deleteClips(Iterable<String> ids) async {
    final current = state.value;
    if (current == null) return;
    final list = ids.toList();
    if (list.isEmpty) return;
    final updated = TimelineOps.deleteClips(project: current, clipIds: list);
    await _commit(updated);
    ref.read(selectedClipIdsProvider(projectId).notifier).state = {};
    ref.read(multiSelectModeProvider(projectId).notifier).state = false;
    final sel = ref.read(selectedClipIdProvider(projectId));
    if (sel != null && list.contains(sel)) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          updated.clips.isNotEmpty ? updated.clips.first.id : null;
    }
    _clampPlayhead(updated);
  }

  Future<void> duplicateClip(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final updated = TimelineOps.duplicateClip(project: current, clipId: clipId);
    await _commit(updated);
    // select the new copy (last matching display or newest)
    final copies = updated.clips.where((c) => c.id != clipId).toList();
    // find by newest id not in old
    final oldIds = current.clips.map((c) => c.id).toSet();
    final created = updated.clips.where((c) => !oldIds.contains(c.id)).toList();
    if (created.isNotEmpty) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          created.last.id;
    }
    _clampPlayhead(updated);
  }

  Future<void> autoSplitEvery(String clipId, int intervalMs) async {
    final current = state.value;
    if (current == null) return;
    final updated = TimelineOps.autoSplitEvery(
      project: current,
      clipId: clipId,
      intervalMs: intervalMs,
    );
    await _commit(updated);
    _clampPlayhead(updated);
  }

  Future<void> removeClip(String clipId) => deleteClip(clipId);

  Future<void> convertToPip(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    if (clip.type != ClipType.video && clip.type != ClipType.image) return;
    await updateClip(
      clip.copyWith(
        trackIndex: TrackIndex.overlay,
        scale: 0.35,
        posX: 0.82,
        posY: 0.82,
      ),
    );
  }

  Future<void> convertPipToMain(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    var next = current.updateClip(
      clip.copyWith(
        trackIndex: TrackIndex.video,
        scale: 1.0,
        posX: 0.5,
        posY: 0.5,
      ),
    );
    next = TimelineOps.packMainTrack(next);
    await _commit(next);
  }

  Future<void> setClipFades({
    required String clipId,
    int? fadeInMs,
    int? fadeOutMs,
  }) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    await updateClip(
      clip.copyWith(
        fadeInMs: fadeInMs ?? clip.fadeInMs,
        fadeOutMs: fadeOutMs ?? clip.fadeOutMs,
      ),
    );
  }

  Future<void> toggleReverse(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    if (clip.type != ClipType.video && clip.type != ClipType.audio) return;
    await updateClip(clip.copyWith(reversed: !clip.reversed));
  }

  Future<void> toggleMute(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    final nextVol = clip.volume < 0.001 ? 1.0 : 0.0;
    await updateClip(clip.copyWith(volume: nextVol));
  }

  Future<ClipModel?> freezeFrameAtPlayhead(String clipId) async {
    final current = state.value;
    if (current == null) return null;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.type != ClipType.video) return null;
    final clock = ref.read(timelineClockProvider(projectId)).positionMs;
    final local = (clock - clip.timelineStartMs).clamp(0, clip.durationMs);
    // Map timeline-local to source time accounting for speed
    final sourceMs = clip.trimStartMs + (local * clip.speed).round();
    final service = FreezeFrameService();
    final frozen = await service.capture(
      projectId: projectId,
      sourcePath: clip.filePath,
      sourceTimeMs: sourceMs,
      timelineStartMs: clock,
    );
    if (frozen == null) return null;
    await addClips([frozen]);
    ref.read(selectedClipIdProvider(projectId).notifier).state = frozen.id;
    return frozen;
  }

  Future<bool> replaceClipMediaFromPath({
    required String clipId,
    required String sourcePath,
  }) async {
    final current = state.value;
    if (current == null) return false;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return false;
    if (clip.type != ClipType.video && clip.type != ClipType.image) return false;
    try {
      final media = await ProjectRepository().mediaDir(projectId);
      final ext = p.extension(sourcePath).toLowerCase();
      final dest = p.join(media.path, '${clip.id}_replaced$ext');
      await File(sourcePath).copy(dest);
      await updateClip(
        clip.copyWith(
          filePath: dest,
          displayName: p.basename(sourcePath),
        ),
      );
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> toggleClipLock(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return;
    await updateClip(clip.copyWith(locked: !clip.locked));
  }

  Future<void> setClipColorTag(String clipId, String tag) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return;
    await updateClip(clip.copyWith(colorTag: tag));
  }

  Future<void> addMarkerAtPlayhead() async {
    final current = state.value;
    if (current == null) return;
    final ms = ref.read(timelineClockProvider(projectId)).positionMs;
    final markers = [...current.markersMs];
    if (markers.any((m) => (m - ms).abs() < 40)) return;
    markers.add(ms);
    markers.sort();
    await _commit(current.copyWith(markersMs: markers, updatedAt: DateTime.now()));
  }

  Future<void> removeNearestMarker() async {
    final current = state.value;
    if (current == null || current.markersMs.isEmpty) return;
    final ms = ref.read(timelineClockProvider(projectId)).positionMs;
    var best = current.markersMs.first;
    var bestD = (best - ms).abs();
    for (final m in current.markersMs) {
      final d = (m - ms).abs();
      if (d < bestD) {
        bestD = d;
        best = m;
      }
    }
    if (bestD > 500) return;
    final markers = current.markersMs.where((m) => m != best).toList();
    await _commit(current.copyWith(markersMs: markers, updatedAt: DateTime.now()));
  }

  Future<void> importSrtClips(List<ClipModel> clips) async {
    if (clips.isEmpty) return;
    final current = state.value;
    if (current == null) return;
    var next = current;
    for (final c in clips) {
      next = next.addClip(c);
    }
    await _commit(next.copyWith(updatedAt: DateTime.now()));
    if (clips.isNotEmpty) {
      ref.read(selectedClipIdProvider(projectId).notifier).state = clips.first.id;
    }
  }

  Future<void> replaceClipMedia({
    required String clipId,
    required String newFilePath,
    required String displayName,
  }) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    if (clip.type != ClipType.video && clip.type != ClipType.image) return;
    await updateClip(
      clip.copyWith(filePath: newFilePath, displayName: displayName),
    );
    _reloadPreviewIfSelected(clipId);
  }

  Future<void> reorderMainClip(String clipId, int newIndex) async {
    final current = state.value;
    if (current == null) return;
    await _commit(TimelineOps.reorderMainTrack(
      project: current,
      clipId: clipId,
      newIndex: newIndex,
    ));
  }

  Future<void> moveClipToTime(String clipId, int timelineStartMs) async {
    final current = state.value;
    if (current == null) return;
    await _commit(TimelineOps.setClipTimelineStart(
      project: current,
      clipId: clipId,
      timelineStartMs: timelineStartMs,
    ));
  }

  Future<void> renameProject(String name) async {
    final current = state.value;
    if (current == null) return;
    final trimmed = name.trim();
    if (trimmed.isEmpty || trimmed == current.name) return;
    await _commit(current.copyWith(name: trimmed, updatedAt: DateTime.now()));
  }

  Future<void> setAspectRatio({required int width, required int height}) async {
    final current = state.value;
    if (current == null) return;
    if (current.width == width && current.height == height) return;
    await _commit(
      current.copyWith(width: width, height: height, updatedAt: DateTime.now()),
    );
  }

  Future<void> moveClipLeft(String clipId) async {
    final current = state.value;
    if (current == null) return;
    await _commit(TimelineOps.moveClip(
      project: current,
      clipId: clipId,
      direction: -1,
    ));
  }

  Future<void> moveClipRight(String clipId) async {
    final current = state.value;
    if (current == null) return;
    await _commit(TimelineOps.moveClip(
      project: current,
      clipId: clipId,
      direction: 1,
    ));
  }

  Future<void> addTextClip({
    required String content,
    int durationMs = 3000,
    int? timelineStartMs,
  }) async {
    final current = state.value;
    if (current == null) return;
    final start = timelineStartMs ??
        ref.read(timelineClockProvider(projectId)).positionMs;
    final clip = ClipModel.text(
      content: content,
      durationMs: durationMs,
      timelineStartMs: start,
    );
    await _commit(current.addClip(clip));
    ref.read(selectedClipIdProvider(projectId).notifier).state = clip.id;
  }

  Future<void> addAudioClip(ClipModel audioClip) async {
    final current = state.value;
    if (current == null) return;
    await _commit(current.addClip(audioClip));
    ref.read(selectedClipIdProvider(projectId).notifier).state = audioClip.id;
  }

  Future<void> updateTextClip({
    required String clipId,
    String? textContent,
    double? fontSize,
    int? textColorArgb,
    int? textAlign,
    double? posX,
    double? posY,
    String? textStyleId,
    int? durationMs,
    bool continuous = false,
  }) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.type != ClipType.text) return;
    var updated = clip;
    if (textContent != null) {
      final name = textContent.length > 24
          ? '${textContent.substring(0, 24)}…'
          : textContent;
      updated = updated.copyWith(
        textContent: textContent,
        displayName: name,
      );
    }
    if (fontSize != null) updated = updated.copyWith(fontSize: fontSize);
    if (textColorArgb != null) {
      updated = updated.copyWith(textColorArgb: textColorArgb);
    }
    if (textAlign != null) updated = updated.copyWith(textAlign: textAlign);
    if (posX != null) updated = updated.copyWith(posX: posX);
    if (posY != null) updated = updated.copyWith(posY: posY);
    if (textStyleId != null) {
      updated = updated.copyWith(textStyleId: textStyleId);
    }
    if (durationMs != null && durationMs >= 100) {
      updated = updated.copyWith(
        sourceDurationMs: durationMs,
        trimEndMs: durationMs,
        trimStartMs: 0,
      );
    }
    final next = current.updateClip(updated);
    if (continuous) {
      await applyLive(next);
    } else {
      await _commit(next);
    }
  }

  void _clampPlayhead(ProjectModel project) {
    final max = project.durationMs;
    final clock = ref.read(timelineClockProvider(projectId));
    if (clock.positionMs > max) {
      ref.read(timelineClockProvider(projectId).notifier).setPosition(max);
    }
  }

  void _reloadPreviewIfSelected(String clipId) {
    final selected = ref.read(selectedClipIdProvider(projectId));
    if (selected == clipId) {
      ref.read(selectedClipIdProvider(projectId).notifier).state = null;
      Future.microtask(() {
        ref.read(selectedClipIdProvider(projectId).notifier).state = clipId;
      });
    }
  }
}
