import 'dart:async';
import 'dart:io';

import 'package:collection/collection.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:video_player/video_player.dart';

import '../../domain/models/clip_model.dart';
import '../../domain/timeline_playback.dart';
import '../../data/services/proxy_service.dart';
import 'editor_provider.dart';
import 'timeline_clock_provider.dart';

/// Selected clip id for preview / timeline highlight.
final selectedClipIdProvider =
    StateProvider.family<String?, String>((ref, projectId) => null);

/// Multi-select mode for bulk actions (Tour 4).
final multiSelectModeProvider =
    StateProvider.family<bool, String>((ref, projectId) => false);

final selectedClipIdsProvider =
    StateProvider.family<Set<String>, String>((ref, projectId) => {});

/// Preview surface + multi-clip continuous playback.
///
/// Playback model:
/// - [TimelineClock] is the source of truth for project time.
/// - Play starts at the current playhead, loads the visual clip under it,
///   seeks into the clip, and plays.
/// - When a video reaches its trim end (or an image's duration elapses),
///   we advance to the next visual clip automatically until the timeline ends.
class PreviewControllerNotifier
    extends FamilyAsyncNotifier<PreviewState, String> {
  VideoPlayerController? _controller;
  String? _loadedClipId;

  /// User pressed play; keep advancing until pause or end.
  bool _userWantsPlay = false;

  /// Guard against double-advance from multiple listener ticks.
  bool _advancing = false;

  Timer? _imageTimer;
  Timer? _transitionTimer;

  /// Prefetched next video for gapless advance.
  VideoPlayerController? _preloaded;
  String? _preloadedClipId;

  VideoPlayerController? _outgoing;
  double _transitionOpacity = 0;
  String? _transitionKind;

  String get projectId => arg;

  @override
  Future<PreviewState> build(String projectId) async {
    ref.onDispose(() {
      _imageTimer?.cancel();
      _transitionTimer?.cancel();
      _userWantsPlay = false;
      _disposeController();
      _disposePreload();
      _disposeOutgoing();
    });

    // Keep selection valid when clips change.
    ref.listen(editorProvider(projectId), (prev, next) {
      final clips = next.value?.clips ?? [];
      final selectedId = ref.read(selectedClipIdProvider(projectId));
      if (selectedId != null && !clips.any((c) => c.id == selectedId)) {
        ref.read(selectedClipIdProvider(projectId).notifier).state =
            clips.isNotEmpty ? clips.first.id : null;
      } else if (selectedId == null && clips.isNotEmpty) {
        ref.read(selectedClipIdProvider(projectId).notifier).state =
            clips.first.id;
      }
    });

    // Selection change → load media for visual clips only.
    // Text/audio selection keeps the current visual under the playhead
    // (or under the text's timeline start) so preview never goes blank.
    ref.listen(selectedClipIdProvider(projectId), (prev, next) async {
      if (next == null) {
        await _disposeController();
        state = const AsyncData(PreviewState.empty());
        return;
      }
      if (_advancing) return;

      final project = ref.read(editorProvider(projectId)).value;
      final clip = project?.clips.where((c) => c.id == next).firstOrNull;
      if (clip == null) return;

      if (clip.type == ClipType.text || clip.type == ClipType.audio) {
        final clockMs =
            ref.read(timelineClockProvider(projectId)).positionMs;
        // Prefer visual under text start so overlay is meaningful
        final targetMs = clip.timelineStartMs;
        if ((clockMs - targetMs).abs() > 200) {
          ref
              .read(timelineClockProvider(projectId).notifier)
              .setPosition(targetMs);
        }
        final under = TimelinePlayback.visualClipAt(
              project!.clips,
              targetMs,
            ) ??
            TimelinePlayback.visualClipsSorted(project.clips).firstOrNull;
        if (under == null) {
          // Only text/audio in project — keep empty black surface
          _loadedClipId = null;
          state = const AsyncData(PreviewState.empty());
          return;
        }
        if (under.id != _loadedClipId) {
          final result = await _loadClip(under);
          state = AsyncData(result);
        }
        return;
      }

      if (next != _loadedClipId) {
        final result = await _loadClip(clip);
        if (ref.read(selectedClipIdProvider(projectId)) == next) {
          state = AsyncData(result);
          if (_userWantsPlay) {
            await _playLoadedClipFromClock();
          }
        }
      }
    });

    // Playhead scrub while paused → show the clip under the playhead.
    ref.listen(timelineClockProvider(projectId), (prev, next) async {
      if (_userWantsPlay) return;
      if (prev?.positionMs == next.positionMs) return;
      final project = ref.read(editorProvider(projectId)).value;
      if (project == null || project.clips.isEmpty) return;
      final under =
          TimelinePlayback.visualClipAt(project.clips, next.positionMs);
      if (under == null) return;
      if (under.id == _loadedClipId) {
        // Same clip: seek video to match playhead.
        if (!under.type.isVideo || _controller == null) return;
        if (!_controller!.value.isInitialized) return;
        final local =
            TimelinePlayback.projectToLocalMs(under, next.positionMs);
        final cur = _controller!.value.position.inMilliseconds;
        if ((cur - local).abs() > 120) {
          await _controller!.seekTo(Duration(milliseconds: local));
        }
        return;
      }
      ref.read(selectedClipIdProvider(projectId).notifier).state = under.id;
    });

    final selectedId = ref.read(selectedClipIdProvider(projectId));
    if (selectedId != null) {
      return _loadClipById(selectedId);
    }

    final project = ref.read(editorProvider(projectId)).value;
    final clips = project?.clips ?? const <ClipModel>[];
    final first = TimelinePlayback.visualClipsSorted(clips).firstOrNull ??
        (clips.isNotEmpty ? clips.first : null);
    if (first != null) {
      ref.read(selectedClipIdProvider(projectId).notifier).state = first.id;
      return _loadClipById(first.id);
    }

    return const PreviewState.empty();
  }

  Future<PreviewState> _loadClipById(String clipId) async {
    final project = ref.read(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return const PreviewState.empty();
    return _loadClip(clip);
  }

  Future<PreviewState> _loadClip(
    ClipModel clip, {
    bool silent = false,
  }) async {
    if (!silent) {
      state = const AsyncLoading();
    }
    _imageTimer?.cancel();
    // Keep current frame on screen while we prepare the next (silent).
    if (!silent) {
      await _disposeController();
      await _disposeOutgoing();
    }

    if (clip.type == ClipType.image) {
      if (!silent) {
        await _disposeController();
      }
      final imageFile = File(clip.filePath);
      if (!await imageFile.exists()) {
        _loadedClipId = clip.id;
        return PreviewState(
          clipId: clip.id,
          displayName: clip.displayName,
          isImage: true,
          error: 'Görsel dosyası bulunamadı:\n${clip.filePath}',
        );
      }
      if (!silent) {
        await _disposeController();
      }
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        isImage: true,
      );
    }

    if (clip.type == ClipType.text || clip.type == ClipType.audio) {
      final prev = state.value;
      if (prev != null && (prev.hasVideo || prev.isImage) && prev.error == null) {
        return prev;
      }
      return const PreviewState.empty();
    }

    if (clip.type != ClipType.video) {
      return const PreviewState.empty();
    }

    // Reuse preload if it matches
    if (_preloadedClipId == clip.id &&
        _preloaded != null &&
        _preloaded!.value.isInitialized) {
      final ready = _preloaded!;
      _preloaded = null;
      _preloadedClipId = null;
      if (!silent) {
        await _disposeController();
      } else {
        // swap: detach old
        final old = _controller;
        if (old != null) {
          old.removeListener(_onControllerUpdate);
          // keep briefly if transition, else dispose
          _outgoing = old;
        }
      }
      ready.addListener(_onControllerUpdate);
      _controller = ready;
      _loadedClipId = clip.id;
      final startLocal = clip.trimStartMs.clamp(0, clip.trimEndMs);
      final pos = ready.value.position.inMilliseconds;
      if ((pos - startLocal).abs() > 60) {
        await ready.seekTo(Duration(milliseconds: startLocal));
      }
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        controller: ready,
        outgoingController: _outgoing,
        transitionOpacity: 0,
        transitionKind: _transitionKind,
      );
    }

    final file = File(ProxyService.pathForPreview(clip.filePath));
    if (!await file.exists()) {
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        error: 'Video dosyası bulunamadı:\n${clip.filePath}',
      );
    }

    try {
      final controller = VideoPlayerController.file(file);
      await controller.initialize();

      final startLocal = clip.trimStartMs.clamp(0, clip.trimEndMs);
      if (startLocal > 0) {
        await controller.seekTo(Duration(milliseconds: startLocal));
      }

      if (!silent) {
        await _disposeController();
        await _disposeOutgoing();
      } else {
        final old = _controller;
        if (old != null) {
          old.removeListener(_onControllerUpdate);
          _outgoing = old;
        }
      }

      controller.addListener(_onControllerUpdate);
      _controller = controller;
      _loadedClipId = clip.id;

      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        controller: controller,
        outgoingController: _outgoing,
        transitionOpacity: 0,
        transitionKind: _transitionKind,
      );
    } catch (e, st) {
      debugPrint('Preview load error: $e\n$st');
      _loadedClipId = clip.id;
      return PreviewState(
        clipId: clip.id,
        displayName: clip.displayName,
        error: 'Video yüklenemedi: $e',
      );
    }
  }

  Future<void> _ensurePreload(ClipModel next) async {
    if (next.type != ClipType.video) return;
    if (_preloadedClipId == next.id &&
        _preloaded != null &&
        _preloaded!.value.isInitialized) {
      return;
    }
    await _disposePreload();
    final file = File(ProxyService.pathForPreview(next.filePath));
    if (!await file.exists()) return;
    try {
      final c = VideoPlayerController.file(file);
      await c.initialize();
      final startLocal = next.trimStartMs.clamp(0, next.trimEndMs);
      if (startLocal > 0) {
        await c.seekTo(Duration(milliseconds: startLocal));
      }
      // Drop if another preload won the race
      if (_preloaded != null) {
        await c.dispose();
        return;
      }
      _preloaded = c;
      _preloadedClipId = next.id;
    } catch (e) {
      debugPrint('Preload failed: $e');
    }
  }

  Future<void> _disposePreload() async {
    final c = _preloaded;
    _preloaded = null;
    _preloadedClipId = null;
    if (c != null) {
      try {
        await c.dispose();
      } catch (_) {}
    }
  }

  Future<void> _disposeOutgoing() async {
    _transitionTimer?.cancel();
    _transitionTimer = null;
    final c = _outgoing;
    _outgoing = null;
    _transitionOpacity = 0;
    _transitionKind = null;
    if (c != null) {
      try {
        await c.dispose();
      } catch (_) {}
    }
  }

  void _startTransitionFade({
    required String kind,
    required int durationMs,
  }) {
    _transitionTimer?.cancel();
    _transitionKind = kind;
    final total = durationMs.clamp(120, 2000);
    final steps = 16;
    final stepMs = (total / steps).round().clamp(12, 60);
    var i = 0;
    // transitionOpacity field stores progress 0→1 for TransitionOverlay
    _transitionOpacity = 0;
    _transitionTimer = Timer.periodic(Duration(milliseconds: stepMs), (timer) {
      i++;
      final progress = (i / steps).clamp(0.0, 1.0);
      _transitionOpacity = progress;
      final cur = state.value;
      if (cur != null) {
        state = AsyncData(cur.copyWith(
          transitionOpacity: progress,
          transitionKind: kind,
          outgoingController: _outgoing,
          tick: cur.tick + 1,
        ));
      }
      if (i >= steps) {
        timer.cancel();
        _disposeOutgoing();
        final cur2 = state.value;
        if (cur2 != null) {
          state = AsyncData(cur2.copyWith(
            clearOutgoing: true,
            transitionOpacity: 0,
            tick: cur2.tick + 1,
          ));
        }
      }
    });
  }

  void _onControllerUpdate() {
    final current = state.value;
    final controller = current?.controller;
    if (current == null || controller == null) return;

    state = AsyncData(current.copyWith(tick: current.tick + 1));

    final clipId = current.clipId;
    if (clipId == null) return;
    final project = ref.read(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return;

    final localMs = controller.value.position.inMilliseconds;
    final projectMs = TimelinePlayback.localToProjectMs(clip, localMs);
    final clock = ref.read(timelineClockProvider(projectId).notifier);
    clock.setPosition(projectMs);

    if (!_userWantsPlay) {
      clock.setPlaying(controller.value.isPlaying);
      return;
    }

    clock.setPlaying(true);

    if (!_userWantsPlay || _advancing) return;

    final remaining = clip.trimEndMs - localMs;
    // Prefetch next clip ~1s early (eliminates spinner gap)
    if (remaining <= 1200 && remaining > 40) {
      final next = TimelinePlayback.nextAfter(
        project?.clips ?? const [],
        clip.id,
      );
      if (next != null && next.type == ClipType.video) {
        // fire-and-forget
        _ensurePreload(next);
      }
    }

    final duration = controller.value.duration.inMilliseconds;
    final atTrimEnd = TimelinePlayback.isAtClipEnd(clip, localMs, toleranceMs: 40);
    final nearFileEnd = duration > 0 && localMs >= duration - 80;
    if (remaining <= 40 || atTrimEnd || nearFileEnd) {
      if (controller.value.isPlaying && remaining > 120) {
        return;
      }
      _advanceFrom(clip);
    }
  }

  Future<void> _advanceFrom(ClipModel finished) async {
    if (_advancing || !_userWantsPlay) return;
    _advancing = true;
    try {
      final project = ref.read(editorProvider(projectId)).value;
      if (project == null) {
        await pausePlayback();
        return;
      }
      final next = TimelinePlayback.nextAfter(project.clips, finished.id);
      if (next == null) {
        ref
            .read(timelineClockProvider(projectId).notifier)
            .setPosition(finished.timelineEndMs);
        await pausePlayback();
        return;
      }

      ref
          .read(timelineClockProvider(projectId).notifier)
          .setPosition(next.timelineStartMs);

      final kind = finished.transitionId;
      final wantsFade = kind != 'none' && kind.isNotEmpty;
      final fadeMs = finished.transitionDurationMs.clamp(120, 2000);

      if (wantsFade) {
        _transitionKind = kind;
      } else {
        _transitionKind = null;
        await _disposeOutgoing();
      }

      // Silent swap — no AsyncLoading spinner
      if (_loadedClipId != next.id) {
        final result = await _loadClip(next, silent: true);
        if (!_userWantsPlay) return;
        state = AsyncData(result);
        if (wantsFade && _outgoing != null) {
          _startTransitionFade(kind: _transitionKind ?? 'crossfade', durationMs: fadeMs);
        } else {
          await _disposeOutgoing();
        }
      }

      // Selection update without re-triggering a hard load (listener skips if same visual)
      ref.read(selectedClipIdProvider(projectId).notifier).state = next.id;

      await _playLoadedClipFromClock();
    } finally {
      _advancing = false;
    }
  }

  /// Seek + play the currently loaded clip according to the timeline clock.
  Future<void> _playLoadedClipFromClock() async {
    final project = ref.read(editorProvider(projectId)).value;
    if (project == null || !_userWantsPlay) return;

    final pos = ref.read(timelineClockProvider(projectId)).positionMs;
    final clip = project.clips.where((c) => c.id == _loadedClipId).firstOrNull;
    if (clip == null) return;

    if (clip.type == ClipType.image) {
      _scheduleImageAdvance(clip, pos);
      return;
    }

    final c = _controller;
    if (c == null || !c.value.isInitialized) return;

    final local = TimelinePlayback.projectToLocalMs(clip, pos);
    await c.seekTo(Duration(milliseconds: local));
    if (!_userWantsPlay) return;
    await c.play();
    ref.read(timelineClockProvider(projectId).notifier).setPlaying(true);
  }

  void _scheduleImageAdvance(ClipModel clip, int projectPosMs) {
    _imageTimer?.cancel();
    final remaining =
        (clip.timelineEndMs - projectPosMs).clamp(50, clip.durationMs);
    // Tick the clock while the image is "playing".
    final started = DateTime.now();
    final startPos = projectPosMs;
    _imageTimer = Timer.periodic(const Duration(milliseconds: 50), (t) {
      if (!_userWantsPlay) {
        t.cancel();
        return;
      }
      final elapsed = DateTime.now().difference(started).inMilliseconds;
      final now = (startPos + elapsed).clamp(startPos, clip.timelineEndMs);
      ref.read(timelineClockProvider(projectId).notifier).setPosition(now);
      if (elapsed >= remaining) {
        t.cancel();
        _advanceFrom(clip);
      }
    });
  }

  // ── Public transport API ──────────────────────────────────────────

  Future<void> startPlayback() async {
    final project = ref.read(editorProvider(projectId)).value;
    if (project == null || project.clips.isEmpty) return;

    _userWantsPlay = true;
    ref.read(timelineClockProvider(projectId).notifier).setPlaying(true);

    var pos = ref.read(timelineClockProvider(projectId)).positionMs;
    // If we're at/past the end, restart from the beginning.
    if (pos >= project.durationMs - 40) {
      pos = 0;
      ref.read(timelineClockProvider(projectId).notifier).setPosition(0);
    }

    var clip = TimelinePlayback.visualClipAt(project.clips, pos);
    clip ??= TimelinePlayback.nextVisualAtOrAfter(project.clips, pos);
    if (clip == null) {
      await pausePlayback();
      return;
    }

    if (pos < clip.timelineStartMs) {
      pos = clip.timelineStartMs;
      ref.read(timelineClockProvider(projectId).notifier).setPosition(pos);
    }

    if (_loadedClipId != clip.id) {
      ref.read(selectedClipIdProvider(projectId).notifier).state = clip.id;
      final result = await _loadClip(clip);
      if (!_userWantsPlay) return;
      state = AsyncData(result);
    }

    await _playLoadedClipFromClock();
  }

  Future<void> pausePlayback() async {
    _userWantsPlay = false;
    _imageTimer?.cancel();
    _imageTimer = null;
    final c = _controller;
    if (c != null && c.value.isInitialized && c.value.isPlaying) {
      await c.pause();
    }
    ref.read(timelineClockProvider(projectId).notifier).setPlaying(false);
  }

  Future<void> togglePlay() async {
    final playing = ref.read(timelineClockProvider(projectId)).isPlaying ||
        _userWantsPlay;
    if (playing) {
      await pausePlayback();
    } else {
      await startPlayback();
    }
  }

  Future<void> play() => startPlayback();
  Future<void> pause() => pausePlayback();

  /// Seek within the *loaded* video (transport slider). Also updates clock.
  Future<void> seek(Duration position) async {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    await c.seekTo(position);
    final project = ref.read(editorProvider(projectId)).value;
    final clip =
        project?.clips.where((c) => c.id == _loadedClipId).firstOrNull;
    if (clip != null) {
      final projectMs =
          TimelinePlayback.localToProjectMs(clip, position.inMilliseconds);
      ref.read(timelineClockProvider(projectId).notifier).setPosition(projectMs);
    }
  }

  Future<void> _disposeController() async {
    final c = _controller;
    _controller = null;
    _loadedClipId = null;
    if (c != null) {
      c.removeListener(_onControllerUpdate);
      try {
        await c.dispose();
      } catch (_) {}
    }
  }
}

final previewProvider = AsyncNotifierProvider.family<PreviewControllerNotifier,
    PreviewState, String>(
  PreviewControllerNotifier.new,
);

class PreviewState {
  final String? clipId;
  final String? displayName;
  final bool isImage;
  final String? error;
  final VideoPlayerController? controller;
  final VideoPlayerController? outgoingController;
  final double transitionOpacity;
  final String? transitionKind;
  final int tick;

  const PreviewState({
    this.clipId,
    this.displayName,
    this.isImage = false,
    this.error,
    this.controller,
    this.outgoingController,
    this.transitionOpacity = 0,
    this.transitionKind,
    this.tick = 0,
  });

  const PreviewState.empty()
      : clipId = null,
        displayName = null,
        isImage = false,
        error = null,
        controller = null,
        outgoingController = null,
        transitionOpacity = 0,
        transitionKind = null,
        tick = 0;

  bool get hasVideo =>
      controller != null &&
      controller!.value.isInitialized &&
      error == null &&
      !isImage;

  bool get isPlaying => controller?.value.isPlaying ?? false;

  Duration get position => controller?.value.position ?? Duration.zero;

  Duration get duration => controller?.value.duration ?? Duration.zero;

  bool get hasTransitionLayer =>
      outgoingController != null &&
      outgoingController!.value.isInitialized &&
      transitionOpacity < 0.999;

  PreviewState copyWith({
    String? clipId,
    String? displayName,
    bool? isImage,
    String? error,
    VideoPlayerController? controller,
    VideoPlayerController? outgoingController,
    double? transitionOpacity,
    String? transitionKind,
    int? tick,
    bool clearOutgoing = false,
  }) {
    return PreviewState(
      clipId: clipId ?? this.clipId,
      displayName: displayName ?? this.displayName,
      isImage: isImage ?? this.isImage,
      error: error ?? this.error,
      controller: controller ?? this.controller,
      outgoingController: clearOutgoing
          ? null
          : (outgoingController ?? this.outgoingController),
      transitionOpacity:
          clearOutgoing ? 0 : (transitionOpacity ?? this.transitionOpacity),
      transitionKind:
          clearOutgoing ? null : (transitionKind ?? this.transitionKind),
      tick: tick ?? this.tick,
    );
  }
}
