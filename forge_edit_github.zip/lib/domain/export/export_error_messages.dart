class ExportErrorMessages {
  static String humanize(String? raw) {
    if (raw == null || raw.trim().isEmpty) {
      return 'Export başarısız. Tekrar dene veya klipleri sadeleştir.';
    }
    final s = raw.toLowerCase();
    if (s.contains('xfade') || s.contains('merge')) {
      return 'Geçiş birleştirilemedi. Geçişleri “Kesme” yapıp tekrar dene.';
    }
    if (s.contains('drawtext') || s.contains('font') || s.contains('text')) {
      return 'Metin katmanı uygulanamadı. Yazı stillerini sadeleştirip dene.';
    }
    if (s.contains('audio') || s.contains('amix') || s.contains('atempo')) {
      return 'Ses karışımı başarısız. Ses kliplerini kaldırıp tekrar dene.';
    }
    if (s.contains('chromakey')) {
      return 'Yeşil ekran filtresi başarısız. Filtreyi kaldırıp dene.';
    }
    if (s.contains('no space') || s.contains('enospc')) {
      return 'Depolama dolu. Yer açıp tekrar dene.';
    }
    if (s.contains('permission') || s.contains('eacces')) {
      return 'Dosya izni yok. Uygulama depolama iznini kontrol et.';
    }
    if (s.contains('cancel')) {
      return 'Export iptal edildi.';
    }
    final short = raw.length > 120 ? '${raw.substring(0, 120)}…' : raw;
    return 'Export hatası: $short';
  }
}
