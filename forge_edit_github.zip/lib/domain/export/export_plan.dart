import 'dart:io';

import '../models/clip_model.dart';
import '../models/project_model.dart';
import 'export_filter_map.dart';
import 'export_text_style.dart';

class ExportSettings {
  final int width;
  final int height;
  final int fps;
  /// 'h264' software libx264 (GPL full kit)
  final String videoCodec;
  /// draft | balanced | high
  final String quality;

  const ExportSettings({
    this.width = 1280,
    this.height = 720,
    this.fps = 30,
    this.videoCodec = 'libx264',
    this.quality = 'balanced',
  });

  /// FFmpeg x264 params for quality preset.
  String get x264Params {
    switch (quality) {
      case 'draft':
        return '-preset ultrafast -crf 28';
      case 'high':
        return '-preset medium -crf 18';
      case 'balanced':
      default:
        return '-preset veryfast -crf 23';
    }
  }
}

class ExportValidationIssue {
  final String message;
  const ExportValidationIssue(this.message);
}

class ExportPlan {
  final ProjectModel project;
  final ExportSettings settings;
  final List<ClipModel> videoTrack;
  final List<ClipModel> audioTrack;
  final List<ClipModel> textTrack;
  final List<ClipModel> overlayTrack;
  final List<ExportValidationIssue> issues;

  ExportPlan({
    required this.project,
    required this.settings,
    required this.videoTrack,
    required this.audioTrack,
    required this.textTrack,
    this.overlayTrack = const [],
    required this.issues,
  });

  bool get canExport =>
      issues.isEmpty && (videoTrack.isNotEmpty || textTrack.isNotEmpty);

  /// Build a pure plan + validate media files exist.
  static Future<ExportPlan> build(
    ProjectModel project, {
    ExportSettings settings = const ExportSettings(),
  }) async {
    final issues = <ExportValidationIssue>[];
    if (project.clips.isEmpty) {
      issues.add(const ExportValidationIssue('Proje boş — klip ekleyin'));
    }

    final video = project.clips
        .where((c) =>
            c.trackIndex == TrackIndex.video &&
            (c.type == ClipType.video || c.type == ClipType.image))
        .toList()
      ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));

    final audio = project.clips
        .where((c) => c.type == ClipType.audio)
        .toList()
      ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));

    final text = project.clips
        .where((c) => c.type == ClipType.text)
        .toList();

    final overlay = project.clips
        .where((c) =>
            c.trackIndex == TrackIndex.overlay &&
            (c.type == ClipType.video || c.type == ClipType.image))
        .toList()
      ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));

    for (final c in [...video, ...audio, ...overlay]) {
      if (c.filePath.isEmpty) {
        issues.add(ExportValidationIssue('Dosya yolu boş: ${c.displayName}'));
        continue;
      }
      final f = File(c.filePath);
      if (!await f.exists()) {
        issues.add(ExportValidationIssue(
          'Dosya bulunamadı: ${c.displayName}\n${c.filePath}',
        ));
      } else if (await f.length() == 0) {
        issues.add(ExportValidationIssue('Dosya boş: ${c.displayName}'));
      }
    }

    if (video.isEmpty && text.isEmpty) {
      issues.add(const ExportValidationIssue(
        'Dışa aktarılacak video veya metin klibi yok',
      ));
    }

    // Unsupported transitions — warn only, still export hard cuts
    for (final c in video) {
      if (c.transitionId != 'none' &&
          !supportedTransitionExport.contains(c.transitionId)) {
        issues.add(ExportValidationIssue(
          'Geçiş "${c.transitionId}" desteklenmiyor; kesme kullanılacak '
          '(${c.displayName})',
        ));
      }
    }
    // Treat unsupported transition as soft warning — remove from blocking
    // Only hard-fail on missing files / empty project
    final hard = issues
        .where((i) =>
            i.message.contains('bulunamadı') ||
            i.message.contains('boş') ||
            i.message.contains('Proje boş') ||
            i.message.contains('Dışa aktarılacak'))
        .toList();

    return ExportPlan(
      project: project,
      settings: settings,
      videoTrack: video,
      audioTrack: audio,
      textTrack: text,
      overlayTrack: overlay,
      issues: hard.isNotEmpty ? hard : [],
    );
  }

  /// FFmpeg scale+pad to target size without stretching.
  String get scalePadVf =>
      'scale=${settings.width}:${settings.height}:force_original_aspect_ratio=decrease,'
      'pad=${settings.width}:${settings.height}:(ow-iw)/2:(oh-ih)/2';

  /// Timeline end = max of all clips' timelineEndMs (gaps included).
  int get timelineDurationMs {
    var maxEnd = 0;
    for (final c in [...videoTrack, ...audioTrack, ...textTrack]) {
      if (c.timelineEndMs > maxEnd) maxEnd = c.timelineEndMs;
    }
    return maxEnd;
  }

  /// Build per-clip intermediate commands.
  /// Video segments keep source audio (trimmed); image segments get silent aac
  /// so concat has a consistent A/V layout.
  List<String> buildSegmentCommands({
    required String workDir,
    required List<String> segmentPathsOut,
  }) {
    final cmds = <String>[];
    segmentPathsOut.clear();
    for (var i = 0; i < videoTrack.length; i++) {
      final c = videoTrack[i];
      final out = '$workDir/seg_$i.mp4';
      segmentPathsOut.add(out);

      final filters = <String>[scalePadVf];
      final color = ExportFilterMap.videoFilter(c.filterId, c.filterIntensity);
      if (color.isNotEmpty) filters.add(color);

      if (c.type == ClipType.image) {
        final durSec = (c.durationMs / 1000.0).clamp(0.1, 3600.0);
        final d = durSec.toStringAsFixed(3);
        final imgVf = <String>[];
        if (c.flipHorizontal) {
          imgVf.add('hflip');
        }
        if (c.rotationDegrees.abs() > 0.5) {
          final rad = (-c.rotationDegrees * 3.141592653589793 / 180.0)
              .toStringAsFixed(6);
          imgVf.add('rotate=$rad:ow=rotw($rad):oh=roth($rad):c=black@0');
        }
        if ((c.scale - 1.0).abs() > 0.01) {
          final s = c.scale.clamp(0.1, 3.0).toStringAsFixed(4);
          imgVf.add('scale=iw*$s:ih*$s');
        }
        imgVf.addAll(filters);
        if (c.opacity < 0.999) {
          final o = c.opacity.clamp(0.0, 1.0).toStringAsFixed(3);
          imgVf.add(
            'format=rgba,colorchannelmixer=aa=$o,format=yuv420p',
          );
        }
        final vf = imgVf.join(',');
        cmds.add(
          '-loop 1 -t $d -i "${c.filePath}" '
          '-f lavfi -t $d -i anullsrc=channel_layout=stereo:sample_rate=44100 '
          '-vf "$vf" -r ${settings.fps} '
          '-c:v ${settings.videoCodec} -pix_fmt yuv420p '
          '-c:a aac -b:a 128k -shortest -y "$out"',
        );
      } else {
        // Input window = trimmed source length (before speed).
        final trimmedMs =
            (c.trimEndMs - c.trimStartMs).clamp(1, c.sourceDurationMs > 0 ? c.sourceDurationMs : 1 << 30);
        final ss = (c.trimStartMs / 1000.0).toStringAsFixed(3);
        final inputT = (trimmedMs / 1000.0).clamp(0.1, 3600.0).toStringAsFixed(3);
        // Output duration accounts for speed (durationMs = trimmed / speed).
        final outT = (c.durationMs / 1000.0).clamp(0.1, 3600.0).toStringAsFixed(3);

        final vfParts = <String>[];
        // Speed: stretch/compress timestamps
        final spd = c.speed <= 0 ? 1.0 : c.speed;
        if ((spd - 1.0).abs() > 0.001) {
          vfParts.add('setpts=PTS/${spd.toStringAsFixed(4)}');
        }
        if (c.reversed) {
          vfParts.add('reverse');
        }
        // Rotation (degrees, clockwise positive in UI → FFmpeg rotate uses radians CCW)
        if (c.flipHorizontal) {
          vfParts.add('hflip');
        }
        if (c.rotationDegrees.abs() > 0.5) {
          final rad = (-c.rotationDegrees * 3.141592653589793 / 180.0)
              .toStringAsFixed(6);
          vfParts.add(
            'rotate=$rad:ow=rotw($rad):oh=roth($rad):c=black@0',
          );
        }
        // Optional scale (clip.scale is 1.0 = 100%)
        if ((c.scale - 1.0).abs() > 0.01) {
          final s = c.scale.clamp(0.1, 3.0).toStringAsFixed(4);
          vfParts.add('scale=iw*$s:ih*$s');
        }
        vfParts.addAll(filters);
        if (c.opacity < 0.999) {
          final o = c.opacity.clamp(0.0, 1.0).toStringAsFixed(3);
          // Flatten alpha onto black (timeline background).
          vfParts.add(
            'format=rgba,colorchannelmixer=aa=$o,format=yuv420p',
          );
        }
        if (c.fadeInMs > 0) {
          final fin = (c.fadeInMs / 1000.0).clamp(0.01, 30.0).toStringAsFixed(3);
          vfParts.add('fade=t=in:st=0:d=$fin');
        }
        if (c.fadeOutMs > 0) {
          final clipDur = (c.durationMs / 1000.0).clamp(0.1, 3600.0);
          final fout = (c.fadeOutMs / 1000.0).clamp(0.01, 30.0);
          final st = (clipDur - fout).clamp(0.0, 3600.0).toStringAsFixed(3);
          vfParts.add('fade=t=out:st=$st:d=${fout.toStringAsFixed(3)}');
        }
        final fullVf = vfParts.join(',');

        // Audio tempo must match video speed (atempo range 0.5–2.0; chain if needed)
        final afParts = <String>[];
        final tempo = _atempoChain(spd);
        if (tempo.isNotEmpty) afParts.add(tempo);
        if (c.reversed) afParts.add('areverse');
        if (c.volume < 0.001) {
          afParts.add('volume=0');
        } else if ((c.volume - 1.0).abs() > 0.01) {
          afParts.add('volume=${c.volume.clamp(0.0, 2.0).toStringAsFixed(3)}');
        }
        final af = afParts.join(',');

        final afArg = af.isEmpty ? '' : '-af "$af" ';
        cmds.add(
          '-ss $ss -t $inputT -i "${c.filePath}" '
          '-vf "$fullVf" -r ${settings.fps} '
          '$afArg'
          '-map 0:v:0 -map 0:a? '
          '-c:v ${settings.videoCodec} -pix_fmt yuv420p '
          '-c:a aac -b:a 128k -ar 44100 -ac 2 '
          '-t $outT -y "$out"',
        );
      }
    }
    return cmds;
  }

  String buildConcatListFile(List<String> segmentPaths) {
    final b = StringBuffer();
    for (final p in segmentPaths) {
      final escaped = p.replaceAll("'", r"'\''");
      b.writeln("file '$escaped'");
    }
    return b.toString();
  }

  /// Drawtext filters using [ExportTextStyle] (catalog style → FFmpeg).
  ///
  /// [fontFileRegular] / [fontFileBold] must already be filter-graph escaped
  /// (':' → '\:'). Bold is used when the style weight is ≥ 600.
  String? buildDrawtextFilter({
    String? fontFileRegular,
    String? fontFileBold,
  }) {
    if (textTrack.isEmpty) return null;
    final parts = <String>[];
    for (final t in textTrack) {
      final style = ExportTextStyle.fromClip(
        t,
        frameWidth: settings.width,
        frameHeight: settings.height,
      );
      final font = style.preferBold
          ? (fontFileBold ?? fontFileRegular)
          : (fontFileRegular ?? fontFileBold);
      parts.add(style.toDrawtext(fontFile: font));
    }
    return parts.join(',');
  }

  /// Backward-compatible single-font overload used by older call sites.
  String? buildDrawtextFilterLegacy({String? fontFile}) =>
      buildDrawtextFilter(fontFileRegular: fontFile, fontFileBold: fontFile);

  static const supportedTransitionExport = {
    'none',
    'crossfade',
    'fadeBlack',
    'fadeWhite',
    'wipeLeft',
    'wipeRight',
    'wipeUp',
    'wipeDown',
    'slideLeft',
    'slideRight',
    'slideUp',
    'slideDown',
    'circleOpen',
    'circleClose',
    'dissolve',
    'pixelize',
    'radial',
    'diagTl',
    'hblur',
    'distance',
  };

  /// Whether [transitionId] should use FFmpeg xfade (not hard cut).
  static bool isXfadeTransition(String transitionId) =>
      transitionId != 'none' &&
      transitionId.isNotEmpty &&
      supportedTransitionExport.contains(transitionId);

  /// FFmpeg xfade transition name.
  static String xfadeName(String transitionId) {
    switch (transitionId) {
      case 'crossfade':
      case 'dissolve':
        return 'fade';
      case 'fadeBlack':
        return 'fadeblack';
      case 'fadeWhite':
        return 'fadewhite';
      case 'wipeLeft':
        return 'wipeleft';
      case 'wipeRight':
        return 'wiperight';
      case 'wipeUp':
        return 'wipeup';
      case 'wipeDown':
        return 'wipedown';
      case 'slideLeft':
        return 'slideleft';
      case 'slideRight':
        return 'slideright';
      case 'slideUp':
        return 'slideup';
      case 'slideDown':
        return 'slidedown';
      case 'circleOpen':
        return 'circleopen';
      case 'circleClose':
        return 'circleclose';
      case 'pixelize':
        return 'pixelize';
      case 'radial':
        return 'radial';
      case 'diagTl':
        return 'diagtl';
      case 'hblur':
        return 'hblur';
      case 'distance':
        return 'distance';
      default:
        return 'fade';
    }
  }

  /// atempo chain for speed in (0, ∞); each filter limited to 0.5–2.0.
  static String _atempoChain(double speed) {
    if ((speed - 1.0).abs() < 0.001) return '';
    var s = speed.clamp(0.05, 8.0);
    final parts = <String>[];
    // Bring into range by repeated atempo
    while (s > 2.0 + 1e-6) {
      parts.add('atempo=2.0');
      s /= 2.0;
    }
    while (s < 0.5 - 1e-6) {
      parts.add('atempo=0.5');
      s /= 0.5;
    }
    parts.add('atempo=${s.toStringAsFixed(4)}');
    return parts.join(',');
  }
}

