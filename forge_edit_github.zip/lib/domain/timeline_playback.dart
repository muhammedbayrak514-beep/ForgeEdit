import 'models/clip_model.dart';

/// Pure helpers for multi-clip continuous playback.
///
/// Visual clips = video + image (what the preview surface shows).
/// Audio/text ride along on the clock but do not own the video surface.
class TimelinePlayback {
  TimelinePlayback._();

  static bool isVisual(ClipModel c) =>
      c.type == ClipType.video || c.type == ClipType.image;

  /// Visual clips sorted by timeline start.
  static List<ClipModel> visualClipsSorted(List<ClipModel> clips) {
    final list = clips.where(isVisual).toList()
      ..sort((a, b) {
        final byStart = a.timelineStartMs.compareTo(b.timelineStartMs);
        if (byStart != 0) return byStart;
        return a.id.compareTo(b.id);
      });
    return list;
  }

  /// Clip that covers [projectMs], if any.
  static ClipModel? visualClipAt(List<ClipModel> clips, int projectMs) {
    final visual = visualClipsSorted(clips);
    for (final c in visual) {
      if (projectMs >= c.timelineStartMs && projectMs < c.timelineEndMs) {
        return c;
      }
    }
    return null;
  }

  /// First visual clip that starts at or after [projectMs].
  static ClipModel? nextVisualAtOrAfter(List<ClipModel> clips, int projectMs) {
    final visual = visualClipsSorted(clips);
    for (final c in visual) {
      if (c.timelineEndMs > projectMs) {
        // Prefer one that still has remaining time
        if (projectMs < c.timelineEndMs) return c;
      }
    }
    return null;
  }

  /// The visual clip immediately after [currentId] on the timeline.
  static ClipModel? nextAfter(List<ClipModel> clips, String currentId) {
    final visual = visualClipsSorted(clips);
    final idx = visual.indexWhere((c) => c.id == currentId);
    if (idx < 0 || idx + 1 >= visual.length) return null;
    return visual[idx + 1];
  }

  /// Map project time → local media time (ms from file start), clamped to trim.
  static int projectToLocalMs(ClipModel clip, int projectMs) {
    final within = (projectMs - clip.timelineStartMs).clamp(0, clip.durationMs);
    // durationMs already accounts for speed; local file time uses trim window
    final local = clip.trimStartMs + within;
    return local.clamp(clip.trimStartMs, clip.trimEndMs);
  }

  /// Map local media time → project time.
  static int localToProjectMs(ClipModel clip, int localMs) {
    final within = (localMs - clip.trimStartMs).clamp(0, clip.durationMs);
    return clip.timelineStartMs + within;
  }

  /// True when local playback is at (or past) the trimmed end.
  static bool isAtClipEnd(ClipModel clip, int localMs, {int toleranceMs = 80}) {
    return localMs >= clip.trimEndMs - toleranceMs;
  }
}
