import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// A named text appearance preset for overlay clips.
class TextStyleDef {
  final String id;
  final String label;
  final String category;
  /// Key used by [TextStyleResolver].
  final String fontKey;
  final FontWeight weight;
  final FontStyle fontStyle;
  final double letterSpacing;
  final double height;
  /// If non-null, overrides clip color when style is applied.
  final int? presetColorArgb;
  final bool uppercase;
  final double shadowBlur;
  final Offset shadowOffset;
  final int shadowColorArgb;

  const TextStyleDef({
    required this.id,
    required this.label,
    required this.category,
    required this.fontKey,
    this.weight = FontWeight.w500,
    this.fontStyle = FontStyle.normal,
    this.letterSpacing = 0,
    this.height = 1.2,
    this.presetColorArgb,
    this.uppercase = false,
    this.shadowBlur = 0,
    this.shadowOffset = Offset.zero,
    this.shadowColorArgb = 0xFF000000,
  });

  List<Shadow>? get shadows {
    if (shadowBlur <= 0 && shadowOffset == Offset.zero) return null;
    return [
      Shadow(
        color: Color(shadowColorArgb),
        blurRadius: shadowBlur,
        offset: shadowOffset,
      ),
    ];
  }
}

/// Resolves [TextStyleDef.fontKey] + clip overrides into a Flutter [TextStyle].
class TextStyleResolver {
  TextStyleResolver._();

  static TextStyle resolve({
    required TextStyleDef def,
    required double fontSize,
    required int colorArgb,
  }) {
    final color = Color(def.presetColorArgb ?? colorArgb);
    final base = _font(
      def.fontKey,
      fontSize: fontSize,
      fontWeight: def.weight,
      fontStyle: def.fontStyle,
      letterSpacing: def.letterSpacing,
      height: def.height,
      color: color,
    );
    final shadows = def.shadows;
    if (shadows == null) return base;
    return base.copyWith(shadows: shadows);
  }

  static String displayText(String raw, TextStyleDef def) {
    return def.uppercase ? raw.toUpperCase() : raw;
  }

  static TextStyle _font(
    String key, {
    required double fontSize,
    required FontWeight fontWeight,
    required FontStyle fontStyle,
    required double letterSpacing,
    required double height,
    required Color color,
  }) {
    switch (key) {
      case 'roboto':
        return GoogleFonts.roboto(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'robotoCondensed':
        return GoogleFonts.robotoCondensed(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'robotoMono':
        return GoogleFonts.robotoMono(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'openSans':
        return GoogleFonts.openSans(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'lato':
        return GoogleFonts.lato(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'montserrat':
        return GoogleFonts.montserrat(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'poppins':
        return GoogleFonts.poppins(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'raleway':
        return GoogleFonts.raleway(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'oswald':
        return GoogleFonts.oswald(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'playfair':
        return GoogleFonts.playfairDisplay(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'merriweather':
        return GoogleFonts.merriweather(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'nunito':
        return GoogleFonts.nunito(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'ubuntu':
        return GoogleFonts.ubuntu(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'inter':
        return GoogleFonts.inter(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'bebas':
        return GoogleFonts.bebasNeue(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'pacifico':
        return GoogleFonts.pacifico(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'dancing':
        return GoogleFonts.dancingScript(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'lobster':
        return GoogleFonts.lobster(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'caveat':
        return GoogleFonts.caveat(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'indieFlower':
        return GoogleFonts.indieFlower(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'pressStart':
        return GoogleFonts.pressStart2p(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'orbitron':
        return GoogleFonts.orbitron(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'rubik':
        return GoogleFonts.rubik(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'workSans':
        return GoogleFonts.workSans(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'sourceSans':
        return GoogleFonts.sourceSans3(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'ptSans':
        return GoogleFonts.ptSans(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'notoSans':
        return GoogleFonts.notoSans(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'crimson':
        return GoogleFonts.crimsonText(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'libreBaskerville':
        return GoogleFonts.libreBaskerville(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'cinzel':
        return GoogleFonts.cinzel(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'anton':
        return GoogleFonts.anton(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'archivoBlack':
        return GoogleFonts.archivoBlack(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'bangers':
        return GoogleFonts.bangers(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'permanentMarker':
        return GoogleFonts.permanentMarker(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'shadowsIntoLight':
        return GoogleFonts.shadowsIntoLight(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'greatVibes':
        return GoogleFonts.greatVibes(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'satisfy':
        return GoogleFonts.satisfy(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'comfortaa':
        return GoogleFonts.comfortaa(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'exo2':
        return GoogleFonts.exo2(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'rajdhani':
        return GoogleFonts.rajdhani(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'titillium':
        return GoogleFonts.titilliumWeb(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'quicksand':
        return GoogleFonts.quicksand(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'josefin':
        return GoogleFonts.josefinSans(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'cabin':
        return GoogleFonts.cabin(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'mulish':
        return GoogleFonts.mulish(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'manrope':
        return GoogleFonts.manrope(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'dmSans':
        return GoogleFonts.dmSans(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'spaceGrotesk':
        return GoogleFonts.spaceGrotesk(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'syne':
        return GoogleFonts.syne(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'barlow':
        return GoogleFonts.barlow(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      case 'fjalla':
        return GoogleFonts.fjallaOne(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
      default:
        return GoogleFonts.roboto(fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, letterSpacing: letterSpacing, height: height, color: color);
    }
  }
}


/// ~100 built-in overlay text styles.
class TextStyleCatalog {
  TextStyleCatalog._();

  static const String defaultId = 'plain_white';

  static TextStyleDef byId(String id) {
    return all.firstWhere(
      (s) => s.id == id,
      orElse: () => all.first,
    );
  }

  static List<String> get categories {
    final set = <String>{};
    for (final s in all) {
      set.add(s.category);
    }
    return set.toList();
  }

  static List<TextStyleDef> byCategory(String category) =>
      all.where((s) => s.category == category).toList();

  static const List<TextStyleDef> all = [
    // ── Minimal / Plain (10) ──
    TextStyleDef(id: 'plain_white', label: 'Sade Beyaz', category: 'Minimal', fontKey: 'roboto', weight: FontWeight.w400, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'plain_black', label: 'Sade Siyah', category: 'Minimal', fontKey: 'roboto', weight: FontWeight.w400, presetColorArgb: 0xFF111111),
    TextStyleDef(id: 'plain_gray', label: 'Sade Gri', category: 'Minimal', fontKey: 'inter', weight: FontWeight.w400, presetColorArgb: 0xFFB0B0B0),
    TextStyleDef(id: 'minimal_light', label: 'İnce Açık', category: 'Minimal', fontKey: 'inter', weight: FontWeight.w300, letterSpacing: 1.2, presetColorArgb: 0xFFF5F5F5),
    TextStyleDef(id: 'minimal_medium', label: 'Orta Minimal', category: 'Minimal', fontKey: 'dmSans', weight: FontWeight.w500, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'minimal_bold', label: 'Kalın Minimal', category: 'Minimal', fontKey: 'manrope', weight: FontWeight.w700, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'minimal_caps', label: 'Minimal Caps', category: 'Minimal', fontKey: 'workSans', weight: FontWeight.w600, letterSpacing: 3, uppercase: true, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'minimal_mono', label: 'Mono Minimal', category: 'Minimal', fontKey: 'robotoMono', weight: FontWeight.w400, letterSpacing: 0.5, presetColorArgb: 0xFFE0E0E0),
    TextStyleDef(id: 'minimal_soft_shadow', label: 'Yumuşak Gölge', category: 'Minimal', fontKey: 'inter', weight: FontWeight.w500, shadowBlur: 6, shadowOffset: const Offset(0, 2), presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'minimal_outline_feel', label: 'Hafif Vurgu', category: 'Minimal', fontKey: 'mulish', weight: FontWeight.w600, letterSpacing: 0.8, shadowBlur: 1, shadowOffset: const Offset(1, 1), presetColorArgb: 0xFFFFFFFF),

    // ── Modern (12) ──
    TextStyleDef(id: 'modern_sans', label: 'Modern Sans', category: 'Modern', fontKey: 'poppins', weight: FontWeight.w600, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'modern_clean', label: 'Temiz Modern', category: 'Modern', fontKey: 'montserrat', weight: FontWeight.w500, letterSpacing: 0.5, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'modern_bold', label: 'Modern Kalın', category: 'Modern', fontKey: 'montserrat', weight: FontWeight.w800, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'modern_thin', label: 'Modern İnce', category: 'Modern', fontKey: 'raleway', weight: FontWeight.w200, letterSpacing: 2, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'modern_space', label: 'Space Grotesk', category: 'Modern', fontKey: 'spaceGrotesk', weight: FontWeight.w600, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'modern_syne', label: 'Syne Başlık', category: 'Modern', fontKey: 'syne', weight: FontWeight.w700, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'modern_barlow', label: 'Barlow', category: 'Modern', fontKey: 'barlow', weight: FontWeight.w600, letterSpacing: 1, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'modern_blue', label: 'Mavi Modern', category: 'Modern', fontKey: 'poppins', weight: FontWeight.w600, presetColorArgb: 0xFF4FC3F7),
    TextStyleDef(id: 'modern_mint', label: 'Mint Modern', category: 'Modern', fontKey: 'manrope', weight: FontWeight.w600, presetColorArgb: 0xFF26A69A),
    TextStyleDef(id: 'modern_coral', label: 'Mercan', category: 'Modern', fontKey: 'dmSans', weight: FontWeight.w700, presetColorArgb: 0xFFFF7043),
    TextStyleDef(id: 'modern_wide', label: 'Geniş Harf', category: 'Modern', fontKey: 'montserrat', weight: FontWeight.w500, letterSpacing: 4, uppercase: true, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'modern_shadow', label: 'Modern Gölge', category: 'Modern', fontKey: 'poppins', weight: FontWeight.w700, shadowBlur: 8, shadowOffset: const Offset(2, 3), presetColorArgb: 0xFFFFFFFF),

    // ── Classic / Serif (10) ──
    TextStyleDef(id: 'classic_serif', label: 'Klasik Serif', category: 'Klasik', fontKey: 'merriweather', weight: FontWeight.w400, presetColorArgb: 0xFFFFF8E1),
    TextStyleDef(id: 'classic_playfair', label: 'Playfair', category: 'Klasik', fontKey: 'playfair', weight: FontWeight.w600, presetColorArgb: 0xFFFFFDE7),
    TextStyleDef(id: 'classic_playfair_italic', label: 'Playfair İtalik', category: 'Klasik', fontKey: 'playfair', weight: FontWeight.w500, fontStyle: FontStyle.italic, presetColorArgb: 0xFFFFFDE7),
    TextStyleDef(id: 'classic_crimson', label: 'Crimson', category: 'Klasik', fontKey: 'crimson', weight: FontWeight.w600, presetColorArgb: 0xFFFFF3E0),
    TextStyleDef(id: 'classic_baskerville', label: 'Baskerville', category: 'Klasik', fontKey: 'libreBaskerville', weight: FontWeight.w400, presetColorArgb: 0xFFFFF8E1),
    TextStyleDef(id: 'classic_cinzel', label: 'Cinzel Roman', category: 'Klasik', fontKey: 'cinzel', weight: FontWeight.w600, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFFFFE082),
    TextStyleDef(id: 'classic_gold', label: 'Altın Klasik', category: 'Klasik', fontKey: 'playfair', weight: FontWeight.w700, presetColorArgb: 0xFFFFD54F, shadowBlur: 4, shadowOffset: const Offset(1, 1)),
    TextStyleDef(id: 'classic_ivory', label: 'Fildişi', category: 'Klasik', fontKey: 'merriweather', weight: FontWeight.w300, presetColorArgb: 0xFFFFF8E7),
    TextStyleDef(id: 'classic_dark', label: 'Koyu Serif', category: 'Klasik', fontKey: 'libreBaskerville', weight: FontWeight.w700, presetColorArgb: 0xFF3E2723),
    TextStyleDef(id: 'classic_quote', label: 'Alıntı', category: 'Klasik', fontKey: 'playfair', weight: FontWeight.w400, fontStyle: FontStyle.italic, letterSpacing: 0.5, presetColorArgb: 0xFFFFECB3),

    // ── Bold / Display (12) ──
    TextStyleDef(id: 'bold_impact', label: 'Impact', category: 'Kalın', fontKey: 'anton', weight: FontWeight.w400, letterSpacing: 1, uppercase: true, presetColorArgb: 0xFFFFFFFF, shadowBlur: 3, shadowOffset: const Offset(2, 2)),
    TextStyleDef(id: 'bold_bebas', label: 'Bebas', category: 'Kalın', fontKey: 'bebas', weight: FontWeight.w400, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'bold_archivo', label: 'Archivo Black', category: 'Kalın', fontKey: 'archivoBlack', weight: FontWeight.w400, uppercase: true, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'bold_fjalla', label: 'Fjalla', category: 'Kalın', fontKey: 'fjalla', weight: FontWeight.w400, letterSpacing: 1, uppercase: true, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'bold_oswald', label: 'Oswald', category: 'Kalın', fontKey: 'oswald', weight: FontWeight.w700, letterSpacing: 1.5, uppercase: true, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'bold_red', label: 'Kırmızı Vurgu', category: 'Kalın', fontKey: 'anton', weight: FontWeight.w400, uppercase: true, presetColorArgb: 0xFFFF1744, shadowBlur: 4, shadowOffset: const Offset(2, 2)),
    TextStyleDef(id: 'bold_yellow', label: 'Sarı Başlık', category: 'Kalın', fontKey: 'bebas', weight: FontWeight.w400, uppercase: true, presetColorArgb: 0xFFFFEE58, shadowBlur: 2, shadowOffset: const Offset(1, 1)),
    TextStyleDef(id: 'bold_block', label: 'Blok', category: 'Kalın', fontKey: 'archivoBlack', weight: FontWeight.w400, letterSpacing: -0.5, presetColorArgb: 0xFFFFFFFF, shadowBlur: 0, shadowOffset: const Offset(3, 3), shadowColorArgb: 0xFF000000),
    TextStyleDef(id: 'bold_condensed', label: 'Condensed', category: 'Kalın', fontKey: 'robotoCondensed', weight: FontWeight.w700, letterSpacing: 0.5, uppercase: true, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'bold_sport', label: 'Spor', category: 'Kalın', fontKey: 'oswald', weight: FontWeight.w600, letterSpacing: 3, uppercase: true, presetColorArgb: 0xFF76FF03),
    TextStyleDef(id: 'bold_news', label: 'Haber', category: 'Kalın', fontKey: 'robotoCondensed', weight: FontWeight.w900, uppercase: true, presetColorArgb: 0xFFFFFFFF),
    TextStyleDef(id: 'bold_poster', label: 'Poster', category: 'Kalın', fontKey: 'anton', weight: FontWeight.w400, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFFFF6F00, shadowBlur: 6, shadowOffset: const Offset(3, 3)),

    // ── Elegant (10) ──
    TextStyleDef(id: 'elegant_script', label: 'Zarif Script', category: 'Zarif', fontKey: 'greatVibes', weight: FontWeight.w400, presetColorArgb: 0xFFFFF9C4),
    TextStyleDef(id: 'elegant_dancing', label: 'Dancing', category: 'Zarif', fontKey: 'dancing', weight: FontWeight.w600, presetColorArgb: 0xFFFFF59D),
    TextStyleDef(id: 'elegant_satisfy', label: 'Satisfy', category: 'Zarif', fontKey: 'satisfy', weight: FontWeight.w400, presetColorArgb: 0xFFFFECB3),
    TextStyleDef(id: 'elegant_thin_serif', label: 'İnce Zarif', category: 'Zarif', fontKey: 'playfair', weight: FontWeight.w300, letterSpacing: 1.5, presetColorArgb: 0xFFFFF8E1),
    TextStyleDef(id: 'elegant_rose', label: 'Gül', category: 'Zarif', fontKey: 'greatVibes', weight: FontWeight.w400, presetColorArgb: 0xFFF8BBD0),
    TextStyleDef(id: 'elegant_champagne', label: 'Şampanya', category: 'Zarif', fontKey: 'cinzel', weight: FontWeight.w400, letterSpacing: 3, uppercase: true, presetColorArgb: 0xFFFFE0B2),
    TextStyleDef(id: 'elegant_soft', label: 'Yumuşak', category: 'Zarif', fontKey: 'raleway', weight: FontWeight.w300, fontStyle: FontStyle.italic, presetColorArgb: 0xFFFCE4EC),
    TextStyleDef(id: 'elegant_night', label: 'Gece Zarif', category: 'Zarif', fontKey: 'playfair', weight: FontWeight.w500, fontStyle: FontStyle.italic, presetColorArgb: 0xFFCE93D8),
    TextStyleDef(id: 'elegant_pearl', label: 'İnci', category: 'Zarif', fontKey: 'libreBaskerville', weight: FontWeight.w400, presetColorArgb: 0xFFFAFAFA, shadowBlur: 4, shadowOffset: const Offset(0, 1)),
    TextStyleDef(id: 'elegant_invite', label: 'Davetiye', category: 'Zarif', fontKey: 'greatVibes', weight: FontWeight.w400, presetColorArgb: 0xFFFFD180),

    // ── Playful (10) ──
    TextStyleDef(id: 'play_comic', label: 'Çizgi Roman', category: 'Eğlenceli', fontKey: 'bangers', weight: FontWeight.w400, letterSpacing: 1, presetColorArgb: 0xFFFFEB3B, shadowBlur: 2, shadowOffset: const Offset(2, 2)),
    TextStyleDef(id: 'play_marker', label: 'Marker', category: 'Eğlenceli', fontKey: 'permanentMarker', weight: FontWeight.w400, presetColorArgb: 0xFFFF5722),
    TextStyleDef(id: 'play_pacifico', label: 'Pacifico', category: 'Eğlenceli', fontKey: 'pacifico', weight: FontWeight.w400, presetColorArgb: 0xFF69F0AE),
    TextStyleDef(id: 'play_indie', label: 'Indie', category: 'Eğlenceli', fontKey: 'indieFlower', weight: FontWeight.w400, presetColorArgb: 0xFF80D8FF),
    TextStyleDef(id: 'play_caveat', label: 'Caveat', category: 'Eğlenceli', fontKey: 'caveat', weight: FontWeight.w600, presetColorArgb: 0xFFFFF176),
    TextStyleDef(id: 'play_pixel', label: 'Pixel', category: 'Eğlenceli', fontKey: 'pressStart', weight: FontWeight.w400, letterSpacing: 1, presetColorArgb: 0xFF00E676),
    TextStyleDef(id: 'play_lobster', label: 'Lobster', category: 'Eğlenceli', fontKey: 'lobster', weight: FontWeight.w400, presetColorArgb: 0xFFFF8A80),
    TextStyleDef(id: 'play_comfort', label: 'Comfortaa', category: 'Eğlenceli', fontKey: 'comfortaa', weight: FontWeight.w600, presetColorArgb: 0xFFEA80FC),
    TextStyleDef(id: 'play_quicksand', label: 'Quicksand', category: 'Eğlenceli', fontKey: 'quicksand', weight: FontWeight.w600, presetColorArgb: 0xFF82B1FF),
    TextStyleDef(id: 'play_shadow_light', label: 'Shadows Light', category: 'Eğlenceli', fontKey: 'shadowsIntoLight', weight: FontWeight.w400, presetColorArgb: 0xFFFFE57F),

    // ── Neon / Glow (10) ──
    TextStyleDef(id: 'neon_cyan', label: 'Neon Cyan', category: 'Neon', fontKey: 'orbitron', weight: FontWeight.w600, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFF00E5FF, shadowBlur: 12, shadowOffset: Offset.zero, shadowColorArgb: 0xFF00E5FF),
    TextStyleDef(id: 'neon_pink', label: 'Neon Pembe', category: 'Neon', fontKey: 'orbitron', weight: FontWeight.w700, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFFFF4081, shadowBlur: 14, shadowOffset: Offset.zero, shadowColorArgb: 0xFFFF4081),
    TextStyleDef(id: 'neon_green', label: 'Neon Yeşil', category: 'Neon', fontKey: 'rajdhani', weight: FontWeight.w700, letterSpacing: 3, uppercase: true, presetColorArgb: 0xFF76FF03, shadowBlur: 12, shadowOffset: Offset.zero, shadowColorArgb: 0xFF76FF03),
    TextStyleDef(id: 'neon_purple', label: 'Neon Mor', category: 'Neon', fontKey: 'exo2', weight: FontWeight.w700, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFFE040FB, shadowBlur: 14, shadowOffset: Offset.zero, shadowColorArgb: 0xFFE040FB),
    TextStyleDef(id: 'neon_orange', label: 'Neon Turuncu', category: 'Neon', fontKey: 'titillium', weight: FontWeight.w700, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFFFF9100, shadowBlur: 12, shadowOffset: Offset.zero, shadowColorArgb: 0xFFFF9100),
    TextStyleDef(id: 'neon_blue', label: 'Neon Mavi', category: 'Neon', fontKey: 'orbitron', weight: FontWeight.w500, letterSpacing: 1.5, presetColorArgb: 0xFF2979FF, shadowBlur: 16, shadowOffset: Offset.zero, shadowColorArgb: 0xFF2979FF),
    TextStyleDef(id: 'neon_white', label: 'Neon Beyaz', category: 'Neon', fontKey: 'rajdhani', weight: FontWeight.w600, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFFFFFFFF, shadowBlur: 10, shadowOffset: Offset.zero, shadowColorArgb: 0xAAFFFFFF),
    TextStyleDef(id: 'neon_red', label: 'Neon Kırmızı', category: 'Neon', fontKey: 'exo2', weight: FontWeight.w800, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFFFF1744, shadowBlur: 14, shadowOffset: Offset.zero, shadowColorArgb: 0xFFFF1744),
    TextStyleDef(id: 'neon_soft_pink', label: 'Yumuşak Neon', category: 'Neon', fontKey: 'poppins', weight: FontWeight.w600, presetColorArgb: 0xFFFF80AB, shadowBlur: 10, shadowOffset: Offset.zero, shadowColorArgb: 0xFFFF80AB),
    TextStyleDef(id: 'neon_tech', label: 'Tech Glow', category: 'Neon', fontKey: 'orbitron', weight: FontWeight.w500, letterSpacing: 4, uppercase: true, presetColorArgb: 0xFF00B0FF, shadowBlur: 8, shadowOffset: const Offset(0, 0), shadowColorArgb: 0xFF00B0FF),

    // ── Cinematic (10) ──
    TextStyleDef(id: 'cine_title', label: 'Film Başlığı', category: 'Sinematik', fontKey: 'cinzel', weight: FontWeight.w700, letterSpacing: 4, uppercase: true, presetColorArgb: 0xFFFFF8E1, shadowBlur: 6, shadowOffset: const Offset(2, 2)),
    TextStyleDef(id: 'cine_subtitle', label: 'Altyazı', category: 'Sinematik', fontKey: 'roboto', weight: FontWeight.w400, height: 1.35, presetColorArgb: 0xFFFFFFFF, shadowBlur: 4, shadowOffset: const Offset(1, 1)),
    TextStyleDef(id: 'cine_lower_third', label: 'Lower Third', category: 'Sinematik', fontKey: 'robotoCondensed', weight: FontWeight.w500, letterSpacing: 1, presetColorArgb: 0xFFFFFFFF, shadowBlur: 3, shadowOffset: const Offset(1, 1)),
    TextStyleDef(id: 'cine_credit', label: 'Jenerik', category: 'Sinematik', fontKey: 'lato', weight: FontWeight.w300, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFFBDBDBD),
    TextStyleDef(id: 'cine_horror', label: 'Korku', category: 'Sinematik', fontKey: 'cinzel', weight: FontWeight.w900, letterSpacing: 3, uppercase: true, presetColorArgb: 0xFFB71C1C, shadowBlur: 8, shadowOffset: const Offset(2, 2), shadowColorArgb: 0xFF000000),
    TextStyleDef(id: 'cine_noir', label: 'Noir', category: 'Sinematik', fontKey: 'playfair', weight: FontWeight.w700, fontStyle: FontStyle.italic, presetColorArgb: 0xFFE0E0E0, shadowBlur: 2, shadowOffset: const Offset(1, 1)),
    TextStyleDef(id: 'cine_doc', label: 'Belgesel', category: 'Sinematik', fontKey: 'sourceSans', weight: FontWeight.w400, presetColorArgb: 0xFFFFFDE7, shadowBlur: 3, shadowOffset: const Offset(1, 1)),
    TextStyleDef(id: 'cine_trailer', label: 'Fragman', category: 'Sinematik', fontKey: 'bebas', weight: FontWeight.w400, letterSpacing: 5, uppercase: true, presetColorArgb: 0xFFFFF176, shadowBlur: 5, shadowOffset: const Offset(2, 2)),
    TextStyleDef(id: 'cine_soft', label: 'Yumuşak Sahne', category: 'Sinematik', fontKey: 'raleway', weight: FontWeight.w300, letterSpacing: 1, presetColorArgb: 0xFFFFF3E0, shadowBlur: 6, shadowOffset: const Offset(0, 1)),
    TextStyleDef(id: 'cine_end', label: 'Son Yazı', category: 'Sinematik', fontKey: 'cinzel', weight: FontWeight.w400, letterSpacing: 6, uppercase: true, presetColorArgb: 0xFFFFE082),

    // ── Handwritten (8) ──
    TextStyleDef(id: 'hand_note', label: 'Not', category: 'El Yazısı', fontKey: 'caveat', weight: FontWeight.w500, presetColorArgb: 0xFFFFF59D),
    TextStyleDef(id: 'hand_diary', label: 'Günlük', category: 'El Yazısı', fontKey: 'shadowsIntoLight', weight: FontWeight.w400, presetColorArgb: 0xFFE1BEE7),
    TextStyleDef(id: 'hand_sketch', label: 'Eskiz', category: 'El Yazısı', fontKey: 'permanentMarker', weight: FontWeight.w400, presetColorArgb: 0xFF90CAF9),
    TextStyleDef(id: 'hand_love', label: 'Aşk Notu', category: 'El Yazısı', fontKey: 'dancing', weight: FontWeight.w600, presetColorArgb: 0xFFF48FB1),
    TextStyleDef(id: 'hand_casual', label: 'Gündelik', category: 'El Yazısı', fontKey: 'indieFlower', weight: FontWeight.w400, presetColorArgb: 0xFFA5D6A7),
    TextStyleDef(id: 'hand_script_bold', label: 'Kalın Script', category: 'El Yazısı', fontKey: 'pacifico', weight: FontWeight.w400, presetColorArgb: 0xFFFFCC80),
    TextStyleDef(id: 'hand_ink', label: 'Mürekkep', category: 'El Yazısı', fontKey: 'satisfy', weight: FontWeight.w400, presetColorArgb: 0xFFB0BEC5),
    TextStyleDef(id: 'hand_chalk', label: 'Tebeşir', category: 'El Yazısı', fontKey: 'caveat', weight: FontWeight.w700, presetColorArgb: 0xFFFFFFFF, shadowBlur: 1, shadowOffset: const Offset(1, 1)),

    // ── Tech / UI (8) ──
    TextStyleDef(id: 'tech_code', label: 'Kod', category: 'Teknik', fontKey: 'robotoMono', weight: FontWeight.w500, letterSpacing: 0.5, presetColorArgb: 0xFF69F0AE),
    TextStyleDef(id: 'tech_hud', label: 'HUD', category: 'Teknik', fontKey: 'orbitron', weight: FontWeight.w500, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFF00E5FF),
    TextStyleDef(id: 'tech_data', label: 'Veri', category: 'Teknik', fontKey: 'rajdhani', weight: FontWeight.w600, letterSpacing: 1, presetColorArgb: 0xFF80D8FF),
    TextStyleDef(id: 'tech_system', label: 'Sistem', category: 'Teknik', fontKey: 'exo2', weight: FontWeight.w400, letterSpacing: 1.5, uppercase: true, presetColorArgb: 0xFFB2FF59),
    TextStyleDef(id: 'tech_terminal', label: 'Terminal', category: 'Teknik', fontKey: 'robotoMono', weight: FontWeight.w400, presetColorArgb: 0xFF00C853),
    TextStyleDef(id: 'tech_alert', label: 'Uyarı', category: 'Teknik', fontKey: 'orbitron', weight: FontWeight.w700, letterSpacing: 2, uppercase: true, presetColorArgb: 0xFFFF1744),
    TextStyleDef(id: 'tech_label', label: 'Etiket', category: 'Teknik', fontKey: 'titillium', weight: FontWeight.w600, letterSpacing: 1, uppercase: true, presetColorArgb: 0xFFECEFF1),
    TextStyleDef(id: 'tech_grid', label: 'Grid', category: 'Teknik', fontKey: 'spaceGrotesk', weight: FontWeight.w500, letterSpacing: 1, presetColorArgb: 0xFF82B1FF),
  ];
}
