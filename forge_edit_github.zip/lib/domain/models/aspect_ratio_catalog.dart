/// CapCut-style canvas ratio presets.
class AspectRatioPreset {
  final String id;
  final String label;
  final int width;
  final int height;

  const AspectRatioPreset({
    required this.id,
    required this.label,
    required this.width,
    required this.height,
  });

  double get ratio => width / height;
}

class AspectRatioCatalog {
  static const all = <AspectRatioPreset>[
    AspectRatioPreset(id: '9:16', label: '9:16 Reels', width: 1080, height: 1920),
    AspectRatioPreset(id: '1:1', label: '1:1 Kare', width: 1080, height: 1080),
    AspectRatioPreset(id: '16:9', label: '16:9 Yatay', width: 1920, height: 1080),
    AspectRatioPreset(id: '4:5', label: '4:5 Post', width: 1080, height: 1350),
  ];

  static AspectRatioPreset bySize(int w, int h) {
    for (final p in all) {
      if (p.width == w && p.height == h) return p;
    }
    // nearest by ratio
    final r = w / h;
    AspectRatioPreset best = all.first;
    var bestD = double.infinity;
    for (final p in all) {
      final d = (p.ratio - r).abs();
      if (d < bestD) {
        bestD = d;
        best = p;
      }
    }
    return best;
  }
}
