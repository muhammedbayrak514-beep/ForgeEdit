/// Emoji stickers as lightweight text-overlay clips (PicsArt-style quick stickers).
class StickerDef {
  final String id;
  final String emoji;
  final String label;

  const StickerDef({
    required this.id,
    required this.emoji,
    required this.label,
  });
}

class StickerCatalog {
  static const all = <StickerDef>[
    StickerDef(id: 'fire', emoji: '🔥', label: 'Ateş'),
    StickerDef(id: 'heart', emoji: '❤️', label: 'Kalp'),
    StickerDef(id: 'star', emoji: '⭐', label: 'Yıldız'),
    StickerDef(id: 'laugh', emoji: '😂', label: 'Gül'),
    StickerDef(id: 'clap', emoji: '👏', label: 'Alkış'),
    StickerDef(id: 'party', emoji: '🎉', label: 'Parti'),
    StickerDef(id: 'rocket', emoji: '🚀', label: 'Roket'),
    StickerDef(id: 'ok', emoji: '✅', label: 'OK'),
    StickerDef(id: 'cam', emoji: '📸', label: 'Kamera'),
    StickerDef(id: 'music', emoji: '🎵', label: 'Müzik'),
    StickerDef(id: 'spark', emoji: '✨', label: 'Işıltı'),
    StickerDef(id: 'cool', emoji: '😎', label: 'Cool'),
  ];
}
