# Forge Edit Studio

CapCut tarzı bir fotoğraf/video düzenleyici için Flutter başlangıç projesi. Android telefon ve tablet odaklı, koyu temalı bir arayüz içerir.

## Bu sürümde çalışanlar

- Galeriden birden fazla fotoğraf/video seçme; tek fotoğraf, tek video veya kameradan fotoğraf alma.
- Seçilen medya dosyalarını uygulamanın belge klasörüne kopyalama.
- Kaydedilen projeleri ana ekranda listeleme ve tekrar açma.
- Video önizlemesi ve oynat/duraklat kontrolü.
- Önizlemede renk filtresi ve parlaklık ayarı.
- Önizlemede yazı bindirme.
- Klip aralığı, hız ve ses seviyesi ayarlarını proje dosyasına kaydetme.
- Proje ayarlarını JSON olarak yerel depolamaya kaydetme.
- GitHub Actions ile release APK oluşturma.

## Henüz tamamlanmayanlar

Bu, çalışabilir bir ilk iskelettir; CapCut'ın tüm işlevlerine sahip bitmiş bir ürün değildir. Bu sürümde düzenlemeleri yeni bir MP4 dosyasına işleyen gerçek video render/export motoru yoktur. Klip kesim aralığı ve hız bilgisi proje ayarı olarak saklanır, ancak video dosyasına uygulanmaz. Metin ve filtreler önizlemede görünür; dışa aktarılan medya dosyasına gömülmez. Çok kanallı timeline, geçişler, ses müziği katmanı, altyazı, çözünürlük seçimi ve geri al/yinele sonraki geliştirme aşamalarıdır.

## APK'yi Android telefon/tablet üzerinden GitHub ile oluşturma

1. Bu ZIP dosyasını indirip aç.
2. GitHub'da yeni bir depo oluştur (ör. `forge-edit-studio`).
3. ZIP'in içindeki dosyaları, klasör yapısını koruyarak deponun köküne yükle. `.github/workflows/build-apk.yml` dosyası da yüklenmiş olmalı.
4. Depoda **Actions** sekmesini aç. `Build Forge Edit APK` iş akışı otomatik başlayabilir; başlamazsa iş akışını seçip **Run workflow** düğmesine bas.
5. Yeşil onayla biten çalışmaya gir. Sayfanın altındaki **Artifacts** bölümünden `forge-edit-release-apk` dosyasını indir.
6. İnen artifact ZIP'ini aç; içindeki `app-release.apk` dosyası uygulamadır. Android kurulum ekranında cihazın istediği izinleri kullanarak kur.

## Bilgisayarda Flutter ile çalıştırma

Flutter SDK kurulu bir ortamda proje kökünde:

```bash
flutter create --platforms=android --org com.forgeedit --project-name forge_edit .
flutter pub get
flutter analyze
flutter run
flutter build apk --release
```

APK yolu: `build/app/outputs/flutter-apk/app-release.apk`

## Teknik bilgiler

- Flutter / Dart
- `image_picker`: medya seçimi ve kamera
- `video_player`: video önizleme
- `path_provider`: projeleri ve içe aktarılan medyayı uygulama belge alanında saklama

Uygulama sürümü: `0.1.0+1`


## Zaman çizelgesi — sürüm 0.2.0

Bu sürümde editörün yatay zaman çizelgesi geliştirildi:
- Bir klibi basılı tutup yatayda sürükleyerek sırasını değiştirebilirsin.
- Makas düğmesi seçili klibin mevcut aralığını iki parçaya böler.
- Çöp kutusu düğmesi seçili klibi projeden kaldırır.
- Yeni sıra ve bölme işlemleri proje modeline uygulanır; kalıcı olması için üstteki **Kaydet** düğmesine basılmalıdır.

Bölme işlemi kaynak medya dosyasını fiziksel olarak kesmez. İki ayrı klip segmenti oluşturur ve `trimStart` / `trimEnd` değerlerini ayarlar. Gerçek MP4 render/dışa aktarma motoru ayrı bir geliştirme adımıdır.

**Test notu:** Bu paketin hazırlandığı ortamda Flutter SDK bulunmadığından APK derlemesi ve cihaz testi çalıştırılamadı.


## UI refresh 0.3.0

- Ana ekranın yatay boşlukları ekran genişliğine göre uyarlanır; büyük telefon/tablet ekranlarında başlık ölçeği büyür.
- Düzenleme ekranı 820 px ve üzerindeki genişliklerde iki bölümlü çalışma alanına geçer: solda medya önizlemesi ve zaman çizelgesi, sağda düzenleme araçları.
- Dar ekranlarda mobil dikey akış korunur.
- Zaman çizelgesi klip seçimi, sürükleyerek sıralama, klip aralığını iki parçaya bölme ve silme kontrollerini içerir.
- Arayüzde dışa aktarma düğmesi gerçek render işlemi yapmaz; kullanıcıya MP4 render motorunun henüz eklenmediği açıkça bildirilir.

Bu sürüm kaynak kodu güncellemesidir. Flutter SDK bu üretim ortamında bulunmadığı için APK derlemesi ve cihaz testi burada doğrulanamamıştır. GitHub Actions ile derleyip Android cihazda test edin.
