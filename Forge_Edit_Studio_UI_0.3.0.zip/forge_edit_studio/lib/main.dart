import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ForgeEditApp());
}

const Color kBackground = Color(0xFF0B0D13);
const Color kPanel = Color(0xFF151925);
const Color kPanelLight = Color(0xFF202638);
const Color kPurple = Color(0xFF8B5CF6);
const Color kCyan = Color(0xFF22D3EE);

class ForgeEditApp extends StatelessWidget {
  const ForgeEditApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Forge Edit Studio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: kBackground,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kPurple,
          brightness: Brightness.dark,
          surface: kPanel,
        ),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: kBackground,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class EditClip {
  EditClip({
    required this.path,
    required this.name,
    required this.isVideo,
    this.filterIndex = 0,
    this.brightness = 0,
    this.overlayText = '',
    this.trimStart = 0,
    this.trimEnd = 1,
    this.speed = 1,
    this.volume = 1,
  });

  String path;
  String name;
  bool isVideo;
  int filterIndex;
  double brightness;
  String overlayText;
  double trimStart;
  double trimEnd;
  double speed;
  double volume;

  Map<String, dynamic> toJson() => {
        'path': path,
        'name': name,
        'isVideo': isVideo,
        'filterIndex': filterIndex,
        'brightness': brightness,
        'overlayText': overlayText,
        'trimStart': trimStart,
        'trimEnd': trimEnd,
        'speed': speed,
        'volume': volume,
      };

  factory EditClip.fromJson(Map<String, dynamic> json) => EditClip(
        path: json['path'] as String? ?? '',
        name: json['name'] as String? ?? 'Medya',
        isVideo: json['isVideo'] as bool? ?? false,
        filterIndex: (json['filterIndex'] as num?)?.toInt() ?? 0,
        brightness: (json['brightness'] as num?)?.toDouble() ?? 0,
        overlayText: json['overlayText'] as String? ?? '',
        trimStart: (json['trimStart'] as num?)?.toDouble() ?? 0,
        trimEnd: (json['trimEnd'] as num?)?.toDouble() ?? 1,
        speed: (json['speed'] as num?)?.toDouble() ?? 1,
        volume: (json['volume'] as num?)?.toDouble() ?? 1,
      );
}

class EditProject {
  EditProject({
    required this.id,
    required this.title,
    required this.updatedAtMs,
    required this.clips,
  });

  String id;
  String title;
  int updatedAtMs;
  List<EditClip> clips;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'updatedAtMs': updatedAtMs,
        'clips': clips.map((clip) => clip.toJson()).toList(),
      };

  factory EditProject.fromJson(Map<String, dynamic> json) => EditProject(
        id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
        title: json['title'] as String? ?? 'Yeni Proje',
        updatedAtMs: (json['updatedAtMs'] as num?)?.toInt() ?? DateTime.now().millisecondsSinceEpoch,
        clips: (json['clips'] as List<dynamic>? ?? [])
            .whereType<Map<String, dynamic>>()
            .map(EditClip.fromJson)
            .toList(),
      );
}

class ProjectStore {
  static Future<Directory> _root() async {
    final docs = await getApplicationDocumentsDirectory();
    final root = Directory('${docs.path}${Platform.pathSeparator}forge_edit');
    if (!await root.exists()) await root.create(recursive: true);
    return root;
  }

  static Future<Directory> _mediaFolder() async {
    final root = await _root();
    final dir = Directory('${root.path}${Platform.pathSeparator}media');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  static Future<Directory> _projectsFolder() async {
    final root = await _root();
    final dir = Directory('${root.path}${Platform.pathSeparator}projects');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  static Future<List<EditClip>> copyPickedFiles(List<XFile> files) async {
    final dir = await _mediaFolder();
    final clips = <EditClip>[];
    for (var i = 0; i < files.length; i++) {
      final file = files[i];
      final source = File(file.path);
      if (!await source.exists()) continue;
      final rawExt = file.name.contains('.') ? file.name.split('.').last.toLowerCase() : 'dat';
      final ext = rawExt.replaceAll(RegExp(r'[^a-z0-9]'), '');
      final timestamp = DateTime.now().microsecondsSinceEpoch;
      final dest = File('${dir.path}${Platform.pathSeparator}media_${timestamp}_$i.${ext.isEmpty ? 'dat' : ext}');
      await source.copy(dest.path);
      const videoExts = {'mp4', 'mov', 'm4v', 'webm', 'mkv', '3gp', 'avi'};
      clips.add(EditClip(
        path: dest.path,
        name: file.name,
        isVideo: videoExts.contains(rawExt),
      ));
    }
    return clips;
  }

  static Future<void> save(EditProject project) async {
    project.updatedAtMs = DateTime.now().millisecondsSinceEpoch;
    final dir = await _projectsFolder();
    final file = File('${dir.path}${Platform.pathSeparator}${project.id}.json');
    await file.writeAsString(jsonEncode(project.toJson()));
  }

  static Future<List<EditProject>> loadAll() async {
    final dir = await _projectsFolder();
    final result = <EditProject>[];
    await for (final entity in dir.list()) {
      if (entity is! File || !entity.path.toLowerCase().endsWith('.json')) continue;
      try {
        final decoded = jsonDecode(await entity.readAsString());
        if (decoded is Map<String, dynamic>) {
          final project = EditProject.fromJson(decoded);
          project.clips.removeWhere((clip) => !File(clip.path).existsSync());
          if (project.clips.isNotEmpty) result.add(project);
        }
      } catch (_) {
        // Corrupt individual project files are skipped rather than blocking the home screen.
      }
    }
    result.sort((a, b) => b.updatedAtMs.compareTo(a.updatedAtMs));
    return result;
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ImagePicker _picker = ImagePicker();
  List<EditProject> _projects = [];
  bool _loading = true;
  bool _creating = false;

  @override
  void initState() {
    super.initState();
    _refreshProjects();
  }

  Future<void> _refreshProjects() async {
    final projects = await ProjectStore.loadAll();
    if (!mounted) return;
    setState(() {
      _projects = projects;
      _loading = false;
    });
  }

  Future<void> _newFromFiles(List<XFile> files) async {
    if (files.isEmpty || _creating) return;
    setState(() => _creating = true);
    try {
      final clips = await ProjectStore.copyPickedFiles(files);
      if (clips.isEmpty) throw Exception('Seçilen medya dosyaları okunamadı.');
      final now = DateTime.now();
      final project = EditProject(
        id: now.microsecondsSinceEpoch.toString(),
        title: 'Proje ${now.day}.${now.month}.${now.year} ${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}',
        updatedAtMs: now.millisecondsSinceEpoch,
        clips: clips,
      );
      await ProjectStore.save(project);
      if (!mounted) return;
      await _openProject(project);
    } catch (e) {
      if (mounted) _showMessage('Proje oluşturulamadı: $e');
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  Future<void> _pickAllMedia() async {
    try {
      final files = await _picker.pickMultipleMedia();
      await _newFromFiles(files);
    } catch (e) {
      if (mounted) _showMessage('Medya açılamadı: $e');
    }
  }

  Future<void> _pickPhoto() async {
    try {
      final file = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 100);
      if (file != null) await _newFromFiles([file]);
    } catch (e) {
      if (mounted) _showMessage('Fotoğraf açılamadı: $e');
    }
  }

  Future<void> _pickVideo() async {
    try {
      final file = await _picker.pickVideo(source: ImageSource.gallery);
      if (file != null) await _newFromFiles([file]);
    } catch (e) {
      if (mounted) _showMessage('Video açılamadı: $e');
    }
  }

  Future<void> _takePhoto() async {
    try {
      final file = await _picker.pickImage(source: ImageSource.camera, imageQuality: 100);
      if (file != null) await _newFromFiles([file]);
    } catch (e) {
      if (mounted) _showMessage('Kamera açılamadı: $e');
    }
  }

  Future<void> _openProject(EditProject project) async {
    await Navigator.of(context).push<void>(MaterialPageRoute<void>(
      builder: (_) => EditorScreen(
        project: project,
        onSaved: (updated) => ProjectStore.save(updated),
      ),
    ));
    await _refreshProjects();
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.sizeOf(context).width;
    final horizontalPadding = screenWidth >= 900 ? 36.0 : (screenWidth >= 600 ? 28.0 : 18.0);
    final heroTitleSize = screenWidth >= 600 ? 38.0 : 31.0;
    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _refreshProjects,
          child: ListView(
            padding: EdgeInsets.fromLTRB(horizontalPadding, 14, horizontalPadding, 28),
            children: [
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      gradient: const LinearGradient(colors: [kPurple, kCyan]),
                    ),
                    child: const Icon(Icons.movie_creation_rounded, color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('FORGE EDIT', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: 1.7)),
                        Text('STUDIO  •  YARATICI DÜZENLEME', style: TextStyle(color: Colors.white54, fontSize: 9, letterSpacing: 1.1)),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Bilgi',
                    onPressed: () => showAboutDialog(
                      context: context,
                      applicationName: 'Forge Edit Studio',
                      applicationVersion: '0.3.0',
                      children: const [Text('Fotoğraf ve video düzenleme için başlangıç sürümü. Gerçek video render/dışa aktarma motoru sonraki geliştirme aşamasıdır.')],
                    ),
                    icon: const Icon(Icons.info_outline_rounded, color: Colors.white70),
                  ),
                ],
              ),
              const SizedBox(height: 28),
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF34206D), Color(0xFF1A2442), Color(0xFF112B36)],
                  ),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), borderRadius: BorderRadius.circular(30)),
                      child: const Text('KURGU MASAN HAZIR', style: TextStyle(fontSize: 10, letterSpacing: 1.4, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(height: 16),
                    Text('Fikrini harekete\ndönüştür.', style: TextStyle(fontSize: heroTitleSize, height: 1.08, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 12),
                    const Text('Fotoğrafını seç, kliplerini sırala, filtre ve yazı ekleyerek kendi tarzını oluştur.', style: TextStyle(color: Colors.white70, height: 1.45)),
                    const SizedBox(height: 22),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: _creating ? null : _pickAllMedia,
                        style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF151425), padding: const EdgeInsets.symmetric(vertical: 15)),
                        icon: _creating ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.add_rounded),
                        label: Text(_creating ? 'Proje hazırlanıyor...' : 'Yeni proje oluştur', style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const _SectionTitle(title: 'HIZLI BAŞLAT', trailing: 'MEDYA SEÇ'),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _QuickAction(icon: Icons.video_library_rounded, title: 'Video', subtitle: 'Galeriden seç', color: kPurple, onTap: _pickVideo)),
                  const SizedBox(width: 10),
                  Expanded(child: _QuickAction(icon: Icons.photo_library_rounded, title: 'Fotoğraf', subtitle: 'Düzenlemeye başla', color: kCyan, onTap: _pickPhoto)),
                  const SizedBox(width: 10),
                  Expanded(child: _QuickAction(icon: Icons.camera_alt_rounded, title: 'Kamera', subtitle: 'Yeni çekim', color: const Color(0xFFFFB86B), onTap: _takePhoto)),
                ],
              ),
              const SizedBox(height: 28),
              Row(
                children: [
                  const Expanded(child: Text('Projelerim', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                  Text('${_projects.length} proje', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                ],
              ),
              const SizedBox(height: 12),
              if (_loading)
                const Padding(padding: EdgeInsets.all(28), child: Center(child: CircularProgressIndicator()))
              else if (_projects.isEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
                  decoration: BoxDecoration(color: kPanel, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white.withOpacity(0.05))),
                  child: const Column(
                    children: [
                      Icon(Icons.video_library_outlined, size: 34, color: Colors.white38),
                      SizedBox(height: 10),
                      Text('Henüz proje yok', style: TextStyle(fontWeight: FontWeight.bold)),
                      SizedBox(height: 5),
                      Text('Yukarıdan bir fotoğraf veya video seçerek başla.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
                    ],
                  ),
                )
              else
                ..._projects.map((project) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: _ProjectTile(project: project, onTap: () => _openProject(project)),
                    )),
              const SizedBox(height: 18),
              const Center(child: Text('FORGE EDIT • KENDİ TARZINI OLUŞTUR', style: TextStyle(color: Colors.white30, fontSize: 9, letterSpacing: 1.6))),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.trailing});
  final String title;
  final String trailing;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Expanded(child: Text(title, style: const TextStyle(fontSize: 12, color: Colors.white70, letterSpacing: 1.3, fontWeight: FontWeight.bold))),
          Text(trailing, style: const TextStyle(fontSize: 9, color: Colors.white38, letterSpacing: 1.1)),
        ],
      );
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: kPanel,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 15, 10, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(width: 38, height: 38, decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: color)),
                const SizedBox(height: 13),
                Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(fontSize: 9, color: Colors.white54), maxLines: 2),
              ],
            ),
          ),
        ),
      );
}

class _ProjectTile extends StatelessWidget {
  const _ProjectTile({required this.project, required this.onTap});
  final EditProject project;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final videoCount = project.clips.where((clip) => clip.isVideo).length;
    final photoCount = project.clips.length - videoCount;
    final date = DateTime.fromMillisecondsSinceEpoch(project.updatedAtMs);
    return Material(
      color: kPanel,
      borderRadius: BorderRadius.circular(19),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(19),
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Row(
            children: [
              Container(
                width: 62,
                height: 62,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), gradient: const LinearGradient(colors: [Color(0xFF362665), Color(0xFF1C5360)])),
                child: Icon(videoCount > 0 ? Icons.movie_filter_rounded : Icons.image_rounded, size: 28, color: Colors.white),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(project.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    const SizedBox(height: 6),
                    Text('$videoCount video  •  $photoCount fotoğraf', style: const TextStyle(color: Colors.white54, fontSize: 11)),
                    const SizedBox(height: 5),
                    Text('${date.day.toString().padLeft(2, '0')}.${date.month.toString().padLeft(2, '0')}.${date.year}', style: const TextStyle(color: Colors.white38, fontSize: 10)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: Colors.white54),
            ],
          ),
        ),
      ),
    );
  }
}

class _FilterPreset {
  const _FilterPreset(this.name, this.matrix, this.color);
  final String name;
  final List<double> matrix;
  final Color color;
}

const List<_FilterPreset> _filters = [
  _FilterPreset('Original', [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0], Color(0xFF7A8094)),
  _FilterPreset('Sıcak', [1.08, 0, 0, 0, 5, 0, 1.02, 0, 0, 2, 0, 0, 0.90, 0, 0, 0, 0, 0, 1, 0], Color(0xFFFFA45B)),
  _FilterPreset('Soğuk', [0.94, 0, 0, 0, 0, 0, 1.0, 0, 0, 1, 0, 0, 1.10, 0, 8, 0, 0, 0, 1, 0], Color(0xFF53BDF5)),
  _FilterPreset('Mono', [0.299, 0.587, 0.114, 0, 0, 0.299, 0.587, 0.114, 0, 0, 0.299, 0.587, 0.114, 0, 0, 0, 0, 0, 1, 0], Color(0xFF9BA2B2)),
  _FilterPreset('Film', [0.90, 0.08, 0.02, 0, 4, 0.02, 0.94, 0.02, 0, 1, 0.02, 0.06, 0.82, 0, 2, 0, 0, 0, 1, 0], Color(0xFFC69A6B)),
  _FilterPreset('Mor', [1.0, 0, 0.08, 0, 4, 0.02, 0.92, 0.05, 0, 0, 0.08, 0.02, 1.08, 0, 7, 0, 0, 0, 1, 0], Color(0xFFB08BFF)),
];

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key, required this.project, required this.onSaved});
  final EditProject project;
  final Future<void> Function(EditProject project) onSaved;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late EditProject _project;
  int _selectedIndex = 0;
  String _activeTool = 'Filtre';
  VideoPlayerController? _videoController;
  bool _saving = false;
  final ImagePicker _picker = ImagePicker();

  EditClip? get _selectedClip => _project.clips.isEmpty ? null : _project.clips[_selectedIndex.clamp(0, _project.clips.length - 1).toInt()];

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _syncVideoController();
  }

  @override
  void dispose() {
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _syncVideoController() async {
    final clip = _selectedClip;
    final oldController = _videoController;
    _videoController = null;
    if (oldController != null) await oldController.dispose();
    if (!mounted || clip == null || !clip.isVideo) {
      if (mounted) setState(() {});
      return;
    }
    final controller = VideoPlayerController.file(File(clip.path));
    _videoController = controller;
    if (mounted) setState(() {});
    try {
      await controller.initialize();
      await controller.setVolume(clip.volume.clamp(0.0, 1.0).toDouble());
      if (!mounted || !identical(_videoController, controller)) return;
      setState(() {});
    } catch (_) {
      if (mounted && identical(_videoController, controller)) setState(() {});
    }
  }

  void _selectClip(int index) {
    if (index == _selectedIndex) return;
    setState(() => _selectedIndex = index);
    _syncVideoController();
  }

  Future<void> _saveProject() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      await widget.onSaved(_project);
      if (mounted) _showMessage('Proje kaydedildi.');
    } catch (e) {
      if (mounted) _showMessage('Kaydedilemedi: $e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _addMedia() async {
    try {
      final files = await _picker.pickMultipleMedia();
      if (files.isEmpty) return;
      final clips = await ProjectStore.copyPickedFiles(files);
      if (!mounted || clips.isEmpty) return;
      setState(() {
        _project.clips.addAll(clips);
        _selectedIndex = _project.clips.length - clips.length;
      });
      await _syncVideoController();
      _showMessage('${clips.length} medya eklendi. Kaydetmeyi unutma.');
    } catch (e) {
      if (mounted) _showMessage('Medya eklenemedi: $e');
    }
  }

  void _deleteClip() {
    final clip = _selectedClip;
    if (clip == null) return;
    setState(() {
      _project.clips.removeAt(_selectedIndex);
      if (_project.clips.isEmpty) {
        _selectedIndex = 0;
      } else if (_selectedIndex >= _project.clips.length) {
        _selectedIndex = _project.clips.length - 1;
      }
    });
    _syncVideoController();
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
  }

  Future<void> _showExportNotice() async {
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: kPanel,
        title: const Text('Dışa aktarma'),
        content: const Text('Bu başlangıç sürümünde medya içe aktarma, önizleme, filtre/yazı/ayar düzenleme ve proje kaydetme çalışır. Düzenlemeleri tek bir MP4 veya yeni fotoğraf dosyasına işleyen gerçek render motoru henüz eklenmedi.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Kapat')),
          FilledButton(onPressed: () { Navigator.pop(context); _saveProject(); }, child: const Text('Projeyi kaydet')),
        ],
      ),
    );
  }

  List<double> _activeMatrix(EditClip clip) {
    final matrix = List<double>.from(_filters[clip.filterIndex.clamp(0, _filters.length - 1).toInt()].matrix);
    matrix[4] = (matrix[4] + clip.brightness * 255).clamp(-255.0, 255.0).toDouble();
    matrix[9] = (matrix[9] + clip.brightness * 255).clamp(-255.0, 255.0).toDouble();
    matrix[14] = (matrix[14] + clip.brightness * 255).clamp(-255.0, 255.0).toDouble();
    return matrix;
  }

  @override
  Widget build(BuildContext context) {
    final clip = _selectedClip;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(_project.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
          const Text('DÜZENLEME MASASI', style: TextStyle(fontSize: 9, color: Colors.white45, letterSpacing: 1.2)),
        ]),
        actions: [
          IconButton(onPressed: _addMedia, tooltip: 'Medya ekle', icon: const Icon(Icons.add_to_photos_outlined)),
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: FilledButton(
              onPressed: _saving ? null : _saveProject,
              style: FilledButton.styleFrom(backgroundColor: kPurple, padding: const EdgeInsets.symmetric(horizontal: 13)),
              child: _saving ? const SizedBox(width: 15, height: 15, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Kaydet'),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: clip == null
            ? _emptyEditor()
            : LayoutBuilder(
                builder: (context, constraints) {
                  if (constraints.maxWidth >= 820) return _buildWideEditor(clip);
                  return Column(
                    children: [
                      Expanded(
                        child: ListView(
                          padding: const EdgeInsets.fromLTRB(14, 8, 14, 18),
                          children: [
                            _buildPreview(clip),
                            const SizedBox(height: 13),
                            _buildPreviewHeading(),
                            const SizedBox(height: 10),
                            _buildTimeline(),
                            const SizedBox(height: 18),
                            _buildToolPicker(),
                            const SizedBox(height: 12),
                            _buildToolPanel(clip),
                            const SizedBox(height: 16),
                            _buildEditorActions(),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
      ),
    );
  }

  Widget _buildPreviewHeading() => Row(
        children: [
          const Icon(Icons.auto_awesome_rounded, color: kCyan, size: 17),
          const SizedBox(width: 7),
          const Expanded(child: Text('ÖNİZLEME', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.4, fontSize: 10, color: Colors.white70))),
          Text('${_selectedIndex + 1} / ${_project.clips.length}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
        ],
      );

  Widget _buildEditorActions() => Row(
        children: [
          Expanded(child: OutlinedButton.icon(onPressed: _addMedia, icon: const Icon(Icons.add_rounded), label: const Text('Medya ekle'), style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton.icon(onPressed: _showExportNotice, icon: const Icon(Icons.ios_share_rounded), label: const Text('Dışa aktar'), style: FilledButton.styleFrom(backgroundColor: kPurple, padding: const EdgeInsets.symmetric(vertical: 14)))),
        ],
      );

  Widget _buildWideEditor(EditClip clip) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              flex: 7,
              child: ListView(
                children: [
                  _buildPreview(clip),
                  const SizedBox(height: 13),
                  _buildPreviewHeading(),
                  const SizedBox(height: 10),
                  _buildTimeline(),
                  const SizedBox(height: 14),
                  _buildEditorActions(),
                ],
              ),
            ),
            const SizedBox(width: 18),
            Expanded(
              flex: 4,
              child: ListView(
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: kPanel,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.white.withOpacity(0.05)),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.tune_rounded, color: kCyan, size: 19),
                        SizedBox(width: 9),
                        Expanded(child: Text('DÜZENLEME ARAÇLARI', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1.1))),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildToolPicker(),
                  const SizedBox(height: 12),
                  _buildToolPanel(clip),
                  const SizedBox(height: 16),
                  const Text(
                    'Bilgi: Düzenleme ayarları önizleme ve proje verisinde tutulur. Gerçek MP4 dışa aktarma henüz desteklenmiyor.',
                    style: TextStyle(color: Colors.white38, fontSize: 10, height: 1.4),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _emptyEditor() => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.movie_filter_outlined, size: 52, color: Colors.white38),
            const SizedBox(height: 12),
            const Text('Bu projede medya yok', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            const SizedBox(height: 8),
            const Text('Yeni fotoğraf veya video ekleyerek devam et.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: _addMedia, icon: const Icon(Icons.add), label: const Text('Medya ekle')),
          ]),
        ),
      );

  Widget _buildPreview(EditClip clip) {
    final matrix = _activeMatrix(clip);
    Widget media;
    if (clip.isVideo) {
      final controller = _videoController;
      if (controller == null || !controller.value.isInitialized) {
        media = Container(
          color: const Color(0xFF080A0F),
          child: Center(child: controller != null && controller.value.hasError ? const Icon(Icons.error_outline_rounded, color: Colors.white54, size: 38) : const CircularProgressIndicator()),
        );
      } else {
        media = ColoredBox(
          color: const Color(0xFF080A0F),
          child: Center(
            child: ColorFiltered(
              colorFilter: ColorFilter.matrix(matrix),
              child: AspectRatio(aspectRatio: controller.value.aspectRatio, child: VideoPlayer(controller)),
            ),
          ),
        );
      }
    } else {
      final file = File(clip.path);
      media = ColoredBox(
        color: const Color(0xFF080A0F),
        child: Center(
          child: file.existsSync()
              ? ColorFiltered(colorFilter: ColorFilter.matrix(matrix), child: Image.file(file, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined, color: Colors.white54, size: 42)))
              : const Icon(Icons.broken_image_outlined, color: Colors.white54, size: 42),
        ),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: AspectRatio(
        aspectRatio: 16 / 9,
        child: Stack(
          fit: StackFit.expand,
          children: [
            media,
            if (clip.isVideo)
              Center(
                child: IconButton.filledTonal(
                  onPressed: () async {
                    final controller = _videoController;
                    if (controller == null || !controller.value.isInitialized) return;
                    if (controller.value.isPlaying) {
                      await controller.pause();
                    } else {
                      await controller.play();
                    }
                    if (mounted) setState(() {});
                  },
                  iconSize: 29,
                  style: IconButton.styleFrom(backgroundColor: Colors.black.withOpacity(0.45), foregroundColor: Colors.white),
                  icon: Icon((_videoController?.value.isPlaying ?? false) ? Icons.pause_rounded : Icons.play_arrow_rounded),
                ),
              ),
            if (clip.overlayText.trim().isNotEmpty)
              Positioned(
                left: 12,
                right: 12,
                bottom: 14,
                child: Text(
                  clip.overlayText,
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: Colors.white, shadows: [Shadow(blurRadius: 9, color: Colors.black, offset: Offset(1, 2))]),
                ),
              ),
            Positioned(
              left: 10,
              top: 10,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                decoration: BoxDecoration(color: Colors.black.withOpacity(0.55), borderRadius: BorderRadius.circular(9)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(clip.isVideo ? Icons.videocam_rounded : Icons.image_rounded, size: 13), const SizedBox(width: 5), Text(clip.isVideo ? 'VİDEO' : 'FOTOĞRAF', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1))]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _splitSelectedClip() {
    final clip = _selectedClip;
    if (clip == null) return;
    final range = clip.trimEnd - clip.trimStart;
    if (range < 0.06) {
      _showMessage('Bölmek için klip aralığı çok kısa.');
      return;
    }

    final splitPoint = clip.trimStart + range / 2;
    final secondPart = EditClip(
      path: clip.path,
      name: '${clip.name} (2)',
      isVideo: clip.isVideo,
      filterIndex: clip.filterIndex,
      brightness: clip.brightness,
      overlayText: clip.overlayText,
      trimStart: splitPoint,
      trimEnd: clip.trimEnd,
      speed: clip.speed,
      volume: clip.volume,
    );

    setState(() {
      clip.trimEnd = splitPoint;
      _project.clips.insert(_selectedIndex + 1, secondPart);
      _selectedIndex += 1;
    });
    _syncVideoController();
    _showMessage('Klip iki parçaya bölündü. Değişiklikleri saklamak için Kaydet’e bas.');
  }

  void _reorderClip(int oldIndex, int newIndex) {
    if (oldIndex < 0 || oldIndex >= _project.clips.length ||
        newIndex < 0 || newIndex >= _project.clips.length ||
        oldIndex == newIndex) {
      return;
    }
    setState(() {
      final selectedClip = _selectedClip;
      final moved = _project.clips.removeAt(oldIndex);
      _project.clips.insert(newIndex, moved);

      if (identical(selectedClip, moved)) {
        _selectedIndex = newIndex;
      } else if (oldIndex < _selectedIndex && newIndex >= _selectedIndex) {
        _selectedIndex -= 1;
      } else if (oldIndex > _selectedIndex && newIndex <= _selectedIndex) {
        _selectedIndex += 1;
      }
    });
    _showMessage('Klip sırası değiştirildi. Kaydetmeyi unutma.');
  }

  Widget _buildTimeline() => Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: kPanel,
          borderRadius: BorderRadius.circular(19),
          border: Border.all(color: Colors.white.withOpacity(0.04)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.view_timeline_rounded, size: 16, color: kCyan),
                const SizedBox(width: 7),
                const Text(
                  'ZAMAN ÇİZELGESİ',
                  style: TextStyle(fontSize: 10, letterSpacing: 1.2, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                Text('${_project.clips.length} klip', style: const TextStyle(color: Colors.white45, fontSize: 10)),
                const SizedBox(width: 4),
                IconButton(
                  tooltip: 'Seçili klibi böl',
                  visualDensity: VisualDensity.compact,
                  onPressed: _selectedClip == null ? null : _splitSelectedClip,
                  icon: const Icon(Icons.content_cut_rounded, size: 19, color: kCyan),
                ),
                IconButton(
                  tooltip: 'Seçili klibi sil',
                  visualDensity: VisualDensity.compact,
                  onPressed: _selectedClip == null ? null : _deleteClip,
                  icon: const Icon(Icons.delete_outline_rounded, size: 19, color: Color(0xFFFF7B8B)),
                ),
              ],
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Text(
                'Klibi basılı tutup sürükleyerek sırala • Makas ile böl • Çöp kutusu ile sil',
                style: TextStyle(color: Colors.white38, fontSize: 10),
              ),
            ),
            SizedBox(
              height: 92,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (var index = 0; index < _project.clips.length; index++)
                    DragTarget<int>(
                      onWillAcceptWithDetails: (details) => details.data != index,
                      onAcceptWithDetails: (details) => _reorderClip(details.data, index),
                      builder: (context, candidateData, rejectedData) {
                        final item = _project.clips[index];
                        final selected = index == _selectedIndex;
                        return LongPressDraggable<int>(
                          data: index,
                          axis: Axis.horizontal,
                          feedback: Material(
                            color: Colors.transparent,
                            child: SizedBox(
                              width: 104,
                              height: 88,
                              child: _timelineClipCard(item, index, true, true),
                            ),
                          ),
                          childWhenDragging: Container(
                            width: 96,
                            margin: const EdgeInsets.only(right: 8),
                            decoration: BoxDecoration(
                              color: kPanelLight.withOpacity(0.35),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.white12, style: BorderStyle.solid),
                            ),
                          ),
                          onDragStarted: () => setState(() => _selectedIndex = index),
                          child: Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: _timelineClipCard(item, index, selected, candidateData.isNotEmpty),
                          ),
                        );
                      },
                    ),
                  InkWell(
                    onTap: _addMedia,
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      width: 58,
                      margin: const EdgeInsets.only(right: 2),
                      decoration: BoxDecoration(
                        color: kPanelLight,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: const Icon(Icons.add_rounded, color: Colors.white70),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _timelineClipCard(EditClip item, int index, bool selected, bool dropTarget) {
    final borderColor = dropTarget ? kCyan : (selected ? kPurple : Colors.white.withOpacity(0.07));
    return InkWell(
      onTap: () => _selectClip(index),
      borderRadius: BorderRadius.circular(12),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        width: 96,
        padding: const EdgeInsets.all(7),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF30234F) : kPanelLight,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: borderColor, width: selected || dropTarget ? 2 : 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(item.isVideo ? Icons.play_circle_fill_rounded : Icons.image_rounded,
                    size: 16, color: selected ? kCyan : Colors.white54),
                const Spacer(),
                Text('${index + 1}', style: const TextStyle(fontSize: 9, color: Colors.white45)),
              ],
            ),
            const Spacer(),
            Text(
              item.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 9, color: Colors.white80),
            ),
            const SizedBox(height: 5),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                minHeight: 3,
                value: (item.trimEnd - item.trimStart).clamp(0.0, 1.0),
                backgroundColor: Colors.white12,
                valueColor: AlwaysStoppedAnimation<Color>(selected ? kCyan : kPurple),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToolPicker() {
    const tools = [
      ('Filtre', Icons.color_lens_outlined),
      ('Ayar', Icons.tune_rounded),
      ('Metin', Icons.title_rounded),
      ('Kes', Icons.content_cut_rounded),
      ('Hız', Icons.speed_rounded),
      ('Ses', Icons.volume_up_rounded),
      ('Sil', Icons.delete_outline_rounded),
    ];
    return SizedBox(
      height: 73,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: tools.length,
        separatorBuilder: (_, __) => const SizedBox(width: 9),
        itemBuilder: (context, index) {
          final entry = tools[index];
          final selected = _activeTool == entry.$1;
          return InkWell(
            onTap: () {
              if (entry.$1 == 'Sil') {
                _deleteClip();
              } else {
                setState(() => _activeTool = entry.$1);
              }
            },
            borderRadius: BorderRadius.circular(14),
            child: Container(
              width: 68,
              decoration: BoxDecoration(color: selected ? const Color(0xFF30234F) : kPanel, borderRadius: BorderRadius.circular(14), border: Border.all(color: selected ? kPurple : Colors.white.withOpacity(0.04))),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(entry.$2, size: 21, color: selected ? kCyan : Colors.white70), const SizedBox(height: 7), Text(entry.$1, style: TextStyle(fontSize: 10, color: selected ? Colors.white : Colors.white70, fontWeight: selected ? FontWeight.bold : FontWeight.normal))]),
            ),
          );
        },
      ),
    );
  }

  Widget _buildToolPanel(EditClip clip) {
    switch (_activeTool) {
      case 'Filtre':
        return _panelContainer(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('FİLTRELER', style: TextStyle(fontSize: 10, color: Colors.white60, letterSpacing: 1.3, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            SizedBox(
              height: 77,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _filters.length,
                separatorBuilder: (_, __) => const SizedBox(width: 9),
                itemBuilder: (context, index) {
                  final filter = _filters[index];
                  final selected = clip.filterIndex == index;
                  return InkWell(
                    onTap: () => setState(() => clip.filterIndex = index),
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      width: 74,
                      decoration: BoxDecoration(color: selected ? filter.color.withOpacity(0.18) : kPanelLight, borderRadius: BorderRadius.circular(12), border: Border.all(color: selected ? filter.color : Colors.white.withOpacity(0.05), width: selected ? 1.5 : 1)),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Container(width: 26, height: 26, decoration: BoxDecoration(color: filter.color, shape: BoxShape.circle)), const SizedBox(height: 7), Text(filter.name, style: const TextStyle(fontSize: 10))]),
                    ),
                  );
                },
              ),
            ),
          ]),
        );
      case 'Ayar':
        return _panelContainer(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('PARLAKLIK', style: TextStyle(fontSize: 10, color: Colors.white60, letterSpacing: 1.3, fontWeight: FontWeight.bold)),
          Row(children: [const Icon(Icons.brightness_low_rounded, size: 18, color: Colors.white60), Expanded(child: Slider(value: clip.brightness, min: -0.5, max: 0.5, divisions: 20, activeColor: kCyan, onChanged: (value) => setState(() => clip.brightness = value))), const Icon(Icons.brightness_high_rounded, size: 18, color: Colors.white60)]),
          Text('Parlaklık: ${(clip.brightness * 100).round()}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
        ]));
      case 'Metin':
        return _panelContainer(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('VİDEO / FOTOĞRAF ÜZERİNE YAZI', style: TextStyle(fontSize: 10, color: Colors.white60, letterSpacing: 1.0, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          TextFormField(
            key: ValueKey('text-${_selectedIndex}'),
            initialValue: clip.overlayText,
            onChanged: (value) => setState(() => clip.overlayText = value),
            maxLength: 80,
            decoration: InputDecoration(hintText: 'Bir başlık yaz...', filled: true, fillColor: kPanelLight, counterStyle: const TextStyle(color: Colors.white38), border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none), prefixIcon: const Icon(Icons.title_rounded)),
          ),
          const Text('Yazı önizlemede görünür. Bu sürümde henüz dosyanın içine işlenmez.', style: TextStyle(fontSize: 10, color: Colors.white45)),
        ]));
      case 'Kes':
        return _panelContainer(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('KLİP ARALIĞI', style: TextStyle(fontSize: 10, color: Colors.white60, letterSpacing: 1.3, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          RangeSlider(
            values: RangeValues(clip.trimStart, clip.trimEnd),
            min: 0,
            max: 1,
            divisions: 100,
            activeColor: kPurple,
            onChanged: (values) {
              if (values.end - values.start < 0.03) return;
              setState(() { clip.trimStart = values.start; clip.trimEnd = values.end; });
            },
          ),
          Row(children: [Text('Başlangıç ${(clip.trimStart * 100).round()}%', style: const TextStyle(color: Colors.white60, fontSize: 10)), const Spacer(), Text('Bitiş ${(clip.trimEnd * 100).round()}%', style: const TextStyle(color: Colors.white60, fontSize: 10))]),
          const SizedBox(height: 5),
          const Text('Kesim aralığı proje ayarına kaydedilir; mevcut sürüm orijinal video dosyasını değiştirmez.', style: TextStyle(fontSize: 10, color: Colors.white45)),
        ]));
      case 'Hız':
        return _panelContainer(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('OYNATMA HIZI', style: TextStyle(fontSize: 10, color: Colors.white60, letterSpacing: 1.3, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Row(children: [for (final speed in [0.5, 0.75, 1.0, 1.5, 2.0]) Expanded(child: Padding(padding: const EdgeInsets.only(right: 6), child: ChoiceChip(label: Text('${speed}x'), selected: clip.speed == speed, onSelected: (_) => setState(() => clip.speed = speed))))]),
          const Text('Hız değeri proje ayarına kaydedilir; bu sürümde dışa aktarılan klibe uygulanmaz.', style: TextStyle(fontSize: 10, color: Colors.white45)),
        ]));
      case 'Ses':
        return _panelContainer(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('KLİP SESİ', style: TextStyle(fontSize: 10, color: Colors.white60, letterSpacing: 1.3, fontWeight: FontWeight.bold)),
          Row(children: [Icon(clip.volume == 0 ? Icons.volume_off_rounded : Icons.volume_up_rounded, color: Colors.white60), Expanded(child: Slider(value: clip.volume, min: 0, max: 1, divisions: 10, activeColor: kCyan, onChanged: (value) async { setState(() => clip.volume = value); final controller = _videoController; if (controller != null && controller.value.isInitialized) await controller.setVolume(value); })), Text('${(clip.volume * 100).round()}%', style: const TextStyle(color: Colors.white60, fontSize: 11))]),
          const Text('Ses seviyesi video önizlemesinde kullanılabilir.', style: TextStyle(fontSize: 10, color: Colors.white45)),
        ]));
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _panelContainer({required Widget child}) => Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: kPanel, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(0.04))),
        child: child,
      );
}
