# Proje durumu — Forge Edit Studio 0.1.0

## Birinci aşama
- [x] Ana ekran ve proje listesi
- [x] Galeri/kamera üzerinden medya alma
- [x] Medyayı uygulama dizinine kopyalama
- [x] Video oynatma önizlemesi
- [x] Filtre ve parlaklık önizlemesi
- [x] Metin bindirme önizlemesi
- [x] Klip sırası ve temel ayarları kaydetme
- [x] APK derleme GitHub Actions workflow dosyası

## İkinci aşama — zaman çizelgesi
- [x] Yatay klip şeridinde klipleri basılı tutup sürükleyerek yeniden sıralama
- [x] Seçili klibi iki parçaya bölme (mevcut trim aralığının ortasından)
- [x] Seçili klibi zaman çizelgesinden silme
- [x] Seçili klip ve sıra değişiklikleri için görsel geri bildirim
- [x] Mevcut proje JSON biçimiyle uyumlu kalma; değişiklikler Kaydet ile saklanır

## Sonraki öncelikler
1. Flutter ortamında `flutter analyze` ve cihaz testi; derleme bulgularını düzeltme.
2. FFmpeg tabanlı veya platforma uygun bir render motoru seçip gerçek MP4 export ekleme.
3. Proje ayarlarını uygulayarak fotoğraf çıktısı üretme.
4. Timeline üzerinde bölme, silme, yeniden sıralama ve çoklu katman.
5. Geri al/yinele, otomatik kayıt ve dosya boyutu/çözünürlük seçimi.
6. Uzun videolar için performans, depolama ve hata yönetimi testleri.

Not: Bu çalışma ortamında Flutter SDK bulunmadığı için proje burada gerçek cihazda derlenip test edilmedi. GitHub Actions akışı Flutter'ın güncel stable sürümünde derleme ve analiz yapacak şekilde hazırlandı.


## UI update 0.3.0
- Responsive home spacing and hero typography.
- Tablet/landscape editor layout switches to a two-column workspace at 820 logical pixels.
- Mobile editor remains vertically scrollable.
- Timeline operations are still project-state edits; no video render/export engine is included.
- APK build and physical-device validation still required through GitHub Actions.
