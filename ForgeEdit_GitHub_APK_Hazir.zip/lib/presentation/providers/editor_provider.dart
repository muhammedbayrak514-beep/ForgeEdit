import 'package:collection/collection.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/repositories/project_repository.dart';
import '../../domain/edit_history.dart';
import '../../domain/models/clip_model.dart';
import '../../domain/models/effect_presets.dart';
import '../../domain/models/aspect_ratio_catalog.dart';
import '../../domain/models/pip_layouts.dart';
import '../../data/services/beat_detect_service.dart';
import '../../data/services/crop_detect_service.dart';
import '../../domain/models/keyframe.dart';
import '../../domain/models/project_model.dart';
import '../../domain/timeline_ops.dart';
import '../../data/services/freeze_frame_service.dart';
import '../../data/services/audio_import_service.dart';
import '../../data/repositories/project_repository.dart';
import 'package:path/path.dart' as p;
import 'dart:io';
import 'preview_provider.dart';
import 'project_list_provider.dart';
import 'timeline_clock_provider.dart';

final editorProvider =
    AsyncNotifierProvider.family<EditorNotifier, ProjectModel, String>(
  EditorNotifier.new,
);

final historyUiProvider =
    StateProvider.family<HistoryUiState, String>((ref, projectId) {
  return const HistoryUiState();
});

/// Last successful disk save time for autosave indicator.
final lastSavedAtProvider =
    StateProvider.family<DateTime?, String>((ref, projectId) => null);

class EditorNotifier extends FamilyAsyncNotifier<ProjectModel, String> {
  ProjectRepository get _repo => ref.read(projectRepositoryProvider);
  final EditHistory _history = EditHistory();
  bool _saving = false;
  /// Monotonic generation so a late-finishing save cannot overwrite a newer state.
  int _saveGeneration = 0;
  Future<void>? _saveChain;

  String get projectId => arg;

  @override
  Future<ProjectModel> build(String projectId) async {
    final project = await _repo.getProject(projectId);
    if (project == null) {
      throw Exception('Proje bulunamadı: $projectId');
    }
    _history.clear();
    _publishHistory();
    return project;
  }

  Future<void> load() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => build(projectId));
  }

  /// Serializes disk writes; always persists the *latest* state after the chain.
  Future<void> save() {
    final gen = ++_saveGeneration;
    final previous = _saveChain ?? Future.value();
    _saveChain = previous.then((_) => _saveAt(gen)).catchError((e, st) {
      // Keep chain alive after failure
    });
    return _saveChain!;
  }

  Future<void> _saveAt(int gen) async {
    // Wait until we are the latest requested generation's runner,
    // but still write the current in-memory state once per turn of the chain.
    if (gen < _saveGeneration) {
      // A newer save was requested; the chain will call us again via later link.
      return;
    }
    final current = state.value;
    if (current == null) return;
    // Guard against writing wrong project after notifier rebuild
    if (current.id != projectId) return;
    _saving = true;
    try {
      await _repo.saveProject(current);
      // If state advanced during await, schedule another save
      if (gen < _saveGeneration) {
        return;
      }
      ref.read(lastSavedAtProvider(projectId).notifier).state = DateTime.now();
      // Re-check: if still same generation, refresh list once
      ref.read(projectListProvider.notifier).refresh();
    } finally {
      _saving = false;
      // If mutations happened while saving, ensure latest is flushed
      if (gen < _saveGeneration && state.value != null) {
        // chain continues via subsequent save() links
      }
    }
  }

  void _publishHistory() {
    ref.read(historyUiProvider(projectId).notifier).state =
        HistoryUiState.from(_history);
  }

  Future<void> _commit(ProjectModel next) async {
    final current = state.value;
    if (current != null) {
      _history.pushBeforeChange(current);
    }
    state = AsyncData(next);
    _publishHistory();
    await save();
  }

  Future<void> applyLive(ProjectModel next) async {
    state = AsyncData(next);
  }

  void beginContinuousEdit(String key) {
    final current = state.value;
    if (current == null) return;
    _history.beginCoalesce(current, key);
    _publishHistory();
  }

  Future<void> endContinuousEdit() async {
    _history.endCoalesce();
    _publishHistory();
    await save();
  }

  Future<void> undo() async {
    final current = state.value;
    if (current == null || !_history.canUndo) return;
    final prev = _history.undo(current);
    if (prev == null) return;
    state = AsyncData(prev);
    _publishHistory();
    await save();
    _clampPlayhead(prev);
    _fixSelection(prev);
  }

  Future<void> redo() async {
    final current = state.value;
    if (current == null || !_history.canRedo) return;
    final next = _history.redo(current);
    if (next == null) return;
    state = AsyncData(next);
    _publishHistory();
    await save();
    _clampPlayhead(next);
    _fixSelection(next);
  }

  void _fixSelection(ProjectModel project) {
    final selected = ref.read(selectedClipIdProvider(projectId));
    if (selected != null && !project.clips.any((c) => c.id == selected)) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          project.clips.isNotEmpty ? project.clips.first.id : null;
    }
  }

  Future<void> addClips(List<ClipModel> clips) async {
    final current = state.value;
    if (current == null) return;
    var updated = current;
    for (final clip in clips) {
      updated = updated.addClip(clip);
    }
    await _commit(updated);
  }

  Future<void> updateClip(ClipModel clip, {bool continuous = false}) async {
    final current = state.value;
    if (current == null) return;
    final next = current.updateClip(clip);
    if (continuous) {
      await applyLive(next);
    } else {
      await _commit(next);
    }
  }

  Future<void> trimClip({
    required String clipId,
    required int trimStartMs,
    required int trimEndMs,
    bool continuous = false,
  }) async {
    final current = state.value;
    if (current == null) return;
    final updated = TimelineOps.trimClip(
      project: current,
      clipId: clipId,
      newTrimStartMs: trimStartMs,
      newTrimEndMs: trimEndMs,
    );
    if (continuous) {
      await applyLive(updated);
    } else {
      await _commit(updated);
      _clampPlayhead(updated);
      _reloadPreviewIfSelected(clipId);
    }
  }

  Future<void> resizeClipEdge({
    required String clipId,
    required bool fromLeft,
    required int deltaTimelineMs,
    bool continuous = false,
  }) async {
    final current = state.value;
    if (current == null || deltaTimelineMs == 0) return;
    final updated = TimelineOps.resizeClipEdge(
      project: current,
      clipId: clipId,
      fromLeft: fromLeft,
      deltaTimelineMs: deltaTimelineMs,
    );
    if (continuous) {
      await applyLive(updated);
    } else {
      await _commit(updated);
      _clampPlayhead(updated);
      _reloadPreviewIfSelected(clipId);
    }
  }

  Future<bool> splitAtPlayhead(String clipId) async {
    final current = state.value;
    if (current == null) return false;
    final playhead = ref.read(timelineClockProvider(projectId)).positionMs;
    final result = TimelineOps.splitClip(
      project: current,
      clipId: clipId,
      projectTimeMs: playhead,
    );
    if (result == null) return false;
    await _commit(result);
    ref.read(selectedClipIdProvider(projectId).notifier).state = clipId;
    _clampPlayhead(result);
    return true;
  }

  Future<void> deleteClip(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final updated = TimelineOps.deleteClip(project: current, clipId: clipId);
    await _commit(updated);
    final selected = ref.read(selectedClipIdProvider(projectId));
    if (selected == clipId) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          updated.clips.isNotEmpty ? updated.clips.first.id : null;
    }
    final multi = ref.read(selectedClipIdsProvider(projectId));
    if (multi.contains(clipId)) {
      ref.read(selectedClipIdsProvider(projectId).notifier).state =
          {...multi}..remove(clipId);
    }
    _clampPlayhead(updated);
  }

  Future<void> bulkCopySelected() async {
    final ids = ref.read(selectedClipIdsProvider(projectId));
    final current = state.value;
    if (current == null || ids.isEmpty) return;
    // Copy first selected into clipboard for paste; also duplicate all in place.
    final first = current.clips.where((c) => ids.contains(c.id)).firstOrNull;
    if (first != null) {
      ref.read(clipboardClipProvider(projectId).notifier).state = first;
    }
    for (final id in ids.toList()) {
      await duplicateClip(id);
    }
  }

  Future<void> bulkMuteSelected({required bool mute}) async {
    final ids = ref.read(selectedClipIdsProvider(projectId));
    final current = state.value;
    if (current == null || ids.isEmpty) return;
    var next = current;
    for (final c in current.clips) {
      if (ids.contains(c.id)) {
        next = next.updateClip(c.copyWith(muted: mute, volume: mute ? 0.0 : (c.volume < 0.01 ? 1.0 : c.volume)));
      }
    }
    await _commit(next);
  }

  Future<void> deleteClips(Iterable<String> ids) async {
    final current = state.value;
    if (current == null) return;
    final list = ids.toList();
    if (list.isEmpty) return;
    final updated = TimelineOps.deleteClips(project: current, clipIds: list);
    await _commit(updated);
    ref.read(selectedClipIdsProvider(projectId).notifier).state = {};
    ref.read(multiSelectModeProvider(projectId).notifier).state = false;
    final sel = ref.read(selectedClipIdProvider(projectId));
    if (sel != null && list.contains(sel)) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          updated.clips.isNotEmpty ? updated.clips.first.id : null;
    }
    _clampPlayhead(updated);
  }

  void copyClip(String clipId) {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return;
    ref.read(clipboardClipProvider(projectId).notifier).state = clip;
  }

  Future<void> pasteClipAtPlayhead() async {
    final current = state.value;
    if (current == null) return;
    final src = ref.read(clipboardClipProvider(projectId));
    if (src == null) return;
    final start = ref.read(timelineClockProvider(projectId)).positionMs;
    final updated = TimelineOps.pasteClip(
      project: current,
      source: src,
      timelineStartMs: start,
    );
    await _commit(updated);
    final oldIds = current.clips.map((c) => c.id).toSet();
    final created = updated.clips.where((c) => !oldIds.contains(c.id)).toList();
    if (created.isNotEmpty) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          created.last.id;
    }
  }

  Future<void> duplicateClip(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final updated = TimelineOps.duplicateClip(project: current, clipId: clipId);
    await _commit(updated);
    // select the new copy (last matching display or newest)
    final copies = updated.clips.where((c) => c.id != clipId).toList();
    // find by newest id not in old
    final oldIds = current.clips.map((c) => c.id).toSet();
    final created = updated.clips.where((c) => !oldIds.contains(c.id)).toList();
    if (created.isNotEmpty) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          created.last.id;
    }
    _clampPlayhead(updated);
  }

  Future<void> autoSplitEvery(String clipId, int intervalMs) async {
    final current = state.value;
    if (current == null) return;
    final updated = TimelineOps.autoSplitEvery(
      project: current,
      clipId: clipId,
      intervalMs: intervalMs,
    );
    await _commit(updated);
    _clampPlayhead(updated);
  }

  Future<void> removeClip(String clipId) => deleteClip(clipId);

  Future<void> convertToPip(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    if (clip.type != ClipType.video && clip.type != ClipType.image) return;
    await updateClip(
      clip.copyWith(
        trackIndex: TrackIndex.overlay,
        scale: 0.35,
        posX: 0.82,
        posY: 0.82,
      ),
    );
  }

  Future<void> convertPipToMain(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    var next = current.updateClip(
      clip.copyWith(
        trackIndex: TrackIndex.video,
        scale: 1.0,
        posX: 0.5,
        posY: 0.5,
      ),
    );
    next = TimelineOps.packMainTrack(next);
    await _commit(next);
  }

  Future<void> setClipFades({
    required String clipId,
    int? fadeInMs,
    int? fadeOutMs,
  }) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    await updateClip(
      clip.copyWith(
        fadeInMs: fadeInMs ?? clip.fadeInMs,
        fadeOutMs: fadeOutMs ?? clip.fadeOutMs,
      ),
    );
  }

  Future<void> toggleReverse(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    if (clip.type != ClipType.video && clip.type != ClipType.audio) return;
    await updateClip(clip.copyWith(reversed: !clip.reversed));
  }

  Future<void> toggleMute(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    final nextMuted = !clip.muted && clip.volume >= 0.001;
    await updateClip(
      clip.copyWith(
        muted: nextMuted,
        volume: nextMuted ? 0.0 : (clip.volume < 0.01 ? 1.0 : clip.volume),
      ),
    );
  }

  Future<ClipModel?> freezeFrameAtPlayhead(String clipId) async {
    final current = state.value;
    if (current == null) return null;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.type != ClipType.video) return null;
    final clock = ref.read(timelineClockProvider(projectId)).positionMs;
    final local = (clock - clip.timelineStartMs).clamp(0, clip.durationMs);
    // Map timeline-local to source time accounting for speed
    final sourceMs = clip.trimStartMs + (local * clip.speed).round();
    final service = FreezeFrameService();
    final frozen = await service.capture(
      projectId: projectId,
      sourcePath: clip.filePath,
      sourceTimeMs: sourceMs,
      timelineStartMs: clock,
    );
    if (frozen == null) return null;
    await addClips([frozen]);
    ref.read(selectedClipIdProvider(projectId).notifier).state = frozen.id;
    return frozen;
  }

  Future<bool> replaceClipMediaFromPath({
    required String clipId,
    required String sourcePath,
  }) async {
    final current = state.value;
    if (current == null) return false;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return false;
    if (clip.type != ClipType.video && clip.type != ClipType.image) return false;
    try {
      final media = await ProjectRepository().mediaDir(projectId);
      final ext = p.extension(sourcePath).toLowerCase();
      final dest = p.join(media.path, '${clip.id}_replaced$ext');
      await File(sourcePath).copy(dest);
      await updateClip(
        clip.copyWith(
          filePath: dest,
          displayName: p.basename(sourcePath),
        ),
      );
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> toggleClipLock(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return;
    await updateClip(clip.copyWith(locked: !clip.locked));
  }

  Future<void> setClipColorTag(String clipId, String tag) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return;
    await updateClip(clip.copyWith(colorTag: tag));
  }

  /// Add opacity/position keyframe on [clipId] at playhead (text/video).
  Future<void> addKeyframeAtPlayhead(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    final pos = ref.read(timelineClockProvider(projectId)).positionMs;
    final local = (pos - clip.timelineStartMs).clamp(0, clip.durationMs);
    final keys = [...clip.keyframes]
      ..removeWhere((k) => (k.offsetMs - local).abs() < 40);
    keys.add(ClipKeyframe(
      offsetMs: local,
      opacity: clip.opacity,
      posX: clip.posX,
      posY: clip.posY,
      scale: clip.scale,
    ));
    keys.sort((a, b) => a.offsetMs.compareTo(b.offsetMs));
    await updateClip(clip.copyWith(keyframes: keys));
  }

  Future<void> clearKeyframes(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return;
    await updateClip(clip.copyWith(keyframes: const []));
  }

  /// Layout overlay (PiP) clips into grid/split slots.
  Future<void> applyPipLayout(PipLayout layout) async {
    final current = state.value;
    if (current == null) return;
    final overlays = current.clips
        .where((c) =>
            c.trackIndex == TrackIndex.overlay &&
            (c.type == ClipType.video || c.type == ClipType.image))
        .toList()
      ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));
    if (overlays.isEmpty) return;
    var next = current;
    for (var i = 0; i < overlays.length && i < layout.slots.length; i++) {
      final slot = layout.slots[i];
      final c = overlays[i];
      next = next.updateClip(c.copyWith(
        posX: slot.posX,
        posY: slot.posY,
        scale: slot.scale,
      ));
    }
    await _commit(next.copyWith(updatedAt: DateTime.now()));
  }

  Future<void> applyManualCrop({
    required String clipId,
    required double left,
    required double top,
    required double right,
    required double bottom,
  }) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    await updateClip(clip.copyWith(
      cropLeft: left.clamp(0.0, 0.45),
      cropTop: top.clamp(0.0, 0.45),
      cropRight: right.clamp(0.0, 0.45),
      cropBottom: bottom.clamp(0.0, 0.45),
      cropMode: 'manual',
    ));
  }

  Future<void> clearCrop(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return;
    await updateClip(clip.copyWith(
      cropLeft: 0,
      cropTop: 0,
      cropRight: 0,
      cropBottom: 0,
      cropMode: 'none',
    ));
  }

  /// Auto: center cover to project aspect ratio.
  Future<bool> autoCropCover(String clipId) async {
    final current = state.value;
    if (current == null) return false;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return false;
    if (clip.type != ClipType.video && clip.type != ClipType.image) return false;
    final target = current.width / (current.height == 0 ? 1 : current.height);
    final size = await CropDetectService.probeSize(clip.filePath);
    final sourceAspect =
        (size != null && size.$2 > 0) ? size.$1 / size.$2 : 16 / 9;
    final r = CropDetectService.coverCrop(
      sourceAspect: sourceAspect,
      targetAspect: target,
    );
    await updateClip(clip.copyWith(
      cropLeft: r.left,
      cropTop: r.top,
      cropRight: r.right,
      cropBottom: r.bottom,
      cropMode: r.hasCrop ? 'autoCover' : 'none',
      fitMode: 'cover',
    ));
    return r.hasCrop;
  }

  Future<void> applyFilterToAllVideos(String filterId, double intensity) async {
    final current = state.value;
    if (current == null) return;
    var next = current;
    for (final c in current.clips) {
      if ((c.type == ClipType.video || c.type == ClipType.image) &&
          (c.trackIndex == TrackIndex.video ||
              c.trackIndex == TrackIndex.overlay)) {
        next = next.updateClip(c.copyWith(
          filterId: filterId,
          filterIntensity: intensity,
        ));
      }
    }
    await _commit(next.copyWith(updatedAt: DateTime.now()));
  }

  Future<void> toggleFlipVertical(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    await updateClip(clip.copyWith(flipVertical: !clip.flipVertical));
  }

  /// Auto: detect black bars / letterbox with FFmpeg cropdetect.
  Future<bool> autoCropBlackBars(String clipId) async {
    final current = state.value;
    if (current == null) return false;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked || clip.filePath.isEmpty) return false;
    final r = await CropDetectService.detectBlackBars(clip.filePath);
    await updateClip(clip.copyWith(
      cropLeft: r.left,
      cropTop: r.top,
      cropRight: r.right,
      cropBottom: r.bottom,
      cropMode: r.hasCrop ? 'autoBars' : 'none',
    ));
    return r.hasCrop;
  }

  Future<void> applyEffectPreset(EffectPreset pack) async {
    final current = state.value;
    if (current == null) return;
    final applied = EffectPreset.applyToClips(current.clips, pack);
    await _commit(
      current.copyWith(clips: applied.clips, updatedAt: DateTime.now()),
    );
  }

  Future<void> setAspectRatio(AspectRatioPreset preset) async {
    final current = state.value;
    if (current == null) return;
    await _commit(current.copyWith(
      width: preset.width,
      height: preset.height,
      updatedAt: DateTime.now(),
    ));
  }

  /// Detect beats on selected audio (or first audio) → project markers.
  Future<int> applyBeatsFromAudio({String? clipId}) async {
    final current = state.value;
    if (current == null) return 0;
    ClipModel? audio;
    if (clipId != null) {
      audio = current.clips.where((c) => c.id == clipId).firstOrNull;
    }
    audio ??= current.clips.where((c) => c.type == ClipType.audio).firstOrNull;
    if (audio == null || audio.filePath.isEmpty) return 0;
    final beats = await BeatDetectService.detectBeats(
      audio.filePath,
      mediaDurationMs: audio.sourceDurationMs > 0
          ? audio.sourceDurationMs
          : audio.durationMs,
    );
    final markers = BeatDetectService.toProjectMarkers(
      beats,
      timelineOffsetMs: audio.timelineStartMs,
    );
    final merged = {...current.markersMs, ...markers}.toList()..sort();
    await _commit(current.copyWith(markersMs: merged, updatedAt: DateTime.now()));
    return markers.length;
  }

  /// Split main video clips at marker times (beat cut).
  Future<int> autoCutAtMarkers() async {
    final current = state.value;
    if (current == null || current.markersMs.isEmpty) return 0;
    var project = current;
    var cuts = 0;
    final markers = [...current.markersMs]..sort();
    // Cut from end → start so earlier indices stay stable longer
    for (final m in markers.reversed) {
      final under = project.clips
          .where((c) =>
              c.trackIndex == TrackIndex.video &&
              (c.type == ClipType.video || c.type == ClipType.image) &&
              !c.locked &&
              m > c.timelineStartMs + 80 &&
              m < c.timelineEndMs - 80)
          .toList();
      if (under.isEmpty) continue;
      final live = under.first;
      final next = TimelineOps.splitClip(
        project: project,
        clipId: live.id,
        projectTimeMs: m,
      );
      if (next != null) {
        project = next;
        cuts++;
      }
    }
    if (cuts > 0) await _commit(project);
    return cuts;
  }

  Future<void> addMarkerAtPlayhead() async {
    final current = state.value;
    if (current == null) return;
    final ms = ref.read(timelineClockProvider(projectId)).positionMs;
    final markers = [...current.markersMs];
    if (markers.any((m) => (m - ms).abs() < 40)) return;
    markers.add(ms);
    markers.sort();
    await _commit(current.copyWith(markersMs: markers, updatedAt: DateTime.now()));
  }

  Future<void> removeNearestMarker() async {
    final current = state.value;
    if (current == null || current.markersMs.isEmpty) return;
    final ms = ref.read(timelineClockProvider(projectId)).positionMs;
    var best = current.markersMs.first;
    var bestD = (best - ms).abs();
    for (final m in current.markersMs) {
      final d = (m - ms).abs();
      if (d < bestD) {
        bestD = d;
        best = m;
      }
    }
    if (bestD > 500) return;
    final markers = current.markersMs.where((m) => m != best).toList();
    await _commit(current.copyWith(markersMs: markers, updatedAt: DateTime.now()));
  }

  Future<void> importSrtClips(List<ClipModel> clips) async {
    if (clips.isEmpty) return;
    final current = state.value;
    if (current == null) return;
    var next = current;
    for (final c in clips) {
      next = next.addClip(c);
    }
    await _commit(next.copyWith(updatedAt: DateTime.now()));
    if (clips.isNotEmpty) {
      ref.read(selectedClipIdProvider(projectId).notifier).state = clips.first.id;
    }
  }

  Future<void> replaceClipMedia({
    required String clipId,
    required String newFilePath,
    required String displayName,
  }) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return;
    if (clip.type != ClipType.video && clip.type != ClipType.image) return;
    await updateClip(
      clip.copyWith(filePath: newFilePath, displayName: displayName),
    );
    _reloadPreviewIfSelected(clipId);
  }

  Future<void> reorderMainClip(String clipId, int newIndex) async {
    final current = state.value;
    if (current == null) return;
    await _commit(TimelineOps.reorderMainTrack(
      project: current,
      clipId: clipId,
      newIndex: newIndex,
    ));
  }

  Future<void> moveClipToTime(String clipId, int timelineStartMs) async {
    final current = state.value;
    if (current == null) return;
    await _commit(TimelineOps.setClipTimelineStart(
      project: current,
      clipId: clipId,
      timelineStartMs: timelineStartMs,
    ));
  }

  Future<void> renameProject(String name) async {
    final current = state.value;
    if (current == null) return;
    final trimmed = name.trim();
    if (trimmed.isEmpty || trimmed == current.name) return;
    await _commit(current.copyWith(name: trimmed, updatedAt: DateTime.now()));
  }

  Future<void> setAspectRatio({required int width, required int height}) async {
    final current = state.value;
    if (current == null) return;
    if (current.width == width && current.height == height) return;
    await _commit(
      current.copyWith(width: width, height: height, updatedAt: DateTime.now()),
    );
  }

  Future<void> moveClipLeft(String clipId) async {
    final current = state.value;
    if (current == null) return;
    await _commit(TimelineOps.moveClip(
      project: current,
      clipId: clipId,
      direction: -1,
    ));
  }

  Future<void> moveClipRight(String clipId) async {
    final current = state.value;
    if (current == null) return;
    await _commit(TimelineOps.moveClip(
      project: current,
      clipId: clipId,
      direction: 1,
    ));
  }

  Future<void> addTextClip({
    required String content,
    int durationMs = 3000,
    int? timelineStartMs,
  }) async {
    final current = state.value;
    if (current == null) return;
    final start = timelineStartMs ??
        ref.read(timelineClockProvider(projectId)).positionMs;
    final clip = ClipModel.text(
      content: content,
      durationMs: durationMs,
      timelineStartMs: start,
    );
    await _commit(current.addClip(clip));
    ref.read(selectedClipIdProvider(projectId).notifier).state = clip.id;
  }

  Future<void> addAudioClip(ClipModel audioClip) async {
    final current = state.value;
    if (current == null) return;
    await _commit(current.addClip(audioClip));
    ref.read(selectedClipIdProvider(projectId).notifier).state = audioClip.id;
  }

  /// Extract audio track from a video clip onto the A lane.
  Future<ClipModel?> extractAudioFromVideo(String videoClipId) async {
    final current = state.value;
    if (current == null) return null;
    final clip = current.clips.where((c) => c.id == videoClipId).firstOrNull;
    if (clip == null || clip.type != ClipType.video) return null;
    final service = AudioImportService(_repo);
    final audio = await service.extractFromVideo(
      projectId: projectId,
      videoPath: clip.filePath,
      displayName: clip.displayName,
      timelineStartMs: clip.timelineStartMs,
      durationMs: clip.durationMs,
    );
    if (audio == null) return null;
    // Match trim window roughly via duration already set
    await addAudioClip(audio);
    return audio;
  }

  Future<void> updateTextClip({
    required String clipId,
    String? textContent,
    double? fontSize,
    int? textColorArgb,
    int? textAlign,
    double? posX,
    double? posY,
    String? textStyleId,
    int? durationMs,
    bool continuous = false,
  }) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.type != ClipType.text) return;
    var updated = clip;
    if (textContent != null) {
      final name = textContent.length > 24
          ? '${textContent.substring(0, 24)}…'
          : textContent;
      updated = updated.copyWith(
        textContent: textContent,
        displayName: name,
      );
    }
    if (fontSize != null) updated = updated.copyWith(fontSize: fontSize);
    if (textColorArgb != null) {
      updated = updated.copyWith(textColorArgb: textColorArgb);
    }
    if (textAlign != null) updated = updated.copyWith(textAlign: textAlign);
    if (posX != null) updated = updated.copyWith(posX: posX);
    if (posY != null) updated = updated.copyWith(posY: posY);
    if (textStyleId != null) {
      updated = updated.copyWith(textStyleId: textStyleId);
    }
    if (durationMs != null && durationMs >= 100) {
      updated = updated.copyWith(
        sourceDurationMs: durationMs,
        trimEndMs: durationMs,
        trimStartMs: 0,
      );
    }
    final next = current.updateClip(updated);
    if (continuous) {
      await applyLive(next);
    } else {
      await _commit(next);
    }
  }

  void _clampPlayhead(ProjectModel project) {
    final max = project.durationMs;
    final clock = ref.read(timelineClockProvider(projectId));
    if (clock.positionMs > max) {
      ref.read(timelineClockProvider(projectId).notifier).setPosition(max);
    }
  }

  void _reloadPreviewIfSelected(String clipId) {
    final selected = ref.read(selectedClipIdProvider(projectId));
    if (selected == clipId) {
      ref.read(selectedClipIdProvider(projectId).notifier).state = null;
      Future.microtask(() {
        ref.read(selectedClipIdProvider(projectId).notifier).state = clipId;
      });
    }
  }
}
