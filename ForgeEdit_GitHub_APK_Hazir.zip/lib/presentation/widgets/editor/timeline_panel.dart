import 'dart:io';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/time_formatter.dart';
import '../../../domain/models/clip_model.dart';
import '../../../data/services/waveform_service.dart';
import '../../../domain/timeline_ops.dart';
import '../../../domain/models/effect_models.dart';
import '../../../domain/models/text_style_catalog.dart';
import '../../../domain/models/project_model.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../providers/timeline_clock_provider.dart';
import 'clip_thumbnail.dart';

/// Timeline with time ruler, positioned clips, and shared playhead.
///
/// Stage 4:
/// - Clips laid out by timelineStartMs * pixelsPerMs (model-accurate)
/// - Time ruler with second/major ticks
/// - Draggable playhead (updates TimelineClock)
/// - Horizontal scroll for long timelines
/// - Tap clip → select + load preview (unchanged)
///
/// Compact filmstrip style for phone/tablet bottom chrome.
/// Continuous multi-clip playback is handled by PreviewControllerNotifier.
class TimelinePanel extends ConsumerStatefulWidget {
  final String projectId;

  const TimelinePanel({super.key, required this.projectId});

  @override
  ConsumerState<TimelinePanel> createState() => _TimelinePanelState();
}

class _TimelinePanelState extends ConsumerState<TimelinePanel> {
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final editorState = ref.watch(editorProvider(widget.projectId));
    final clock = ref.watch(timelineClockProvider(widget.projectId));
    final selectedId = ref.watch(selectedClipIdProvider(widget.projectId));
    final project = editorState.value;
    final clips = project?.clips ?? [];
    final durationMs = project?.durationMs ?? 0;

    // Extra padding so playhead can sit past last clip
    final contentWidth = _contentWidth(durationMs, clock.pixelsPerMs);

    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(top: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _TimelineHeader(
            projectId: widget.projectId,
            durationMs: durationMs,
            positionMs: clock.positionMs,
          ),
          Expanded(
            child: clips.isEmpty
                ? const Center(
                    child: Text(
                      'Alttan Medya ile klip ekle',
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                  )
                : _MultiLaneTimeline(
                    projectId: widget.projectId,
                    clips: clips,
                    selectedId: selectedId,
                    durationMs: durationMs,
                    positionMs: clock.positionMs,
                    pixelsPerMs: clock.pixelsPerMs,
                    contentWidth: contentWidth,
                    scrollController: _scrollController,
                    markersMs: project?.markersMs ?? const [],
                    onSeek: (ms) {
                      final snapped = TimelineOps.snapMs(
                        ms,
                        project?.clips ?? const [],
                        markersMs: project?.markersMs ?? const [],
                      );
                      ref
                          .read(timelineClockProvider(widget.projectId).notifier)
                          .setPosition(snapped);
                      _seekPreviewToProjectTime(
                        ref,
                        widget.projectId,
                        project,
                        snapped,
                      );
                    },
                    onSelect: (id) {
                      ref
                          .read(selectedClipIdProvider(widget.projectId)
                              .notifier)
                          .state = id;
                    },
                  ),
          ),
        ],
      ),
    );
  }

  double _contentWidth(int durationMs, double pixelsPerMs) {
    final base = durationMs * pixelsPerMs;
    return (base + 120).clamp(400.0, 200000.0);
  }

  void _seekPreviewToProjectTime(
    WidgetRef ref,
    String projectId,
    ProjectModel? project,
    int projectMs,
  ) {
    if (project == null) return;
    final selectedId = ref.read(selectedClipIdProvider(projectId));
    if (selectedId == null) return;
    final clip = project.clips.where((c) => c.id == selectedId).firstOrNull;
    if (clip == null || clip.type != ClipType.video) return;

    if (projectMs < clip.timelineStartMs || projectMs >= clip.timelineEndMs) {
      return;
    }

    final localMs = projectMs - clip.timelineStartMs + clip.trimStartMs;
    ref
        .read(previewProvider(projectId).notifier)
        .seek(Duration(milliseconds: localMs.clamp(0, clip.trimEndMs)));
  }
}

/// PicsArt-style stacked lanes: video on top, then text, then audio.
class _MultiLaneTimeline extends ConsumerWidget {
  final String projectId;
  final List<ClipModel> clips;
  final String? selectedId;
  final int durationMs;
  final int positionMs;
  final double pixelsPerMs;
  final double contentWidth;
  final ScrollController scrollController;
  final List<int> markersMs;
  final void Function(int ms) onSeek;
  final void Function(String id) onSelect;

  static const double rulerH = 16;
  static const double videoH = 40;
  static const double textH = 24;
  static const double audioH = 24;
  static const double stickerH = 24;
  static const double overlayH = 28;
  static const double labelW = 26;

  const _MultiLaneTimeline({
    required this.projectId,
    required this.clips,
    required this.selectedId,
    required this.durationMs,
    required this.positionMs,
    required this.pixelsPerMs,
    required this.contentWidth,
    required this.scrollController,
    required this.markersMs,
    required this.onSeek,
    required this.onSelect,
  });

  List<ClipModel> _lane(int track, {bool Function(ClipModel)? extra}) {
    final list = clips.where((c) {
      if (c.trackIndex != track) return false;
      if (extra != null && !extra(c)) return false;
      return true;
    }).toList()
      ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));
    return list;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final videoClips = clips
        .where((c) =>
            c.trackIndex == TrackIndex.video &&
            (c.type == ClipType.video || c.type == ClipType.image))
        .toList()
      ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));
    final textClips = _lane(TrackIndex.text);
    final audioClips = _lane(TrackIndex.audio);
    final stickerClips = clips
        .where((c) => c.trackIndex == TrackIndex.sticker)
        .toList()
      ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));
    final overlayClips = clips
        .where((c) => c.trackIndex == TrackIndex.overlay)
        .toList()
      ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));

    final totalH = rulerH + videoH + textH + audioH + stickerH + overlayH;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Fixed lane labels (do not scroll horizontally)
        SizedBox(
          width: labelW,
          height: totalH,
          child: Column(
            children: [
              SizedBox(height: rulerH),
              _LaneLabel(letter: 'V', color: AppTheme.primary, height: videoH),
              _LaneLabel(letter: 'T', color: AppTheme.warning, height: textH),
              _LaneLabel(letter: 'A', color: AppTheme.accent, height: audioH),
              _LaneLabel(letter: 'S', color: const Color(0xFFE879F9), height: stickerH),
              _LaneLabel(letter: 'P', color: const Color(0xFF22D3EE), height: overlayH),
            ],
          ),
        ),
        Expanded(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final w = contentWidth.clamp(constraints.maxWidth, double.infinity);
              return SingleChildScrollView(
                controller: scrollController,
                scrollDirection: Axis.horizontal,
                child: SizedBox(
                  width: w,
                  height: totalH,
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Positioned(
                        top: 0,
                        left: 0,
                        right: 0,
                        height: rulerH,
                        child: _TimeRuler(
                          durationMs: durationMs,
                          pixelsPerMs: pixelsPerMs,
                          width: w,
                        ),
                      ),
                      Positioned(
                        top: rulerH,
                        left: 0,
                        right: 0,
                        height: videoH,
                        child: _LaneBackground(
                          child: _ClipLane(
                            projectId: projectId,
                            clips: videoClips,
                            selectedId: selectedId,
                            pixelsPerMs: pixelsPerMs,
                            scrollController: scrollController,
                            laneHeight: videoH,
                            onSelect: onSelect,
                            reorderable: true,
                            freePlaceable: false,
                          ),
                        ),
                      ),
                      Positioned(
                        top: rulerH + videoH,
                        left: 0,
                        right: 0,
                        height: textH,
                        child: _LaneBackground(
                          child: _ClipLane(
                            projectId: projectId,
                            clips: textClips,
                            selectedId: selectedId,
                            pixelsPerMs: pixelsPerMs,
                            scrollController: scrollController,
                            laneHeight: textH,
                            onSelect: onSelect,
                            reorderable: false,
                            freePlaceable: true,
                          ),
                        ),
                      ),
                      Positioned(
                        top: rulerH + videoH + textH,
                        left: 0,
                        right: 0,
                        height: audioH,
                        child: _LaneBackground(
                          child: _ClipLane(
                            projectId: projectId,
                            clips: audioClips,
                            selectedId: selectedId,
                            pixelsPerMs: pixelsPerMs,
                            scrollController: scrollController,
                            laneHeight: audioH,
                            onSelect: onSelect,
                            reorderable: false,
                            freePlaceable: true,
                          ),
                        ),
                      ),
                      Positioned(
                        top: rulerH + videoH + textH + audioH,
                        left: 0,
                        right: 0,
                        height: stickerH,
                        child: _LaneBackground(
                          child: _ClipLane(
                            projectId: projectId,
                            clips: stickerClips,
                            selectedId: selectedId,
                            pixelsPerMs: pixelsPerMs,
                            scrollController: scrollController,
                            laneHeight: stickerH,
                            onSelect: onSelect,
                            reorderable: false,
                            freePlaceable: true,
                          ),
                        ),
                      ),
                      Positioned(
                        top: rulerH + videoH + textH + audioH + stickerH,
                        left: 0,
                        right: 0,
                        height: overlayH,
                        child: _LaneBackground(
                          child: _ClipLane(
                            projectId: projectId,
                            clips: overlayClips,
                            selectedId: selectedId,
                            pixelsPerMs: pixelsPerMs,
                            scrollController: scrollController,
                            laneHeight: overlayH,
                            onSelect: onSelect,
                            reorderable: false,
                            freePlaceable: true,
                          ),
                        ),
                      ),
                      // Markers
                      for (final m in markersMs)
                        Positioned(
                          top: 0,
                          bottom: 0,
                          left: m * pixelsPerMs - 1,
                          child: IgnorePointer(
                            child: Container(
                              width: 2,
                              color: const Color(0xFFFFB020).withValues(alpha: 0.85),
                            ),
                          ),
                        ),
                      // Playhead across all lanes
                      Positioned(
                        top: 0,
                        bottom: 0,
                        left: positionMs * pixelsPerMs,
                        child: _Playhead(
                          onDrag: (dx) {
                            final newMs = (positionMs + (dx / pixelsPerMs))
                                .round()
                                .clamp(0, durationMs > 0 ? durationMs : 0);
                            onSeek(newMs);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _LaneLabel extends StatelessWidget {
  final String letter;
  final Color color;
  final double height;

  const _LaneLabel({
    required this.letter,
    required this.color,
    required this.height,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: Center(
        child: Text(
          letter,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: color.withValues(alpha: 0.9),
          ),
        ),
      ),
    );
  }
}

class _LaneBackground extends StatelessWidget {
  final Widget child;

  const _LaneBackground({required this.child});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        border: Border(
          top: BorderSide(color: AppTheme.border, width: 0.5),
        ),
        color: Color(0xFF141418),
      ),
      child: child,
    );
  }
}

class _ClipLane extends ConsumerWidget {
  final String projectId;
  final List<ClipModel> clips;
  final String? selectedId;
  final double pixelsPerMs;
  final ScrollController scrollController;
  final double laneHeight;
  final void Function(String id) onSelect;
  final bool reorderable;
  final bool freePlaceable;

  const _ClipLane({
    required this.projectId,
    required this.clips,
    required this.selectedId,
    required this.pixelsPerMs,
    required this.scrollController,
    required this.laneHeight,
    required this.onSelect,
    required this.reorderable,
    required this.freePlaceable,
  });

  Future<void> _dropReorder(WidgetRef ref, String fromId, String ontoId) async {
    if (fromId == ontoId) return;
    final from = clips.indexWhere((c) => c.id == fromId);
    final onto = clips.indexWhere((c) => c.id == ontoId);
    if (from < 0 || onto < 0) return;
    await ref.read(editorProvider(projectId).notifier).reorderMainClip(
          fromId,
          onto,
        );
    ref.read(selectedClipIdProvider(projectId).notifier).state = fromId;
  }

  Future<void> _moveToX(WidgetRef ref, String clipId, double contentX) async {
    final ms =
        (contentX / pixelsPerMs).round().clamp(0, 24 * 3600 * 1000);
    await ref
        .read(editorProvider(projectId).notifier)
        .moveClipToTime(clipId, ms);
    ref.read(selectedClipIdProvider(projectId).notifier).state = clipId;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Stack(
      children: [
        for (final clip in clips)
          Positioned(
            left: clip.timelineStartMs * pixelsPerMs,
            width: (clip.durationMs * pixelsPerMs).clamp(24.0, 100000.0),
            top: 3,
            bottom: 3,
            child: _ClipBlock(
              projectId: projectId,
              clip: clip,
              selected: clip.id == selectedId ||
                  ref.watch(selectedClipIdsProvider(projectId)).contains(clip.id),
              pixelsPerMs: pixelsPerMs,
              onTap: () {
                final multi =
                    ref.read(multiSelectModeProvider(projectId));
                if (multi) {
                  final set = {...ref.read(selectedClipIdsProvider(projectId))};
                  if (set.contains(clip.id)) {
                    set.remove(clip.id);
                  } else {
                    set.add(clip.id);
                  }
                  ref.read(selectedClipIdsProvider(projectId).notifier).state =
                      set;
                  return;
                }
                onSelect(clip.id);
              },
              reorderable: !clip.locked &&
                  reorderable &&
                  (clip.type == ClipType.video || clip.type == ClipType.image),
              freePlaceable: freePlaceable,
              onAcceptReorder: (fromId) => _dropReorder(ref, fromId, clip.id),
              onFreePlaceEnd: (globalOffset, blockWidth) {
                final box = context.findRenderObject() as RenderBox?;
                if (box == null || !box.hasSize) return;
                final local = box.globalToLocal(globalOffset);
                final scroll = scrollController.hasClients
                    ? scrollController.offset
                    : 0.0;
                final contentX = local.dx + scroll + (blockWidth / 2);
                _moveToX(ref, clip.id, contentX);
              },
            ),
          ),
      ],
    );
  }
}

class _TimelineHeader extends ConsumerWidget {
  final String projectId;
  final int durationMs;
  final int positionMs;

  const _TimelineHeader({
    required this.projectId,
    required this.durationMs,
    required this.positionMs,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final multi = ref.watch(multiSelectModeProvider(projectId));
    final selectedIds = ref.watch(selectedClipIdsProvider(projectId));

    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 2, 4, 0),
      child: Row(
        children: [
          Text(
            '${TimeFormatter.formatMs(positionMs)} / ${TimeFormatter.formatMs(durationMs)}',
            style: const TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 11,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
          const Spacer(),
          if (multi) ...[
            Text(
              '${selectedIds.length} seçili',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            IconButton(
              icon: const Icon(Icons.copy_all, size: 20),
              tooltip: 'Seçilenleri çoğalt',
              onPressed: selectedIds.isEmpty
                  ? null
                  : () async {
                      await ref
                          .read(editorProvider(projectId).notifier)
                          .bulkCopySelected();
                    },
              visualDensity: VisualDensity.compact,
            ),
            IconButton(
              icon: const Icon(Icons.volume_off, size: 20),
              tooltip: 'Seçilenleri sessiz',
              onPressed: selectedIds.isEmpty
                  ? null
                  : () async {
                      await ref
                          .read(editorProvider(projectId).notifier)
                          .bulkMuteSelected(mute: true);
                    },
              visualDensity: VisualDensity.compact,
            ),
            IconButton(
              icon: const Icon(Icons.content_cut, size: 20),
              tooltip: 'Playhead’de böl',
              onPressed: () async {
                final id = ref.read(selectedClipIdProvider(projectId));
                if (id == null) return;
                final ok = await ref
                    .read(editorProvider(projectId).notifier)
                    .splitAtPlayhead(id);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        ok
                            ? 'Klip bölündü'
                            : 'Bölünemedi (playhead klip dışında)',
                      ),
                      duration: const Duration(milliseconds: 1200),
                    ),
                  );
                }
              },
              visualDensity: VisualDensity.compact,
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline, size: 20),
              tooltip: 'Seçilenleri sil',
              onPressed: selectedIds.isEmpty
                  ? null
                  : () async {
                      await ref
                          .read(editorProvider(projectId).notifier)
                          .deleteClips(selectedIds);
                    },
              visualDensity: VisualDensity.compact,
            ),
          ],
          IconButton(
            icon: const Icon(Icons.flag_outlined, size: 20),
            tooltip: 'İşaret ekle',
            onPressed: () =>
                ref.read(editorProvider(projectId).notifier).addMarkerAtPlayhead(),
            visualDensity: VisualDensity.compact,
          ),
          IconButton(
            icon: const Icon(Icons.outlined_flag, size: 20),
            tooltip: 'Yakın işareti sil',
            onPressed: () =>
                ref.read(editorProvider(projectId).notifier).removeNearestMarker(),
            visualDensity: VisualDensity.compact,
          ),
          IconButton(
            icon: Icon(
              multi ? Icons.checklist_rtl : Icons.checklist,
              size: 20,
              color: multi ? AppTheme.primary : null,
            ),
            tooltip: multi ? 'Çoklu seçimi kapat' : 'Çoklu seçim',
            onPressed: () {
              final next = !multi;
              ref.read(multiSelectModeProvider(projectId).notifier).state = next;
              if (!next) {
                ref.read(selectedClipIdsProvider(projectId).notifier).state = {};
              }
            },
            visualDensity: VisualDensity.compact,
          ),
          IconButton(
            icon: const Icon(Icons.zoom_out, size: 20),
            tooltip: 'Uzaklaştır',
            onPressed: () =>
                ref.read(timelineClockProvider(projectId).notifier).zoomOut(),
            visualDensity: VisualDensity.compact,
          ),
          IconButton(
            icon: const Icon(Icons.zoom_in, size: 20),
            tooltip: 'Yakınlaştır',
            onPressed: () =>
                ref.read(timelineClockProvider(projectId).notifier).zoomIn(),
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }
}

class _TimeRuler extends StatelessWidget {
  final int durationMs;
  final double pixelsPerMs;
  final double width;

  const _TimeRuler({
    required this.durationMs,
    required this.pixelsPerMs,
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(width, 18),
      painter: _RulerPainter(
        durationMs: durationMs,
        pixelsPerMs: pixelsPerMs,
      ),
    );
  }
}

class _RulerPainter extends CustomPainter {
  final int durationMs;
  final double pixelsPerMs;

  _RulerPainter({required this.durationMs, required this.pixelsPerMs});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.border
      ..strokeWidth = 1;

    final labelStyle = TextStyle(
      color: AppTheme.textSecondary.withValues(alpha: 0.9),
      fontSize: 10,
    );

    // Major tick every 1s or 5s depending on zoom
    final pxPerSec = pixelsPerMs * 1000;
    final majorEverySec = pxPerSec >= 60 ? 1 : (pxPerSec >= 20 ? 5 : 10);
    final majorMs = majorEverySec * 1000;
    final minorMs = majorEverySec <= 1 ? 200 : 1000;

    final end = durationMs + 5000; // draw a bit past end
    for (var t = 0; t <= end; t += minorMs) {
      final x = t * pixelsPerMs;
      if (x > size.width) break;
      final isMajor = t % majorMs == 0;
      final h = isMajor ? 14.0 : 6.0;
      canvas.drawLine(
        Offset(x, size.height - h),
        Offset(x, size.height),
        paint,
      );
      if (isMajor) {
        final tp = TextPainter(
          text: TextSpan(
            text: TimeFormatter.formatMs(t),
            style: labelStyle,
          ),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, Offset(x + 2, 2));
      }
    }

    // Baseline
    canvas.drawLine(
      Offset(0, size.height - 0.5),
      Offset(size.width, size.height - 0.5),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _RulerPainter old) =>
      old.durationMs != durationMs || old.pixelsPerMs != pixelsPerMs;
}

class _ClipBlock extends ConsumerWidget {
  final String projectId;
  final ClipModel clip;
  final bool selected;
  final double pixelsPerMs;
  final VoidCallback onTap;
  final bool reorderable;
  final bool freePlaceable;
  final void Function(String fromId)? onAcceptReorder;
  final void Function(Offset globalOffset, double blockWidth)? onFreePlaceEnd;

  const _ClipBlock({
    required this.projectId,
    required this.clip,
    required this.selected,
    required this.pixelsPerMs,
    required this.onTap,
    this.reorderable = false,
    this.freePlaceable = false,
    this.onAcceptReorder,
    this.onFreePlaceEnd,
  });

  void _onEdgeDrag(WidgetRef ref, bool fromLeft, double dx, {required bool end}) {
    if (pixelsPerMs <= 0) return;
    final deltaMs = (dx / pixelsPerMs).round();
    if (deltaMs == 0 && !end) return;
    final notifier = ref.read(editorProvider(projectId).notifier);
    if (!end && deltaMs != 0) {
      notifier.resizeClipEdge(
        clipId: clip.id,
        fromLeft: fromLeft,
        deltaTimelineMs: deltaMs,
        continuous: true,
      );
    } else if (end) {
      notifier.endContinuousEdit();
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final Color baseColor;
    switch (clip.type) {
      case ClipType.video:
      case ClipType.image:
        baseColor = AppTheme.primary;
        break;
      case ClipType.audio:
        baseColor = AppTheme.accent;
        break;
      case ClipType.text:
        baseColor = AppTheme.warning;
        break;
    }

    final isVisual =
        clip.type == ClipType.video || clip.type == ClipType.image;

    final tagColor = switch (clip.colorTag) {
      'red' => const Color(0xFFFF4D6A),
      'orange' => const Color(0xFFFFB020),
      'green' => const Color(0xFF22C55E),
      'blue' => const Color(0xFF5B8CFF),
      'purple' => const Color(0xFFA855F7),
      _ => null,
    };
    final borderColor = tagColor ??
        (selected ? baseColor : baseColor.withValues(alpha: 0.5));

    final body = GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: baseColor.withValues(alpha: selected ? 0.35 : 0.18),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: borderColor,
            width: selected || tagColor != null ? 2 : 1,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (isVisual)
              Positioned.fill(
                child: ClipThumbnail(
                  clip: clip,
                  width: 400,
                  height: 80,
                  borderRadius: BorderRadius.zero,
                ),
              )
            else if (clip.type == ClipType.audio)
              Positioned.fill(
                child: _AudioWaveform(
                  path: clip.filePath,
                  color: baseColor.withValues(alpha: 0.9),
                  fallbackSeed: clip.id.hashCode,
                ),
              )
            else
              Positioned.fill(
                child: ClipThumbnail(clip: clip, width: 400, height: 80),
              ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              height: 18,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.75),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              left: selected ? 12 : 4,
              right: selected ? 12 : 4,
              bottom: 2,
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      clip.displayName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  if ((clip.speed - 1.0).abs() > 0.01)
                    Text(
                      ' ${clip.speed}x',
                      style: const TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        color: Colors.amberAccent,
                      ),
                    ),
                  if (clip.reversed)
                    const Text(
                      ' ↺',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Colors.lightBlueAccent,
                      ),
                    ),
                  if (clip.volume < 0.001 &&
                      (clip.type == ClipType.video ||
                          clip.type == ClipType.audio))
                    const Icon(Icons.volume_off, size: 11, color: Colors.white70),
                ],
              ),
            ),
            if (clip.type == ClipType.video)
              const Positioned(
                top: 3,
                left: 3,
                child: Icon(Icons.play_arrow, size: 12, color: Colors.white70),
              ),
            if (clip.locked)
              const Positioned(
                top: 2,
                left: 16,
                child: Icon(Icons.lock, size: 12, color: Colors.white70),
              ),
            // Filter / transition / style badges
            if (clip.filterId != 'none' ||
                clip.transitionId != 'none' ||
                clip.type == ClipType.text)
              Positioned(
                top: 2,
                right: selected ? 14 : 2,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (clip.filterId != 'none')
                      _TinyBadge(
                        icon: Icons.auto_awesome,
                        color: AppTheme.primary,
                      ),
                    if (clip.transitionId != 'none')
                      _TinyBadge(
                        icon: Icons.swap_horiz,
                        color: AppTheme.accent,
                      ),
                    if (clip.type == ClipType.text)
                      _TinyBadge(
                        icon: Icons.text_fields,
                        color: AppTheme.warning,
                      ),
                  ],
                ),
              ),
            // Edge handles (selected only)
            if (selected && !clip.locked) ...[
              Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                width: 14,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onHorizontalDragStart: (_) {
                    ref
                        .read(editorProvider(projectId).notifier)
                        .beginContinuousEdit('edge_l_${clip.id}');
                  },
                  onHorizontalDragUpdate: (d) =>
                      _onEdgeDrag(ref, true, d.delta.dx, end: false),
                  onHorizontalDragEnd: (_) =>
                      _onEdgeDrag(ref, true, 0, end: true),
                  child: Center(
                    child: Container(
                      width: 4,
                      height: double.infinity,
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.95),
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: const [
                          BoxShadow(color: Colors.black54, blurRadius: 2),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 0,
                top: 0,
                bottom: 0,
                width: 14,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onHorizontalDragStart: (_) {
                    ref
                        .read(editorProvider(projectId).notifier)
                        .beginContinuousEdit('edge_r_${clip.id}');
                  },
                  onHorizontalDragUpdate: (d) =>
                      _onEdgeDrag(ref, false, d.delta.dx, end: false),
                  onHorizontalDragEnd: (_) =>
                      _onEdgeDrag(ref, false, 0, end: true),
                  child: Center(
                    child: Container(
                      width: 4,
                      height: double.infinity,
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.95),
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: const [
                          BoxShadow(color: Colors.black54, blurRadius: 2),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );

    if (!reorderable && !freePlaceable) return body;

    Widget draggableChild = body;

    if (freePlaceable) {
      draggableChild = LongPressDraggable<String>(
        data: 'place:${clip.id}',
        delay: const Duration(milliseconds: 180),
        feedback: Material(
          color: Colors.transparent,
          elevation: 6,
          child: SizedBox(
            width: 80,
            height: 48,
            child: Opacity(opacity: 0.9, child: body),
          ),
        ),
        childWhenDragging: Opacity(opacity: 0.35, child: body),
        onDragEnd: (details) {
          onFreePlaceEnd?.call(details.offset, 80);
        },
        child: body,
      );
    }

    if (!reorderable) return draggableChild;

    return DragTarget<String>(
      onWillAcceptWithDetails: (d) {
        final data = d.data;
        if (data.startsWith('place:')) return false;
        return data != clip.id;
      },
      onAcceptWithDetails: (d) {
        if (d.data.startsWith('place:')) return;
        onAcceptReorder?.call(d.data);
      },
      builder: (context, candidate, rejected) {
        final highlight = candidate.isNotEmpty;
        final child = LongPressDraggable<String>(
          data: clip.id,
          delay: const Duration(milliseconds: 180),
          feedback: Material(
            color: Colors.transparent,
            elevation: 6,
            child: SizedBox(
              width: 72,
              height: 48,
              child: Opacity(opacity: 0.9, child: body),
            ),
          ),
          childWhenDragging: Opacity(opacity: 0.35, child: body),
          child: draggableChild,
        );
        if (!highlight) return child;
        return DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: AppTheme.accent, width: 2),
          ),
          child: child,
        );
      },
    );
  }
}

class _AudioWaveform extends StatefulWidget {
  final String path;
  final Color color;
  final int fallbackSeed;

  const _AudioWaveform({
    required this.path,
    required this.color,
    required this.fallbackSeed,
  });

  @override
  State<_AudioWaveform> createState() => _AudioWaveformState();
}

class _AudioWaveformState extends State<_AudioWaveform> {
  List<double>? _peaks;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant _AudioWaveform old) {
    super.didUpdateWidget(old);
    if (old.path != widget.path) _load();
  }

  Future<void> _load() async {
    final p = await WaveformService.peaksFor(widget.path, barCount: 48);
    if (mounted) setState(() => _peaks = p);
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _WaveformPainter(
        color: widget.color,
        peaks: _peaks,
        seed: widget.fallbackSeed,
      ),
    );
  }
}

class _WaveformPainter extends CustomPainter {
  final Color color;
  final List<double>? peaks;
  final int seed;

  _WaveformPainter({required this.color, required this.seed, this.peaks});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    final barW = 2.5;
    final gap = 1.5;
    if (peaks != null && peaks!.isNotEmpty) {
      final n = peaks!.length;
      final totalW = n * (barW + gap);
      final scale = size.width / totalW;
      var x = 1.0;
      for (var i = 0; i < n; i++) {
        final env = peaks![i].clamp(0.08, 1.0);
        final h =
            (size.height * 0.12 + size.height * 0.78 * env).clamp(2.0, size.height);
        final top = (size.height - h) / 2;
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromLTWH(x, top, barW * scale.clamp(0.5, 2.0), h),
            const Radius.circular(1),
          ),
          paint,
        );
        x += (barW + gap) * scale.clamp(0.5, 2.0);
      }
      return;
    }
    // Fallback synthetic while loading / on failure
    var x = 1.5;
    var i = 0;
    while (x < size.width - 1) {
      final n1 = ((seed * 13 + i * 17) % 100) / 100.0;
      final h = (size.height * 0.2 + size.height * 0.5 * n1).clamp(3.0, size.height);
      final top = (size.height - h) / 2;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, top, barW, h),
          const Radius.circular(1),
        ),
        paint,
      );
      x += barW + gap;
      i++;
    }
  }

  @override
  bool shouldRepaint(covariant _WaveformPainter old) =>
      old.color != color || old.peaks != peaks || old.seed != seed;
}

class _TinyBadge extends StatelessWidget {
  final IconData icon;
  final Color color;

  const _TinyBadge({required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 2),
      padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.55),
        borderRadius: BorderRadius.circular(3),
      ),
      child: Icon(icon, size: 10, color: color),
    );
  }
}

class _Playhead extends StatelessWidget {
  final void Function(double dx) onDrag;

  const _Playhead({required this.onDrag});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onHorizontalDragUpdate: (d) => onDrag(d.delta.dx),
      child: SizedBox(
        width: 20,
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            // Vertical line
            Positioned(
              top: 0,
              bottom: 0,
              child: Container(
                width: 2,
                color: AppTheme.playhead,
              ),
            ),
            // Head handle
            Positioned(
              top: 0,
              child: CustomPaint(
                size: const Size(12, 10),
                painter: _PlayheadHeadPainter(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlayheadHeadPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, Paint()..color = AppTheme.playhead);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
