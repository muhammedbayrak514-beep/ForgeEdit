import 'package:flutter/material.dart';

import '../../../domain/models/effect_models.dart';

/// Preview filters: ColorFilter matrix + solid overlay fallback for video textures.
class FilterMatrix {
  static ColorFilter? forPreview(String filterId, double intensity) {
    final id = FilterId.values.asNameMap()[filterId] ?? FilterId.none;
    if (id == FilterId.none || intensity <= 0) return null;
    final t = intensity.clamp(0.0, 1.0);
    final full = _matrixFor(id);
    const identity = <double>[
      1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0,
    ];
    final blended = List<double>.generate(
      20,
      (i) => identity[i] * (1 - t) + full[i] * t,
    );
    return ColorFilter.matrix(blended);
  }

  static List<double> _matrixFor(FilterId id) {
    switch (id) {
      case FilterId.none:
        return [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0];
      case FilterId.grayscale:
        return [
          0.2126, 0.7152, 0.0722, 0, 0, 0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0, 0, 0, 0, 1, 0,
        ];
      case FilterId.sepia:
        return [
          0.393, 0.769, 0.189, 0, 0, 0.349, 0.686, 0.168, 0, 0,
          0.272, 0.534, 0.131, 0, 0, 0, 0, 0, 1, 0,
        ];
      case FilterId.warm:
        return [
          1.12, 0.05, 0, 0, 10, 0, 1.0, 0, 0, 0, 0, 0, 0.88, 0, 0, 0, 0, 0, 1, 0,
        ];
      case FilterId.cool:
        return [
          0.88, 0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0.05, 0.05, 1.18, 0, 12, 0, 0, 0, 1, 0,
        ];
      case FilterId.highContrast:
        return [
          1.5, 0, 0, 0, -50, 0, 1.5, 0, 0, -50, 0, 0, 1.5, 0, -50, 0, 0, 0, 1, 0,
        ];
      case FilterId.muted:
        return [
          0.65, 0.18, 0.18, 0, 0, 0.18, 0.65, 0.18, 0, 0, 0.18, 0.18, 0.65, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case FilterId.vivid:
        return [
          1.35, -0.1, -0.1, 0, 0, -0.1, 1.35, -0.1, 0, 0, -0.1, -0.1, 1.35, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case FilterId.vintage:
        return [
          0.9, 0.2, 0.1, 0, 12, 0.1, 0.85, 0.1, 0, 6, 0.1, 0.15, 0.65, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case FilterId.bright:
        return [
          1.12, 0, 0, 0, 28, 0, 1.12, 0, 0, 28, 0, 0, 1.12, 0, 28, 0, 0, 0, 1, 0,
        ];
      case FilterId.noir:
        return [
          0.25, 0.55, 0.2, 0, -25, 0.25, 0.55, 0.2, 0, -25, 0.25, 0.55, 0.2, 0, -25,
          0, 0, 0, 1, 0,
        ];
      case FilterId.fade:
        return [
          0.85, 0.1, 0.1, 0, 18, 0.1, 0.85, 0.1, 0, 18, 0.1, 0.1, 0.85, 0, 18,
          0, 0, 0, 1, 0,
        ];
      case FilterId.chromakey:
        return [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0];
    }
  }

  /// Semi-transparent tint always visible over video platform views.
  static Color? overlayColor(String filterId, double intensity) {
    final id = FilterId.values.asNameMap()[filterId] ?? FilterId.none;
    final t = intensity.clamp(0.0, 1.0);
    if (id == FilterId.none || t <= 0) return null;
    switch (id) {
      case FilterId.grayscale:
        return Color.fromRGBO(128, 128, 128, 0.25 + 0.35 * t);
      case FilterId.noir:
        return Color.fromRGBO(20, 20, 20, 0.35 + 0.4 * t);
      case FilterId.sepia:
        return Color.fromRGBO(140, 100, 40, 0.28 + 0.35 * t);
      case FilterId.warm:
        return Color.fromRGBO(255, 120, 40, 0.18 + 0.28 * t);
      case FilterId.cool:
        return Color.fromRGBO(40, 120, 255, 0.18 + 0.28 * t);
      case FilterId.highContrast:
        return Color.fromRGBO(0, 0, 0, 0.12 + 0.22 * t);
      case FilterId.muted:
        return Color.fromRGBO(150, 150, 150, 0.22 + 0.32 * t);
      case FilterId.vivid:
        return Color.fromRGBO(255, 40, 80, 0.1 + 0.2 * t);
      case FilterId.vintage:
        return Color.fromRGBO(90, 60, 40, 0.25 + 0.35 * t);
      case FilterId.bright:
        return Color.fromRGBO(255, 255, 255, 0.12 + 0.25 * t);
      case FilterId.fade:
        return Color.fromRGBO(255, 248, 230, 0.2 + 0.35 * t);
      case FilterId.chromakey:
        return Color.fromRGBO(0, 255, 0, 0.08 * t);
      default:
        return null;
    }
  }
}

class FilteredPreview extends StatelessWidget {
  final String filterId;
  final double intensity;
  final Widget child;
  final bool forTexture;

  const FilteredPreview({
    super.key,
    required this.filterId,
    required this.intensity,
    required this.child,
    this.forTexture = false,
  });

  @override
  Widget build(BuildContext context) {
    if (filterId == 'none' || intensity <= 0) return child;

    Widget content = child;
    final matrix = FilterMatrix.forPreview(filterId, intensity);
    if (matrix != null) {
      content = ColorFiltered(colorFilter: matrix, child: content);
    }

    final overlay = FilterMatrix.overlayColor(filterId, intensity);
    // Always add overlay for texture (video) so effect is visible on Android.
    if (overlay != null && forTexture) {
      return Stack(
        fit: StackFit.expand,
        children: [
          content,
          Positioned.fill(
            child: IgnorePointer(
              child: ColoredBox(color: overlay),
            ),
          ),
        ],
      );
    }
    // For images, matrix is usually enough; mild overlay reinforces
    if (overlay != null && !forTexture && intensity > 0.4) {
      return Stack(
        fit: StackFit.expand,
        children: [
          content,
          Positioned.fill(
            child: IgnorePointer(
              child: ColoredBox(
                color: overlay.withValues(alpha: overlay.a * 0.45),
              ),
            ),
          ),
        ],
      );
    }
    return content;
  }
}
