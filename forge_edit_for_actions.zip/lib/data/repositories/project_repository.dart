import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../core/constants/app_constants.dart';
import '../../domain/models/project_model.dart';

/// Handles reading/writing project JSON files and their media folders.
///
/// Layout:
///   documents/projects/{projectId}/
///     project.json
///     media/
///       {clipId}.mp4 / .jpg ...
class ProjectRepository {
  Future<Directory> _projectsRoot() async {
    final docs = await getApplicationDocumentsDirectory();
    final root = Directory(p.join(docs.path, AppConstants.projectsFolder));
    if (!await root.exists()) {
      await root.create(recursive: true);
    }
    return root;
  }

  Future<Directory> projectDir(String projectId) async {
    final root = await _projectsRoot();
    final dir = Directory(p.join(root.path, projectId));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  Future<Directory> mediaDir(String projectId) async {
    final proj = await projectDir(projectId);
    final media = Directory(p.join(proj.path, AppConstants.mediaFolder));
    if (!await media.exists()) {
      await media.create(recursive: true);
    }
    return media;
  }

  Future<File> _projectJsonFile(String projectId) async {
    final dir = await projectDir(projectId);
    return File(p.join(dir.path, 'project.json'));
  }

  Future<List<ProjectModel>> getAllProjects() async {
    final root = await _projectsRoot();
    final projects = <ProjectModel>[];

    await for (final entity in root.list()) {
      if (entity is Directory) {
        final jsonFile = File(p.join(entity.path, 'project.json'));
        if (await jsonFile.exists()) {
          try {
            final content = await jsonFile.readAsString();
            final map = jsonDecode(content) as Map<String, dynamic>;
            projects.add(ProjectModel.fromJson(map));
          } catch (_) {
            // Skip corrupted project folders – do not crash the whole list
          }
        }
      }
    }

    projects.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return projects;
  }

  Future<File> _projectBakFile(String projectId) async {
    final dir = await projectDir(projectId);
    return File(p.join(dir.path, 'project.json.bak'));
  }

  Future<ProjectModel?> getProject(String id) async {
    final file = await _projectJsonFile(id);
    if (await file.exists()) {
      try {
        final content = await file.readAsString();
        return ProjectModel.fromJson(
          jsonDecode(content) as Map<String, dynamic>,
        );
      } catch (_) {
        // fall through to backup
      }
    }
    final bak = await _projectBakFile(id);
    if (await bak.exists()) {
      try {
        final content = await bak.readAsString();
        final model = ProjectModel.fromJson(
          jsonDecode(content) as Map<String, dynamic>,
        );
        // Restore main file from backup
        try {
          await file.writeAsString(content);
        } catch (_) {}
        return model;
      } catch (_) {
        return null;
      }
    }
    return null;
  }

  Future<void> saveProject(ProjectModel project) async {
    final file = await _projectJsonFile(project.id);
    final bak = await _projectBakFile(project.id);
    final json = const JsonEncoder.withIndent('  ').convert(project.toJson());
    // Rotate: current main → bak, then write main
    if (await file.exists()) {
      try {
        await file.copy(bak.path);
      } catch (_) {}
    }
    await file.writeAsString(json);
  }

  Future<void> deleteProject(String id) async {
    final dir = await projectDir(id);
    if (await dir.exists()) {
      await dir.delete(recursive: true);
    }
  }

  Future<ProjectModel?> duplicateProject(String sourceId) async {
    final src = await getProject(sourceId);
    if (src == null) return null;

    final shell = ProjectModel.create(name: '${src.name} (kopya)');
    final dstMedia = await mediaDir(shell.id);
    final srcMedia = await mediaDir(sourceId);

    if (await srcMedia.exists()) {
      await for (final entity in srcMedia.list(recursive: false)) {
        if (entity is! File) continue;
        final dest = p.join(dstMedia.path, p.basename(entity.path));
        await entity.copy(dest);
      }
    }

    final newClips = src.clips.map((c) {
      if (c.filePath.isEmpty) return c;
      final candidate = p.join(dstMedia.path, p.basename(c.filePath));
      if (File(candidate).existsSync()) {
        return c.copyWith(filePath: candidate);
      }
      return c;
    }).toList();

    final finalProject = shell.copyWith(
      width: src.width,
      height: src.height,
      frameRate: src.frameRate,
      clips: newClips,
      updatedAt: DateTime.now(),
    );
    await saveProject(finalProject);
    return finalProject;
  }
}
