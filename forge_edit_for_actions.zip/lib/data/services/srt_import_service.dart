import 'dart:io';

import '../../domain/models/clip_model.dart';

class SrtCue {
  final int startMs;
  final int endMs;
  final String text;
  SrtCue({required this.startMs, required this.endMs, required this.text});
}

class SrtImportService {
  /// Parse classic SRT content into cues.
  static List<SrtCue> parse(String content) {
    final cues = <SrtCue>[];
    final normalized = content.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    final blocks = normalized.split(RegExp(r'\n\s*\n'));
    for (final block in blocks) {
      final lines = block.trim().split('\n');
      if (lines.length < 2) continue;
      var timeIdx = 0;
      if (RegExp(r'^\d+$').hasMatch(lines[0].trim())) {
        timeIdx = 1;
      }
      if (timeIdx >= lines.length) continue;
      final timeLine = lines[timeIdx];
      final m = RegExp(
        r'(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})',
      ).firstMatch(timeLine);
      if (m == null) continue;
      final start = _toMs(m, 1);
      final end = _toMs(m, 5);
      final text = lines.skip(timeIdx + 1).join('\n').trim();
      if (text.isEmpty || end <= start) continue;
      cues.add(SrtCue(startMs: start, endMs: end, text: text));
    }
    return cues;
  }

  static int _toMs(RegExpMatch m, int i) {
    final h = int.parse(m.group(i)!);
    final min = int.parse(m.group(i + 1)!);
    final s = int.parse(m.group(i + 2)!);
    var ms = int.parse(m.group(i + 3)!);
    // Support 1–2 digit millis by scaling
    if (ms < 10) {
      ms *= 100;
    } else if (ms < 100) {
      ms *= 10;
    }
    return ((h * 3600 + min * 60 + s) * 1000) + ms;
  }

  static List<ClipModel> cuesToTextClips(List<SrtCue> cues) {
    return cues.map((c) {
      final dur = (c.endMs - c.startMs).clamp(100, 60000);
      final label =
          c.text.length > 24 ? '${c.text.substring(0, 24)}…' : c.text;
      return ClipModel.text(
        content: c.text.replaceAll('\n', ' '),
        durationMs: dur,
        timelineStartMs: c.startMs,
        fontSize: 28,
        posY: 0.88,
        textStyleId: 'plain_white',
      ).copyWith(
        displayName: label,
        textAnimId: 'fadeIn',
      );
    }).toList();
  }

  static Future<List<ClipModel>> importFile(String path) async {
    final content = await File(path).readAsString();
    return cuesToTextClips(parse(content));
  }

  static List<ClipModel> importString(String content) {
    return cuesToTextClips(parse(content));
  }

  /// Spread [fullText] across [totalDurationMs] as sequential captions.
  /// Not speech recognition — layouts typed transcript automatically.
  static List<ClipModel> autoCaptionFromText({
    required String fullText,
    required int totalDurationMs,
    int startMs = 0,
  }) {
    final cleaned = fullText
        .replaceAll('\r\n', '\n')
        .split(RegExp(r'[\n.!?]+'))
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .toList();
    if (cleaned.isEmpty) return const [];
    final total = totalDurationMs.clamp(1000, 3600000);
    final each = (total / cleaned.length).floor().clamp(800, 8000);
    final clips = <ClipModel>[];
    var t = startMs;
    for (var i = 0; i < cleaned.length; i++) {
      final text = cleaned[i];
      final dur = i == cleaned.length - 1
          ? (startMs + total - t).clamp(500, 60000)
          : each;
      clips.add(
        ClipModel.text(
          content: text,
          durationMs: dur,
          timelineStartMs: t,
          fontSize: 28,
          posY: 0.88,
          textStyleId: 'plain_white',
        ).copyWith(
          displayName: text.length > 24 ? '${text.substring(0, 24)}…' : text,
          textAnimId: 'fadeIn',
        ),
      );
      t += dur;
    }
    return clips;
  }
}
