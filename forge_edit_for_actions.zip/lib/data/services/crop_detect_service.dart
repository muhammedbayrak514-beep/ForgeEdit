
import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';

/// Auto black-bar / letterbox detection via FFmpeg cropdetect.
class CropDetectResult {
  final double left;
  final double top;
  final double right;
  final double bottom;

  const CropDetectResult({
    this.left = 0,
    this.top = 0,
    this.right = 0,
    this.bottom = 0,
  });

  bool get hasCrop =>
      left > 0.001 || top > 0.001 || right > 0.001 || bottom > 0.001;
}

class CropDetectService {
  static Future<(int, int)?> probeSize(String mediaPath) async {
    try {
      final session = await FFprobeKit.getMediaInformation(mediaPath);
      final info = session.getMediaInformation();
      if (info == null) return null;
      final streams = info.getStreams();
      if (streams == null) return null;
      for (final s in streams) {
        final w = s.getWidth();
        final h = s.getHeight();
        if (w != null && h != null && w > 0 && h > 0) {
          return (w, h);
        }
      }
    } catch (_) {}
    return null;
  }

  /// Sample a few seconds and parse cropdetect recommendations.
  static Future<CropDetectResult> detectBlackBars(String mediaPath) async {
    if (mediaPath.isEmpty || !File(mediaPath).existsSync()) {
      return const CropDetectResult();
    }
    // limit analysis length for speed
    final cmd =
        '-ss 0 -t 8 -i "$mediaPath" -vf cropdetect=24:16:0 -f null -';
    final session = await FFmpegKit.execute(cmd);
    final logs = await session.getAllLogsAsString() ?? '';

    // cropdetect lines: crop=w:h:x:y
    final re = RegExp(r'crop=(\d+):(\d+):(\d+):(\d+)');
    int? bestW, bestH, bestX, bestY;
    for (final m in re.allMatches(logs)) {
      final w = int.parse(m.group(1)!);
      final h = int.parse(m.group(2)!);
      final x = int.parse(m.group(3)!);
      final y = int.parse(m.group(4)!);
      // Prefer largest crop area (most stable recommendation)
      if (bestW == null || w * h > bestW * bestH!) {
        bestW = w;
        bestH = h;
        bestX = x;
        bestY = y;
      }
    }
    if (bestW == null || bestH == null) {
      return const CropDetectResult();
    }

    // Need source size — from stream metadata if possible
    final sizeRe = RegExp(r'(\d{3,5})x(\d{3,5})');
    int srcW = 0, srcH = 0;
    for (final m in sizeRe.allMatches(logs)) {
      final w = int.parse(m.group(1)!);
      final h = int.parse(m.group(2)!);
      if (w >= bestW && h >= bestH && w * h > srcW * srcH) {
        srcW = w;
        srcH = h;
      }
    }
    if (srcW <= 0 || srcH <= 0) {
      // assume crop is absolute; cannot normalize
      return const CropDetectResult();
    }

    final left = (bestX! / srcW).clamp(0.0, 0.45);
    final top = (bestY! / srcH).clamp(0.0, 0.45);
    final right = ((srcW - bestX - bestW) / srcW).clamp(0.0, 0.45);
    final bottom = ((srcH - bestY - bestH) / srcH).clamp(0.0, 0.45);

    // Ignore tiny noise
    if (left + right + top + bottom < 0.02) {
      return const CropDetectResult();
    }
    return CropDetectResult(left: left, top: top, right: right, bottom: bottom);
  }

  /// Cover-mode crop to target aspect (center).
  static CropDetectResult coverCrop({
    required double sourceAspect,
    required double targetAspect,
  }) {
    if (sourceAspect <= 0 || targetAspect <= 0) {
      return const CropDetectResult();
    }
    if ((sourceAspect - targetAspect).abs() < 0.02) {
      return const CropDetectResult();
    }
    if (sourceAspect > targetAspect) {
      // source wider → crop left/right
      final keep = targetAspect / sourceAspect;
      final side = ((1 - keep) / 2).clamp(0.0, 0.45);
      return CropDetectResult(left: side, right: side);
    } else {
      final keep = sourceAspect / targetAspect;
      final side = ((1 - keep) / 2).clamp(0.0, 0.45);
      return CropDetectResult(top: side, bottom: side);
    }
  }
}
