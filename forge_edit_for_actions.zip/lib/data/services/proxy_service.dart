import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;

/// Builds a low-res proxy next to the source for smooth preview.
class ProxyService {
  static String proxyPathFor(String mediaPath) {
    final dir = p.dirname(mediaPath);
    final base = p.basenameWithoutExtension(mediaPath);
    return p.join(dir, '$base.proxy.mp4');
  }

  static String pathForPreview(String mediaPath) {
    final proxy = proxyPathFor(mediaPath);
    final f = File(proxy);
    if (f.existsSync() && f.lengthSync() > 0) return proxy;
    return mediaPath;
  }

  static Future<void> generateProxyAsync(String mediaPath) async {
    final out = proxyPathFor(mediaPath);
    if (File(out).existsSync() && File(out).lengthSync() > 0) return;
    try {
      final cmd =
          '-i "$mediaPath" -vf "scale=540:-2" -c:v libx264 -preset ultrafast '
          '-crf 30 -an -movflags +faststart -y "$out"';
      final session = await FFmpegKit.execute(cmd);
      final code = await session.getReturnCode();
      if (!ReturnCode.isSuccess(code)) {
        debugPrint('Proxy generate failed for $mediaPath');
        try {
          final bad = File(out);
          if (await bad.exists()) await bad.delete();
        } catch (_) {}
      }
    } catch (e) {
      debugPrint('Proxy error: $e');
    }
  }
}
