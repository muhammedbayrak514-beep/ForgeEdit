import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../../domain/models/clip_model.dart';
import '../repositories/project_repository.dart';

/// Copies a user-selected audio file into the project media folder.
class AudioImportService {
  final ProjectRepository _projectRepo;
  static const _uuid = Uuid();

  static const supportedAudio = ['mp3', 'm4a', 'aac', 'wav', 'ogg', 'flac', 'mp4', '3gp'];

  AudioImportService(this._projectRepo);

  /// Probe duration in ms via FFprobe; fallback [fallbackMs].
  static Future<int> probeDurationMs(String path, {int fallbackMs = 30000}) async {
    try {
      final session = await FFprobeKit.getMediaInformation(path);
      final info = session.getMediaInformation();
      final durStr = info?.getDuration();
      if (durStr != null) {
        final sec = double.tryParse(durStr);
        if (sec != null && sec > 0.05) {
          return (sec * 1000).round().clamp(200, 3600000);
        }
      }
    } catch (_) {}
    // Fallback: ffmpeg -i stderr parse is heavy; keep fallback
    try {
      final session = await FFmpegKit.execute(
        '-i "$path" -f null -',
      );
      final output = await session.getFailStackTrace() ??
          await session.getOutput() ??
          '';
      final m = RegExp(r'Duration:\s*(\d+):(\d+):(\d+\.\d+)').firstMatch(output);
      if (m != null) {
        final h = int.parse(m.group(1)!);
        final min = int.parse(m.group(2)!);
        final s = double.parse(m.group(3)!);
        return (((h * 3600 + min * 60) + s) * 1000).round().clamp(200, 3600000);
      }
    } catch (_) {}
    return fallbackMs;
  }

  Future<ClipModel?> importAudioFile({
    required String projectId,
    required String sourcePath,
    required String displayName,
    required int timelineStartMs,
    int? durationMs,
  }) async {
    final file = File(sourcePath);
    if (!await file.exists()) return null;

    final ext = p.extension(sourcePath).toLowerCase().replaceFirst('.', '');
    if (ext.isEmpty || !supportedAudio.contains(ext)) {
      throw FormatException(
        'Desteklenmeyen ses biçimi: .$ext. Desteklenen: ${supportedAudio.join(", ")}',
      );
    }

    final size = await file.length();
    if (size == 0) throw const FormatException('Ses dosyası boş');

    final mediaDir = await _projectRepo.mediaDir(projectId);
    final id = _uuid.v4();
    final dest = p.join(mediaDir.path, '$id.$ext');
    await file.copy(dest);

    final srcDur = durationMs != null && durationMs > 0
        ? durationMs
        : await probeDurationMs(dest);

    return ClipModel.fromImportedMedia(
      filePath: dest,
      displayName: displayName,
      type: ClipType.audio,
      sourceDurationMs: srcDur,
      timelineStartMs: timelineStartMs,
      trackIndex: TrackIndex.audio,
    );
  }

  /// Write bytes from picker (when path is null on some Android versions).
  /// Pull audio stream from a video file into a new audio clip.
  Future<ClipModel?> extractFromVideo({
    required String projectId,
    required String videoPath,
    required String displayName,
    required int timelineStartMs,
    int? durationMs,
  }) async {
    final mediaDir = await _projectRepo.mediaDir(projectId);
    final id = _uuid.v4();
    final dest = p.join(mediaDir.path, '$id.m4a');
    final cmd =
        '-y -i "$videoPath" -vn -acodec aac -b:a 192k -ar 44100 -ac 2 "$dest"';
    final session = await FFmpegKit.execute(cmd);
    final code = await session.getReturnCode();
    if (!ReturnCode.isSuccess(code) || !File(dest).existsSync()) {
      // Retry with mp3
      final dest2 = p.join(mediaDir.path, '$id.mp3');
      final cmd2 =
          '-y -i "$videoPath" -vn -acodec libmp3lame -q:a 2 "$dest2"';
      final s2 = await FFmpegKit.execute(cmd2);
      final c2 = await s2.getReturnCode();
      if (!ReturnCode.isSuccess(c2) || !File(dest2).existsSync()) {
        return null;
      }
      final dur = durationMs ?? await probeDurationMs(dest2);
      return ClipModel.fromImportedMedia(
        filePath: dest2,
        displayName: '$displayName (ses)',
        type: ClipType.audio,
        sourceDurationMs: dur,
        timelineStartMs: timelineStartMs,
        trackIndex: TrackIndex.audio,
      );
    }
    final dur = durationMs ?? await probeDurationMs(dest);
    return ClipModel.fromImportedMedia(
      filePath: dest,
      displayName: '$displayName (ses)',
      type: ClipType.audio,
      sourceDurationMs: dur,
      timelineStartMs: timelineStartMs,
      trackIndex: TrackIndex.audio,
    );
  }

  Future<ClipModel?> importAudioBytes({
    required String projectId,
    required List<int> bytes,
    required String fileName,
    required int timelineStartMs,
  }) async {
    if (bytes.isEmpty) return null;
    var ext = p.extension(fileName).toLowerCase().replaceFirst('.', '');
    if (ext.isEmpty) ext = 'mp3';
    if (!supportedAudio.contains(ext)) {
      throw FormatException('Desteklenmeyen ses biçimi: .$ext');
    }
    final mediaDir = await _projectRepo.mediaDir(projectId);
    final id = _uuid.v4();
    final dest = p.join(mediaDir.path, '$id.$ext');
    await File(dest).writeAsBytes(bytes, flush: true);
    final srcDur = await probeDurationMs(dest);
    return ClipModel.fromImportedMedia(
      filePath: dest,
      displayName: fileName,
      type: ClipType.audio,
      sourceDurationMs: srcDur,
      timelineStartMs: timelineStartMs,
      trackIndex: TrackIndex.audio,
    );
  }
}
