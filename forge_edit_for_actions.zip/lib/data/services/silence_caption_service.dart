import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';

import '../../domain/models/clip_model.dart';
import 'srt_import_service.dart';

/// Smart caption timing using FFmpeg silencedetect on a media file.
/// Not full ASR — aligns user-provided sentences to non-silent regions.
class SilenceCaptionService {
  /// Returns list of (startMs, endMs) speech-ish segments.
  static Future<List<(int, int)>> detectSpeechRanges(
    String mediaPath, {
    double noiseDb = -30,
    double minSilence = 0.35,
  }) async {
    if (mediaPath.isEmpty || !File(mediaPath).existsSync()) {
      return const [];
    }
    final cmd =
        '-i "$mediaPath" -af silencedetect=noise=${noiseDb}dB:d=$minSilence -f null -';
    final session = await FFmpegKit.execute(cmd);
    final logs = await session.getAllLogsAsString() ?? '';
    final silenceStarts = <double>[];
    final silenceEnds = <double>[];
    for (final line in logs.split('\n')) {
      final ss = RegExp(r'silence_start:\s*([\d.]+)').firstMatch(line);
      if (ss != null) silenceStarts.add(double.parse(ss.group(1)!));
      final se = RegExp(r'silence_end:\s*([\d.]+)').firstMatch(line);
      if (se != null) silenceEnds.add(double.parse(se.group(1)!));
    }

    // Infer duration from last silence_end or parse Duration
    double durationSec = 0;
    final durM = RegExp(r'Duration:\s*(\d+):(\d+):(\d+\.\d+)').firstMatch(logs);
    if (durM != null) {
      durationSec = int.parse(durM.group(1)!) * 3600 +
          int.parse(durM.group(2)!) * 60 +
          double.parse(durM.group(3)!);
    }
    if (durationSec <= 0 && silenceEnds.isNotEmpty) {
      durationSec = silenceEnds.last + 1;
    }
    if (durationSec <= 0) durationSec = 30;

    // Speech = inverse of silence
    final ranges = <(int, int)>[];
    var cursor = 0.0;
    final events = <(double, bool)>[]; // time, isSilenceStart
    for (final s in silenceStarts) {
      events.add((s, true));
    }
    for (final e in silenceEnds) {
      events.add((e, false));
    }
    events.sort((a, b) => a.$1.compareTo(b.$1));

    var inSilence = false;
    for (final e in events) {
      if (e.$2) {
        // silence start → speech until here
        if (!inSilence && e.$1 > cursor + 0.15) {
          ranges.add(((cursor * 1000).round(), (e.$1 * 1000).round()));
        }
        inSilence = true;
        cursor = e.$1;
      } else {
        inSilence = false;
        cursor = e.$1;
      }
    }
    if (!inSilence && durationSec > cursor + 0.15) {
      ranges.add(((cursor * 1000).round(), (durationSec * 1000).round()));
    }
    if (ranges.isEmpty) {
      ranges.add((0, (durationSec * 1000).round()));
    }
    return ranges;
  }

  /// Place [sentences] onto detected speech ranges (or even split).
  static Future<List<ClipModel>> captionsFromTextAndMedia({
    required String fullText,
    required String mediaPath,
    int timelineOffsetMs = 0,
  }) async {
    final sentences = fullText
        .replaceAll('\r\n', '\n')
        .split(RegExp(r'[\n.!?]+'))
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .toList();
    if (sentences.isEmpty) return const [];

    final ranges = await detectSpeechRanges(mediaPath);
    if (ranges.isEmpty) {
      return SrtImportService.autoCaptionFromText(
        fullText: fullText,
        totalDurationMs: 15000,
        startMs: timelineOffsetMs,
      );
    }

    final clips = <ClipModel>[];
    for (var i = 0; i < sentences.length; i++) {
      final (rs, re) = ranges[i % ranges.length];
      // If more sentences than ranges, subdivide last ranges
      int start = rs;
      int end = re;
      if (sentences.length > ranges.length) {
        final perRange = (sentences.length / ranges.length).ceil();
        final rangeIdx = i ~/ perRange;
        final r = ranges[rangeIdx.clamp(0, ranges.length - 1)];
        final sub = i % perRange;
        final span = ((r.$2 - r.$1) / perRange).floor().clamp(400, 15000);
        start = r.$1 + sub * span;
        end = start + span;
        if (end > r.$2) end = r.$2;
      }
      final dur = (end - start).clamp(400, 15000);
      final text = sentences[i];
      clips.add(
        ClipModel.text(
          content: text,
          durationMs: dur,
          timelineStartMs: timelineOffsetMs + start,
          fontSize: 28,
          posY: 0.88,
          textStyleId: 'plain_white',
        ).copyWith(
          displayName: text.length > 24 ? '${text.substring(0, 24)}…' : text,
          textAnimId: 'fadeIn',
        ),
      );
    }
    return clips;
  }
}
