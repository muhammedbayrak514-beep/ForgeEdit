
import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

/// Offline denoise via FFmpeg afftdn (no cloud / API).
class AudioDenoiseService {
  static const _uuid = Uuid();

  /// Returns path to denoised file (m4a) or null on failure.
  static Future<String?> denoiseFile(
    String inputPath, {
    double noiseFloor = -25,
  }) async {
    if (inputPath.isEmpty || !File(inputPath).existsSync()) return null;
    final tmp = await getTemporaryDirectory();
    final out = p.join(tmp.path, 'denoise_${_uuid.v4()}.m4a');
    // afftdn is widely available; arnndn needs model file — skip
    final nf = noiseFloor.clamp(-50.0, -5.0).toStringAsFixed(1);
    final cmd =
        '-y -i "$inputPath" -af "afftdn=nf=$nf:nt=w" -c:a aac -b:a 192k "$out"';
    final session = await FFmpegKit.execute(cmd);
    final rc = await session.getReturnCode();
    if (ReturnCode.isSuccess(rc) && File(out).existsSync()) {
      return out;
    }
    // Softer fallback
    final out2 = p.join(tmp.path, 'denoise2_${_uuid.v4()}.m4a');
    final cmd2 =
        '-y -i "$inputPath" -af "highpass=f=80,lowpass=f=12000,afftdn=nf=-20" -c:a aac -b:a 192k "$out2"';
    final s2 = await FFmpegKit.execute(cmd2);
    final rc2 = await s2.getReturnCode();
    if (ReturnCode.isSuccess(rc2) && File(out2).existsSync()) {
      return out2;
    }
    return null;
  }
}
