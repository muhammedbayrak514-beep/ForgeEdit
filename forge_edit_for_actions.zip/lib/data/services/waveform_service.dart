import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Builds peak arrays from audio/video files via FFmpeg → mono f32le PCM.
class WaveformService {
  static final Map<String, List<double>> _cache = {};

  /// Returns [barCount] normalized peaks 0..1. Cached by path+mtime.
  static Future<List<double>> peaksFor(
    String filePath, {
    int barCount = 64,
  }) async {
    if (filePath.isEmpty || !File(filePath).existsSync()) {
      return List.filled(barCount, 0.2);
    }
    final stat = File(filePath).statSync();
    final key = '$filePath|${stat.modified.millisecondsSinceEpoch}|$barCount';
    final hit = _cache[key];
    if (hit != null) return hit;

    try {
      final tmp = await getTemporaryDirectory();
      final rawPath = p.join(
        tmp.path,
        'wf_${filePath.hashCode.abs()}_$barCount.f32',
      );
      // Downsample heavily for speed: 4kHz mono float
      final cmd =
          '-y -i "$filePath" -ac 1 -ar 4000 -f f32le -acodec pcm_f32le "$rawPath"';
      final session = await FFmpegKit.execute(cmd);
      final code = await session.getReturnCode();
      if (!ReturnCode.isSuccess(code) || !File(rawPath).existsSync()) {
        return List.filled(barCount, 0.25);
      }
      final bytes = await File(rawPath).readAsBytes();
      try {
        await File(rawPath).delete();
      } catch (_) {}
      if (bytes.length < 4) return List.filled(barCount, 0.2);

      final bd = ByteData.sublistView(bytes);
      final n = bytes.length ~/ 4;
      final peaks = List<double>.filled(barCount, 0);
      final chunk = math.max(1, n ~/ barCount);
      for (var b = 0; b < barCount; b++) {
        final start = b * chunk;
        final end = math.min(n, start + chunk);
        var peak = 0.0;
        for (var i = start; i < end; i++) {
          final v = bd.getFloat32(i * 4, Endian.little).abs();
          if (v > peak) peak = v;
        }
        peaks[b] = peak;
      }
      // Normalize
      var maxP = peaks.fold<double>(0, (a, b) => a > b ? a : b);
      if (maxP < 1e-6) maxP = 1;
      for (var i = 0; i < peaks.length; i++) {
        peaks[i] = (peaks[i] / maxP).clamp(0.05, 1.0);
      }
      _cache[key] = peaks;
      if (_cache.length > 40) {
        _cache.remove(_cache.keys.first);
      }
      return peaks;
    } catch (_) {
      return List.filled(barCount, 0.25);
    }
  }
}
