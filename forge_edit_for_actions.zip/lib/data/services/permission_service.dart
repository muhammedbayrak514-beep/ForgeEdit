import 'package:permission_handler/permission_handler.dart';
import 'package:photo_manager/photo_manager.dart';

/// Centralized permission handling for media access.
class PermissionService {
  /// Request gallery / media library access (images + videos).
  static Future<PermissionState> requestPhotoAccess() async {
    final state = await PhotoManager.requestPermissionExtend(
      requestOption: const PermissionRequestOption(
        androidPermission: AndroidPermission(
          type: RequestType.common, // images + video
          mediaLocation: false,
        ),
      ),
    );
    return state;
  }

  /// Whether we can proceed with media picking.
  static bool canAccessMedia(PermissionState state) {
    return state.isAuth || state.hasAccess;
  }

  /// Open system settings if user permanently denied / limited.
  static Future<void> openSettings() async {
    await PhotoManager.openSetting();
  }

  /// Request audio / music library access (Android 13+ READ_MEDIA_AUDIO).
  static Future<bool> requestAudioAccess() async {
    try {
      var st = await Permission.audio.status;
      if (st.isGranted || st.isLimited) return true;
      if (st.isDenied) {
        st = await Permission.audio.request();
        if (st.isGranted || st.isLimited) return true;
      }
    } catch (_) {}
    try {
      var st = await Permission.storage.status;
      if (st.isGranted || st.isLimited) return true;
      if (st.isDenied) {
        st = await Permission.storage.request();
        return st.isGranted || st.isLimited;
      }
    } catch (_) {}
    return true; // file_picker may still work via SAF
  }

  /// On older Android also request storage.
  static Future<bool> ensureLegacyStorageIfNeeded() async {
    final status = await Permission.storage.status;
    if (status.isGranted || status.isLimited) return true;
    if (status.isDenied) {
      final result = await Permission.storage.request();
      return result.isGranted || result.isLimited;
    }
    // Also try photos/videos permissions on Android 13+ via permission_handler
    // as a secondary path; photo_manager is primary.
    try {
      final photos = await Permission.photos.status;
      if (photos.isDenied) {
        await Permission.photos.request();
      }
      final videos = await Permission.videos.status;
      if (videos.isDenied) {
        await Permission.videos.request();
      }
    } catch (_) {
      // Older platforms may not define these permissions.
    }
    return status.isGranted || status.isLimited;
  }
}
