import 'dart:math' as math;

import 'waveform_service.dart';

/// Detects approximate beat / onset times from audio peaks (local maxima).
class BeatDetectService {
  /// Returns beat times in milliseconds from start of [filePath].
  static Future<List<int>> detectBeats(
    String filePath, {
    int barCount = 256,
    double sensitivity = 0.55,
    int minGapMs = 280,
    int? mediaDurationMs,
  }) async {
    final peaks = await WaveformService.peaksFor(filePath, barCount: barCount);
    if (peaks.isEmpty) return const [];

    final dur = mediaDurationMs ?? (peaks.length * 40); // rough if unknown
    final msPerBar = dur / peaks.length;

    // Adaptive threshold
    final sorted = [...peaks]..sort();
    final median = sorted[sorted.length ~/ 2];
    final threshold =
        (median + (1.0 - median) * sensitivity).clamp(0.2, 0.95);

    final beats = <int>[];
    var lastBeat = -minGapMs;
    for (var i = 1; i < peaks.length - 1; i++) {
      final p = peaks[i];
      if (p < threshold) continue;
      if (p >= peaks[i - 1] && p >= peaks[i + 1]) {
        final t = (i * msPerBar).round();
        if (t - lastBeat >= minGapMs) {
          beats.add(t);
          lastBeat = t;
        }
      }
    }

    // Cap density
    if (beats.length > 80) {
      final step = beats.length / 80;
      final thin = <int>[];
      for (var i = 0; i < 80; i++) {
        thin.add(beats[(i * step).floor()]);
      }
      return thin;
    }
    return beats;
  }

  /// Place project markers at beat times (offset by [timelineOffsetMs]).
  static List<int> toProjectMarkers(
    List<int> beatMs, {
    int timelineOffsetMs = 0,
  }) {
    return [
      for (final b in beatMs) timelineOffsetMs + b,
    ];
  }
}
