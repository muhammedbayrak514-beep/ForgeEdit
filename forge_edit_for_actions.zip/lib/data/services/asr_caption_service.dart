import 'dart:io';

import '../../domain/models/clip_model.dart';
import 'silence_caption_service.dart';
import 'srt_import_service.dart';
import 'waveform_service.dart';

/// Offline-first auto captions (no API key required).
///
/// Uses FFmpeg silence detection + waveform energy to place timed text clips.
/// Optional transcript text is split across speech regions.
/// Optional Whisper path remains for users who provide a key later.
class AsrCaptionService {
  /// Fully offline auto captions from video/audio file.
  ///
  /// [optionalTranscript]: if non-empty, sentences are aligned to speech ranges.
  /// if empty, creates editable slots labeled for each speech segment.
  static Future<List<ClipModel>> autoOffline({
    required String mediaPath,
    String optionalTranscript = '',
    int timelineOffsetMs = 0,
  }) async {
    if (mediaPath.isEmpty || !File(mediaPath).existsSync()) {
      return const [];
    }

    var ranges = await SilenceCaptionService.detectSpeechRanges(mediaPath);
    if (ranges.isEmpty || (ranges.length == 1 && ranges.first.$2 - ranges.first.$1 > 20000)) {
      // Fallback: energy peaks → pseudo speech windows
      ranges = await _rangesFromWaveform(mediaPath);
    }
    if (ranges.isEmpty) {
      ranges = [(0, 5000)];
    }

    // Merge very short gaps, drop tiny segments
    ranges = _cleanRanges(ranges);

    final text = optionalTranscript.trim();
    if (text.isNotEmpty) {
      return SilenceCaptionService.captionsFromTextAndMedia(
        fullText: text,
        mediaPath: mediaPath,
        timelineOffsetMs: timelineOffsetMs,
      );
    }

    // No transcript: timed empty/placeholder captions user can edit
    final clips = <ClipModel>[];
    for (var i = 0; i < ranges.length; i++) {
      final (start, end) = ranges[i];
      final dur = (end - start).clamp(500, 12000);
      final label = 'Altyazı ${i + 1}';
      clips.add(
        ClipModel.text(
          content: label,
          durationMs: dur,
          timelineStartMs: timelineOffsetMs + start,
          fontSize: 28,
          posY: 0.88,
          textStyleId: 'plain_white',
        ).copyWith(
          textAnimId: 'fadeIn',
          textStrokeWidth: 2,
          displayName: label,
        ),
      );
    }
    return clips;
  }

  static List<(int, int)> _cleanRanges(List<(int, int)> ranges) {
    if (ranges.isEmpty) return ranges;
    final sorted = [...ranges]..sort((a, b) => a.$1.compareTo(b.$1));
    final out = <(int, int)>[];
    var curS = sorted.first.$1;
    var curE = sorted.first.$2;
    for (var i = 1; i < sorted.length; i++) {
      final (s, e) = sorted[i];
      if (s - curE < 250) {
        curE = e > curE ? e : curE;
      } else {
        if (curE - curS >= 400) out.add((curS, curE));
        curS = s;
        curE = e;
      }
    }
    if (curE - curS >= 400) out.add((curS, curE));
    // Cap at 40 captions
    if (out.length > 40) {
      return out.sublist(0, 40);
    }
    return out;
  }

  static Future<List<(int, int)>> _rangesFromWaveform(String path) async {
    final peaks = await WaveformService.peaksFor(path, barCount: 128);
    if (peaks.isEmpty) return const [];
    // Assume ~ if unknown duration use 128 * 200ms
    final totalMs = peaks.length * 200;
    final msPer = totalMs / peaks.length;
    final sorted = [...peaks]..sort();
    final thr = sorted[(sorted.length * 0.55).floor().clamp(0, sorted.length - 1)];
    final ranges = <(int, int)>[];
    int? start;
    for (var i = 0; i < peaks.length; i++) {
      final loud = peaks[i] >= thr;
      if (loud && start == null) start = i;
      if (!loud && start != null) {
        final s = (start * msPer).round();
        final e = (i * msPer).round();
        if (e - s >= 400) ranges.add((s, e));
        start = null;
      }
    }
    if (start != null) {
      ranges.add(((start * msPer).round(), totalMs));
    }
    return ranges;
  }

  /// Legacy name: always offline (no key).
  static Future<List<ClipModel>> transcribeToCaptions({
    required String mediaPath,
    String apiKey = '',
    int timelineOffsetMs = 0,
    String optionalTranscript = '',
  }) {
    // API key ignored — offline only per product decision
    return autoOffline(
      mediaPath: mediaPath,
      optionalTranscript: optionalTranscript,
      timelineOffsetMs: timelineOffsetMs,
    );
  }

  static Future<List<ClipModel>> smartOffline({
    required String fullText,
    required String mediaPath,
    int timelineOffsetMs = 0,
  }) {
    return SilenceCaptionService.captionsFromTextAndMedia(
      fullText: fullText,
      mediaPath: mediaPath,
      timelineOffsetMs: timelineOffsetMs,
    );
  }
}
