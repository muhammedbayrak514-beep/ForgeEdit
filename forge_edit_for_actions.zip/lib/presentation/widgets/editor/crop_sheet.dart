
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/clip_model.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';

/// Manual + auto crop / background trim for selected video/image.
class CropSheet extends ConsumerStatefulWidget {
  final String projectId;

  const CropSheet({super.key, required this.projectId});

  static Future<void> open(BuildContext context, String projectId) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => CropSheet(projectId: projectId),
    );
  }

  @override
  ConsumerState<CropSheet> createState() => _CropSheetState();
}

class _CropSheetState extends ConsumerState<CropSheet> {
  double _l = 0, _t = 0, _r = 0, _b = 0;
  bool _busy = false;
  String? _clipId;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final id = ref.read(selectedClipIdProvider(widget.projectId));
    final p = ref.read(editorProvider(widget.projectId)).value;
    final clip = p?.clips.where((c) => c.id == id).firstOrNull;
    if (clip != null && _clipId != clip.id) {
      _clipId = clip.id;
      _l = clip.cropLeft;
      _t = clip.cropTop;
      _r = clip.cropRight;
      _b = clip.cropBottom;
    }
  }

  ClipModel? get _clip {
    final id = ref.watch(selectedClipIdProvider(widget.projectId));
    final p = ref.watch(editorProvider(widget.projectId)).value;
    return p?.clips.where((c) => c.id == id).firstOrNull;
  }

  Future<void> _applyManual() async {
    final clip = _clip;
    if (clip == null) return;
    await ref.read(editorProvider(widget.projectId).notifier).applyManualCrop(
          clipId: clip.id,
          left: _l,
          top: _t,
          right: _r,
          bottom: _b,
        );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Manuel kırpma uygulandı')),
      );
    }
  }

  Future<void> _autoCover() async {
    final clip = _clip;
    if (clip == null) return;
    setState(() => _busy = true);
    await ref
        .read(editorProvider(widget.projectId).notifier)
        .autoCropCover(clip.id);
    final updated = _clip;
    if (updated != null) {
      setState(() {
        _l = updated.cropLeft;
        _t = updated.cropTop;
        _r = updated.cropRight;
        _b = updated.cropBottom;
        _busy = false;
      });
    } else {
      setState(() => _busy = false);
    }
  }

  Future<void> _autoBars() async {
    final clip = _clip;
    if (clip == null) return;
    setState(() => _busy = true);
    final ok = await ref
        .read(editorProvider(widget.projectId).notifier)
        .autoCropBlackBars(clip.id);
    final updated = _clip;
    if (updated != null) {
      setState(() {
        _l = updated.cropLeft;
        _t = updated.cropTop;
        _r = updated.cropRight;
        _b = updated.cropBottom;
        _busy = false;
      });
    } else {
      setState(() => _busy = false);
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            ok
                ? 'Siyah kenarlar tespit edildi ve kırpıldı'
                : 'Kenar bandı bulunamadı',
          ),
        ),
      );
    }
  }

  Future<void> _reset() async {
    final clip = _clip;
    if (clip == null) return;
    await ref.read(editorProvider(widget.projectId).notifier).clearCrop(clip.id);
    setState(() {
      _l = _t = _r = _b = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final clip = _clip;
    final h = MediaQuery.sizeOf(context).height * 0.72;

    return SafeArea(
      child: SizedBox(
        height: h,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: clip == null ||
                  (clip.type != ClipType.video && clip.type != ClipType.image)
              ? const Center(
                  child: Text(
                    'Kırpma için video veya fotoğraf seç',
                    style: TextStyle(color: AppTheme.textSecondary),
                  ),
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: AppTheme.border,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const Text(
                      'Arka plan / kare kırpma',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 17,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      clip.displayName,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Sığdırma modu',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Expanded(
                          child: ChoiceChip(
                            label: const Text('Sığdır (contain)'),
                            selected: (clip.fitMode) == 'contain',
                            onSelected: (_) {
                              ref
                                  .read(editorProvider(widget.projectId).notifier)
                                  .updateClip(clip.copyWith(fitMode: 'contain'));
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ChoiceChip(
                            label: const Text('Kapla (cover)'),
                            selected: (clip.fitMode) == 'cover',
                            onSelected: (_) {
                              ref
                                  .read(editorProvider(widget.projectId).notifier)
                                  .updateClip(clip.copyWith(fitMode: 'cover'));
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    // Preview crop frame mock
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppTheme.border),
                        ),
                        child: LayoutBuilder(
                          builder: (context, c) {
                            final keepL = _l * c.maxWidth;
                            final keepT = _t * c.maxHeight;
                            final keepR = _r * c.maxWidth;
                            final keepB = _b * c.maxHeight;
                            return Stack(
                              children: [
                                Positioned.fill(
                                  child: CustomPaint(
                                    painter: _CropGridPainter(),
                                  ),
                                ),
                                // Dim outside crop
                                Positioned(
                                  left: 0,
                                  top: 0,
                                  right: 0,
                                  height: keepT,
                                  child: Container(
                                    color: Colors.black.withValues(alpha: 0.55),
                                  ),
                                ),
                                Positioned(
                                  left: 0,
                                  bottom: 0,
                                  right: 0,
                                  height: keepB,
                                  child: Container(
                                    color: Colors.black.withValues(alpha: 0.55),
                                  ),
                                ),
                                Positioned(
                                  left: 0,
                                  top: keepT,
                                  width: keepL,
                                  bottom: keepB,
                                  child: Container(
                                    color: Colors.black.withValues(alpha: 0.55),
                                  ),
                                ),
                                Positioned(
                                  right: 0,
                                  top: keepT,
                                  width: keepR,
                                  bottom: keepB,
                                  child: Container(
                                    color: Colors.black.withValues(alpha: 0.55),
                                  ),
                                ),
                                Positioned(
                                  left: keepL,
                                  top: keepT,
                                  right: keepR,
                                  bottom: keepB,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        color: AppTheme.primary,
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                ),
                                const Center(
                                  child: Icon(
                                    Icons.crop,
                                    color: Colors.white38,
                                    size: 40,
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Otomatik',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _busy ? null : _autoCover,
                            icon: const Icon(Icons.aspect_ratio, size: 18),
                            label: const Text('Orana sığdır',
                                style: TextStyle(fontSize: 12)),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _busy ? null : _autoBars,
                            icon: _busy
                                ? const SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Icon(Icons.auto_awesome, size: 18),
                            label: const Text('Siyah kenar',
                                style: TextStyle(fontSize: 12)),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Manuel kenarlar',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    _slider('Sol', _l, (v) => setState(() => _l = v)),
                    _slider('Üst', _t, (v) => setState(() => _t = v)),
                    _slider('Sağ', _r, (v) => setState(() => _r = v)),
                    _slider('Alt', _b, (v) => setState(() => _b = v)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _reset,
                            child: const Text('Sıfırla'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          flex: 2,
                          child: FilledButton.icon(
                            onPressed: _applyManual,
                            icon: const Icon(Icons.check),
                            label: const Text('Uygula'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _slider(String label, double value, ValueChanged<double> onChanged) {
    return Row(
      children: [
        SizedBox(
          width: 36,
          child: Text(label, style: const TextStyle(fontSize: 12)),
        ),
        Expanded(
          child: Slider(
            min: 0,
            max: 0.4,
            value: value.clamp(0, 0.4),
            onChanged: onChanged,
          ),
        ),
        SizedBox(
          width: 40,
          child: Text(
            '${(value * 100).round()}%',
            style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
          ),
        ),
      ],
    );
  }
}

class _CropGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = Colors.white12
      ..strokeWidth = 1;
    for (var i = 1; i < 3; i++) {
      final x = size.width * i / 3;
      final y = size.height * i / 3;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
