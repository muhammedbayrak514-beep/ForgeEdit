import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/effect_models.dart';
import 'filter_matrix.dart';

/// Mini animated demo of a transition style (A → B).
class TransitionDemo extends StatefulWidget {
  final String style;
  final double size;
  final bool autoPlay;
  final VoidCallback? onFinished;

  const TransitionDemo({
    super.key,
    required this.style,
    this.size = 72,
    this.autoPlay = true,
    this.onFinished,
  });

  @override
  State<TransitionDemo> createState() => _TransitionDemoState();
}

class _TransitionDemoState extends State<TransitionDemo>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    if (widget.autoPlay) {
      _c.forward().whenComplete(() => widget.onFinished?.call());
    }
  }

  @override
  void didUpdateWidget(covariant TransitionDemo old) {
    super.didUpdateWidget(old);
    if (old.style != widget.style) {
      _c.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void replay() {
    _c.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CustomPaint(
              painter: _TransitionPainter(
                progress: _c.value,
                style: widget.style,
              ),
              child: const SizedBox.expand(),
            ),
          );
        },
      ),
    );
  }
}

class _TransitionPainter extends CustomPainter {
  final double progress;
  final String style;

  _TransitionPainter({required this.progress, required this.style});

  @override
  void paint(Canvas canvas, Size size) {
    final a = Paint()..color = const Color(0xFF5B8CFF);
    final b = Paint()..color = const Color(0xFFFF7043);
    // Base B (incoming)
    canvas.drawRect(Offset.zero & size, b);

    final t = progress.clamp(0.0, 1.0);
    final w = size.width;
    final h = size.height;

    switch (style) {
      case 'none':
        canvas.drawRect(Offset.zero & size, a);
        break;
      case 'fade':
      case 'dissolve':
        canvas.drawRect(
          Offset.zero & size,
          Paint()..color = const Color(0xFF5B8CFF).withValues(alpha: 1 - t),
        );
        break;
      case 'fadeBlack':
        canvas.drawRect(Offset.zero & size, a);
        canvas.drawRect(
          Offset.zero & size,
          Paint()..color = Colors.black.withValues(alpha: t < 0.5 ? t * 2 : (1 - t) * 2),
        );
        break;
      case 'fadeWhite':
        canvas.drawRect(Offset.zero & size, a);
        canvas.drawRect(
          Offset.zero & size,
          Paint()..color = Colors.white.withValues(alpha: t < 0.5 ? t * 2 : (1 - t) * 2),
        );
        break;
      case 'wipeLeft':
        canvas.drawRect(Rect.fromLTWH(w * t, 0, w * (1 - t), h), a);
        break;
      case 'wipeRight':
        canvas.drawRect(Rect.fromLTWH(0, 0, w * (1 - t), h), a);
        break;
      case 'wipeUp':
        canvas.drawRect(Rect.fromLTWH(0, h * t, w, h * (1 - t)), a);
        break;
      case 'wipeDown':
        canvas.drawRect(Rect.fromLTWH(0, 0, w, h * (1 - t)), a);
        break;
      case 'slideLeft':
        canvas.drawRect(Rect.fromLTWH(-w * t, 0, w, h), a);
        break;
      case 'slideRight':
        canvas.drawRect(Rect.fromLTWH(w * t, 0, w, h), a);
        break;
      case 'slideUp':
        canvas.drawRect(Rect.fromLTWH(0, -h * t, w, h), a);
        break;
      case 'slideDown':
        canvas.drawRect(Rect.fromLTWH(0, h * t, w, h), a);
        break;
      case 'circleOpen':
        canvas.drawRect(Offset.zero & size, a);
        final r = t * math.sqrt(w * w + h * h) / 2;
        canvas.drawCircle(
          Offset(w / 2, h / 2),
          r,
          Paint()..blendMode = BlendMode.clear,
        );
        // redraw B in circle — use clip
        break;
      case 'circleClose':
        final path = Path()..addRect(Offset.zero & size);
        final r = (1 - t) * math.sqrt(w * w + h * h) / 2;
        path.addOval(Rect.fromCircle(center: Offset(w / 2, h / 2), radius: r));
        path.fillType = PathFillType.evenOdd;
        canvas.drawPath(path, a);
        break;
      case 'pixel':
        canvas.drawRect(Offset.zero & size, a);
        final cells = (2 + t * 10).round().clamp(2, 12);
        final cw = w / cells;
        final ch = h / cells;
        for (var i = 0; i < cells; i++) {
          for (var j = 0; j < cells; j++) {
            if ((i + j) % 2 == 0) {
              canvas.drawRect(
                Rect.fromLTWH(i * cw, j * ch, cw, ch),
                Paint()..color = const Color(0xFFFF7043).withValues(alpha: t),
              );
            }
          }
        }
        break;
      default:
        canvas.drawRect(
          Offset.zero & size,
          Paint()..color = const Color(0xFF5B8CFF).withValues(alpha: 1 - t),
        );
    }

    // circleOpen: cut hole showing B
    if (style == 'circleOpen') {
      final r = t * math.sqrt(w * w + h * h) / 2;
      canvas.save();
      canvas.clipPath(
        Path()..addOval(Rect.fromCircle(center: Offset(w / 2, h / 2), radius: r)),
      );
      canvas.drawRect(Offset.zero & size, b);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _TransitionPainter old) =>
      old.progress != progress || old.style != style;
}

/// Static filter swatch with ColorFilter.
class FilterSwatch extends StatelessWidget {
  final String filterId;
  final double intensity;
  final double size;
  final bool selected;

  const FilterSwatch({
    super.key,
    required this.filterId,
    this.intensity = 1.0,
    this.size = 56,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    final cf = FilterMatrix.forPreview(filterId, intensity);
    Widget face = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        gradient: const LinearGradient(
          colors: [Color(0xFF5B8CFF), Color(0xFFFF7043), Color(0xFF22C55E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: const Icon(Icons.landscape, color: Colors.white70, size: 28),
    );
    if (cf != null) {
      face = ColorFiltered(colorFilter: cf, child: face);
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: selected ? AppTheme.primary : AppTheme.border,
          width: selected ? 2 : 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(9),
        child: face,
      ),
    );
  }
}

IconData transitionIcon(String id) {
  switch (id) {
    case 'none':
      return Icons.cut;
    case 'crossfade':
    case 'dissolve':
      return Icons.blur_on;
    case 'fadeBlack':
      return Icons.brightness_2;
    case 'fadeWhite':
      return Icons.brightness_7;
    case 'wipeLeft':
    case 'wipeRight':
    case 'wipeUp':
    case 'wipeDown':
      return Icons.swipe;
    case 'slideLeft':
    case 'slideRight':
    case 'slideUp':
    case 'slideDown':
      return Icons.swap_horiz;
    case 'circleOpen':
    case 'circleClose':
    case 'radial':
      return Icons.circle_outlined;
    case 'pixelize':
      return Icons.grid_on;
    case 'hblur':
      return Icons.blur_linear;
    default:
      return Icons.animation;
  }
}

String transitionPreviewStyle(TransitionDef tr) => tr.previewStyle;
