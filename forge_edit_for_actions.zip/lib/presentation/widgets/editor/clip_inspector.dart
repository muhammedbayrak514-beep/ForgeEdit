import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/time_formatter.dart';
import '../../../domain/models/clip_model.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../providers/timeline_clock_provider.dart';
import 'text_style_sheet.dart';
import '../../../domain/models/text_style_catalog.dart';
import '../../../domain/models/text_anim_catalog.dart';
import '../../../domain/models/speed_ramp_presets.dart';
import 'keyframe_graph_sheet.dart';
import 'crop_sheet.dart';
import 'package:collection/collection.dart';

/// Bottom-of-tools / overlay controls for the selected clip.
/// Stage 5: trim handles (start/end sliders), split, delete, reorder.
class ClipInspector extends ConsumerWidget {
  final String projectId;

  const ClipInspector({super.key, required this.projectId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedId = ref.watch(selectedClipIdProvider(projectId));
    final project = ref.watch(editorProvider(projectId)).value;
    if (selectedId == null || project == null) {
      return const SizedBox.shrink();
    }
    final clip = project.clips.where((c) => c.id == selectedId).firstOrNull;
    if (clip == null) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      decoration: const BoxDecoration(
        color: AppTheme.surfaceElevated,
        border: Border(top: BorderSide(color: AppTheme.border)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  clip.displayName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
              ),
              Text(
                TimeFormatter.formatMs(clip.durationMs),
                style: const TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Trim range (source time)
          _TrimSliders(projectId: projectId, clip: clip),
          const SizedBox(height: 4),
          // Opacity for visual clips
          if (clip.type == ClipType.video || clip.type == ClipType.image) ...[
            Text(
              'Opaklık: ${(clip.opacity * 100).round()}%',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Slider(
              value: clip.opacity.clamp(0.0, 1.0),
              onChangeStart: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .beginContinuousEdit('opacity_${clip.id}');
              },
              onChanged: (v) {
                ref.read(editorProvider(projectId).notifier).updateClip(
                      clip.copyWith(opacity: v),
                      continuous: true,
                    );
              },
              onChangeEnd: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .endContinuousEdit();
              },
            ),
          ],

          TextButton.icon(
            onPressed: () {
              KeyframeGraphSheet.open(
                context,
                projectId: projectId,
                clipId: clip.id,
              );
            },
            icon: const Icon(Icons.show_chart, size: 18),
            label: const Text('Keyframe grafiği'),
          ),
          if (clip.type == ClipType.text ||
              clip.trackIndex == TrackIndex.sticker) ...[
            const SizedBox(height: 4),
            Text(
              'Animasyon: ${TextAnimCatalog.byId(clip.textAnimId).label}',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            SizedBox(
              height: 36,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (final a in (clip.type == ClipType.text
                      ? TextAnimCatalog.forText()
                      : TextAnimCatalog.forSticker()))
                    Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: ChoiceChip(
                        label: Text(a.label, style: const TextStyle(fontSize: 11)),
                        selected: clip.textAnimId == a.id,
                        onSelected: (_) {
                          ref
                              .read(editorProvider(projectId).notifier)
                              .updateClip(clip.copyWith(textAnimId: a.id));
                        },
                      ),
                    ),
                ],
              ),
            ),
          ],
          if (clip.type == ClipType.text) ...[
            Text(
              'Stroke: ${clip.textStrokeWidth.toStringAsFixed(0)} · Glow: ${(clip.textGlow * 100).round()}%',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Row(
              children: [
                Expanded(
                  child: Slider(
                    min: 0,
                    max: 8,
                    value: clip.textStrokeWidth.clamp(0, 8),
                    onChanged: (v) {
                      ref.read(editorProvider(projectId).notifier).updateClip(
                            clip.copyWith(textStrokeWidth: v),
                          );
                    },
                  ),
                ),
                Expanded(
                  child: Slider(
                    min: 0,
                    max: 1,
                    value: clip.textGlow.clamp(0, 1),
                    onChanged: (v) {
                      ref.read(editorProvider(projectId).notifier).updateClip(
                            clip.copyWith(textGlow: v),
                          );
                    },
                  ),
                ),
              ],
            ),
          ],
          if (clip.type == ClipType.video || clip.type == ClipType.image) ...[
            const Text('Sığdırma',
                style: TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
            Wrap(
              spacing: 6,
              children: [
                for (final m in [('contain', 'Sığdır'), ('cover', 'Kapla')])
                  ChoiceChip(
                    label: Text(m.$2),
                    selected: clip.fitMode == m.$1,
                    onSelected: (_) {
                      ref.read(editorProvider(projectId).notifier).updateClip(
                            clip.copyWith(fitMode: m.$1),
                          );
                    },
                  ),
              ],
            ),
            TextButton.icon(
              onPressed: () => CropSheet.open(context, projectId),
              icon: const Icon(Icons.crop, size: 18),
              label: Text(
                clip.hasCrop
                    ? 'Kırpma (${clip.cropMode})'
                    : 'Kırp / arka plan',
              ),
            ),
            Text(
              'Arka plan blur: ${(clip.bgBlur * 100).round()}%',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Slider(
              min: 0,
              max: 1,
              value: clip.bgBlur.clamp(0, 1),
              onChanged: (v) {
                ref.read(editorProvider(projectId).notifier).updateClip(
                      clip.copyWith(bgBlur: v),
                    );
              },
            ),
          ],
          if (clip.type == ClipType.audio || clip.type == ClipType.video) ...[
            TextButton.icon(
              onPressed: () async {
                final ok = await ref
                    .read(editorProvider(projectId).notifier)
                    .denoiseClip(clip.id);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        ok
                            ? 'Gürültü temizlendi (afftdn)'
                            : 'Denoise başarısız — dosyayı kontrol et',
                      ),
                    ),
                  );
                }
              },
              icon: const Icon(Icons.hearing, size: 18),
              label: const Text('Gürültü temizle (AI Denoise)'),
            ),
          ],
          if (clip.type == ClipType.audio) ...[
            const Text(
              'Ses efekti',
              style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Wrap(
              spacing: 6,
              children: [
                for (final e in [
                  ('none', 'Yok'),
                  ('echo', 'Echo'),
                  ('reverb', 'Reverb'),
                  ('robot', 'Robot'),
                ])
                  ChoiceChip(
                    label: Text(e.$2),
                    selected: clip.audioEffectId == e.$1,
                    onSelected: (_) {
                      ref.read(editorProvider(projectId).notifier).updateClip(
                            clip.copyWith(audioEffectId: e.$1),
                          );
                    },
                  ),
              ],
            ),
          ],
          if (clip.type == ClipType.video || clip.type == ClipType.image) ...[
            const Text(
              'Hız eğrisi (Bezier ramp)',
              style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            SizedBox(
              height: 36,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (final p in SpeedRampPreset.all)
                    Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: ChoiceChip(
                        label: Text(p.label, style: const TextStyle(fontSize: 11)),
                        selected: (clip.speed - p.speedStart).abs() < 0.05 &&
                            (clip.speedEnd - p.speedEnd).abs() < 0.05,
                        onSelected: (_) {
                          ref
                              .read(editorProvider(projectId).notifier)
                              .applySpeedRampPreset(clip.id, p);
                        },
                      ),
                    ),
                ],
              ),
            ),
          ],
          // Speed presets (video / image / audio)
          if (clip.type == ClipType.video ||
              clip.type == ClipType.image ||
              clip.type == ClipType.audio) ...[
            const SizedBox(height: 4),
            Text(
              'Hız: ${clip.speed == clip.speed.roundToDouble() ? clip.speed.toStringAsFixed(0) : clip.speed.toStringAsFixed(1)}x',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            const SizedBox(height: 4),
            Wrap(
              spacing: 6,
              children: [
                for (final s in [0.5, 0.75, 1.0, 1.5, 2.0])
                  ChoiceChip(
                    label: Text('${s}x'),
                    selected: (clip.speed - s).abs() < 0.01 &&
                        (clip.speedEnd - clip.speed).abs() < 0.01,
                    onSelected: (_) {
                      ref.read(editorProvider(projectId).notifier).updateClip(
                            clip.copyWith(speed: s, speedEnd: s),
                          );
                    },
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'Hız rampası (bitiş): '
              '${clip.speedEnd.toStringAsFixed(1)}x',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Wrap(
              spacing: 6,
              children: [
                for (final s in [0.5, 1.0, 1.5, 2.0, 3.0])
                  ChoiceChip(
                    label: Text('→ ${s}x'),
                    selected: (clip.speedEnd - s).abs() < 0.01,
                    onSelected: (_) {
                      ref.read(editorProvider(projectId).notifier).updateClip(
                            clip.copyWith(speedEnd: s),
                          );
                    },
                  ),
              ],
            ),
          ],
          // Fades
          if (clip.type == ClipType.video ||
              clip.type == ClipType.image ||
              clip.type == ClipType.audio) ...[
            Text(
              'Fade in: ${clip.fadeInMs} ms',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Slider(
              min: 0,
              max: 2000,
              divisions: 20,
              value: clip.fadeInMs.clamp(0, 2000).toDouble(),
              onChanged: (v) {
                ref.read(editorProvider(projectId).notifier).setClipFades(
                      clipId: clip.id,
                      fadeInMs: v.round(),
                    );
              },
            ),
            Text(
              'Fade out: ${clip.fadeOutMs} ms',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Slider(
              min: 0,
              max: 2000,
              divisions: 20,
              value: clip.fadeOutMs.clamp(0, 2000).toDouble(),
              onChanged: (v) {
                ref.read(editorProvider(projectId).notifier).setClipFades(
                      clipId: clip.id,
                      fadeOutMs: v.round(),
                    );
              },
            ),
          ],
          // Volume for audio + video
          if (clip.type == ClipType.audio || clip.type == ClipType.video) ...[
            Text(
              'Ses: ${(clip.volume * 100).round()}%',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Slider(
              value: clip.volume.clamp(0.0, 1.0),
              onChangeStart: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .beginContinuousEdit('vol_${clip.id}');
              },
              onChanged: (v) {
                ref.read(editorProvider(projectId).notifier).updateClip(
                      clip.copyWith(volume: v),
                      continuous: true,
                    );
              },
              onChangeEnd: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .endContinuousEdit();
              },
            ),
          ],
          // Color tag
          const Text(
            'Renk etiketi',
            style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 4),
          Wrap(
            spacing: 6,
            children: [
              for (final tag in [
                ('none', 'Yok', AppTheme.border),
                ('red', 'Kırmızı', Color(0xFFFF4D6A)),
                ('orange', 'Turuncu', Color(0xFFFFB020)),
                ('green', 'Yeşil', Color(0xFF22C55E)),
                ('blue', 'Mavi', Color(0xFF5B8CFF)),
                ('purple', 'Mor', Color(0xFFA855F7)),
              ])
                FilterChip(
                  label: Text(tag.$2, style: const TextStyle(fontSize: 11)),
                  selected: clip.colorTag == tag.$1,
                  onSelected: (_) {
                    ref
                        .read(editorProvider(projectId).notifier)
                        .setClipColorTag(clip.id, tag.$1);
                  },
                  selectedColor: tag.$3.withValues(alpha: 0.35),
                  checkmarkColor: tag.$3,
                ),
            ],
          ),
          const SizedBox(height: 8),
          // Text content edit
          if (clip.type == ClipType.text) ...[
            TextField(
              controller: TextEditingController(text: clip.textContent),
              maxLines: 2,
              style: const TextStyle(fontSize: 13),
              decoration: const InputDecoration(
                isDense: true,
                labelText: 'Metin',
              ),
              onSubmitted: (v) {
                if (v.trim().isEmpty) return;
                ref.read(editorProvider(projectId).notifier).updateTextClip(
                      clipId: clip.id,
                      textContent: v.trim(),
                    );
              },
            ),
            const SizedBox(height: 4),
            Text(
              'Boyut: ${clip.fontSize.round()}',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Slider(
              min: 12,
              max: 96,
              value: clip.fontSize.clamp(12, 96),
              onChangeStart: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .beginContinuousEdit('font_${clip.id}');
              },
              onChanged: (v) {
                ref.read(editorProvider(projectId).notifier).updateTextClip(
                      clipId: clip.id,
                      fontSize: v,
                      continuous: true,
                    );
              },
              onChangeEnd: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .endContinuousEdit();
              },
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () {
                TextStyleSheet.open(
                  context,
                  projectId: projectId,
                  clipId: clip.id,
                  currentStyleId: clip.textStyleId,
                );
              },
              icon: const Icon(Icons.style, size: 18),
              label: Text(
                'Stil: ${TextStyleCatalog.byId(clip.textStyleId).label}',
                overflow: TextOverflow.ellipsis,
              ),
            ),

            const SizedBox(height: 8),
            const Text(
              'Yazı animasyonu',
              style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            const SizedBox(height: 4),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final a in TextAnimCatalog.all)
                  ChoiceChip(
                    label: Text(a.label, style: const TextStyle(fontSize: 12)),
                    selected: clip.textAnimId == a.id,
                    onSelected: (_) {
                      ref.read(editorProvider(projectId).notifier).updateClip(
                            clip.copyWith(textAnimId: a.id),
                          );
                    },
                  ),
              ],
            ),
          ],
          // Action buttons
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _ActionChip(
                icon: Icons.content_cut,
                label: 'Böl',
                onPressed: () async {
                  final ok = await ref
                      .read(editorProvider(projectId).notifier)
                      .splitAtPlayhead(clip.id);
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        ok
                            ? 'Klip playhead konumunda bölündü'
                            : 'Bölme geçersiz (playhead klip içinde ve kenarlardan uzak olmalı)',
                      ),
                      backgroundColor: ok ? null : AppTheme.danger,
                    ),
                  );
                },
              ),
              _ActionChip(
                icon: Icons.arrow_back,
                label: 'Sola',
                onPressed: () => ref
                    .read(editorProvider(projectId).notifier)
                    .moveClipLeft(clip.id),
              ),
              _ActionChip(
                icon: Icons.arrow_forward,
                label: 'Sağa',
                onPressed: () => ref
                    .read(editorProvider(projectId).notifier)
                    .moveClipRight(clip.id),
              ),
              _ActionChip(
                icon: Icons.copy_all_outlined,
                label: 'Kopyala',
                  onPressed: () {
                    ref.read(editorProvider(projectId).notifier).copyClip(clip.id);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Klip kopyalandı')),
                    );
                  },
                ),
                _ActionChip(
                  icon: Icons.content_paste,
                  label: 'Yapıştır',
                  onPressed: () async {
                    await ref
                        .read(editorProvider(projectId).notifier)
                        .pasteClipAtPlayhead();
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Playhead’e yapıştırıldı')),
                      );
                    }
                  },
                ),
                _ActionChip(
                  icon: Icons.animation,
                  label: 'Keyframe',
                  onPressed: () async {
                    await ref
                        .read(editorProvider(projectId).notifier)
                        .addKeyframeAtPlayhead(clip.id);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Keyframe eklendi (playhead)',
                          ),
                        ),
                      );
                    }
                  },
                ),
                if (clip.keyframes.isNotEmpty)
                  _ActionChip(
                    icon: Icons.clear_all,
                    label: 'KF sil',
                    onPressed: () async {
                      await ref
                          .read(editorProvider(projectId).notifier)
                          .clearKeyframes(clip.id);
                    },
                  ),
                _ActionChip(
                  icon: Icons.copy_all,
                  label: 'Çoğalt',
                onPressed: () {
                  if (clip.locked) return;
                  ref
                      .read(editorProvider(projectId).notifier)
                      .duplicateClip(clip.id);
                },
              ),
              _ActionChip(
                icon: clip.locked ? Icons.lock : Icons.lock_open,
                label: clip.locked ? 'Kilitli' : 'Kilitle',
                onPressed: () {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .toggleClipLock(clip.id);
                },
              ),
              if (clip.type == ClipType.video || clip.type == ClipType.audio)
                _ActionChip(
                  icon: Icons.swap_horiz,
                  label: clip.reversed ? 'Ters açık' : 'Ters',
                  onPressed: () {
                    if (clip.locked) return;
                    ref
                        .read(editorProvider(projectId).notifier)
                        .toggleReverse(clip.id);
                  },
                ),
              if (clip.type == ClipType.video || clip.type == ClipType.audio)
                _ActionChip(
                  icon: (clip.muted || clip.volume < 0.001)
                      ? Icons.volume_off
                      : Icons.volume_up,
                  label: (clip.muted || clip.volume < 0.001) ? 'Sessiz' : 'Ses',
                  onPressed: () {
                    if (clip.locked) return;
                    ref
                        .read(editorProvider(projectId).notifier)
                        .toggleMute(clip.id);
                  },
                ),
              if ((clip.type == ClipType.video || clip.type == ClipType.image) &&
                  clip.trackIndex != TrackIndex.overlay)
                _ActionChip(
                  icon: Icons.picture_in_picture_alt,
                  label: 'PiP yap',
                  onPressed: () {
                    if (clip.locked) return;
                    ref
                        .read(editorProvider(projectId).notifier)
                        .convertToPip(clip.id);
                  },
                ),
              if (clip.trackIndex == TrackIndex.overlay)
                _ActionChip(
                  icon: Icons.fullscreen,
                  label: 'Ana track',
                  onPressed: () {
                    if (clip.locked) return;
                    ref
                        .read(editorProvider(projectId).notifier)
                        .convertPipToMain(clip.id);
                  },
                ),
              if (clip.type == ClipType.video)
                _ActionChip(
                  icon: Icons.music_off,
                  label: 'Sadece müzik',
                  onPressed: () async {
                    await ref.read(editorProvider(projectId).notifier).updateClip(
                          clip.copyWith(muted: true, volume: 0),
                        );
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Video sesi kapatıldı — A şeridi müziği öne çıkar',
                          ),
                        ),
                      );
                    }
                  },
                ),
              if (clip.type == ClipType.video)
                _ActionChip(
                  icon: Icons.audiotrack,
                  label: 'Ses ayır',
                  onPressed: () async {
                    final a = await ref
                        .read(editorProvider(projectId).notifier)
                        .extractAudioFromVideo(clip.id);
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          a != null
                              ? 'Ses A şeridine eklendi'
                              : 'Ses ayrılamadı (videoda ses olmayabilir)',
                        ),
                      ),
                    );
                  },
                ),
              if (clip.type == ClipType.video)
                _ActionChip(
                  icon: Icons.camera_alt_outlined,
                  label: 'Dondur',
                  onPressed: () async {
                    final f = await ref
                        .read(editorProvider(projectId).notifier)
                        .freezeFrameAtPlayhead(clip.id);
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          f != null
                              ? 'Dondurulmuş kare eklendi'
                              : 'Kare alınamadı',
                        ),
                      ),
                    );
                  },
                ),
              if (clip.type == ClipType.video || clip.type == ClipType.image)
                _ActionChip(
                  icon: Icons.find_replace,
                  label: 'Medya değiştir',
                  onPressed: () async {
                    if (clip.locked) return;
                    final pick = await FilePicker.platform.pickFiles(
                      type: clip.type == ClipType.image
                          ? FileType.image
                          : FileType.video,
                    );
                    if (pick == null || pick.files.isEmpty) return;
                    final path = pick.files.single.path;
                    if (path == null) return;
                    final ok = await ref
                        .read(editorProvider(projectId).notifier)
                        .replaceClipMediaFromPath(
                          clipId: clip.id,
                          sourcePath: path,
                        );
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          ok ? 'Medya değiştirildi' : 'Değiştirilemedi',
                        ),
                      ),
                    );
                  },
                ),
              if (clip.type == ClipType.video || clip.type == ClipType.image)
                _ActionChip(
                  icon: Icons.swap_vert,
                  label: clip.flipVertical ? 'Dikey ✓' : 'Dikey çevir',
                  onPressed: () {
                    if (clip.locked) return;
                    ref
                        .read(editorProvider(projectId).notifier)
                        .toggleFlipVertical(clip.id);
                  },
                ),
                _ActionChip(
                  icon: Icons.flip,
                  label: clip.flipHorizontal ? 'Ayna açık' : 'Ayna',
                  onPressed: () {
                    ref.read(editorProvider(projectId).notifier).updateClip(
                          clip.copyWith(
                            flipHorizontal: !clip.flipHorizontal,
                          ),
                        );
                  },
                ),
              if (clip.type == ClipType.video)
                _ActionChip(
                  icon: Icons.grid_on,
                  label: '1sn kes',
                  onPressed: () {
                    ref
                        .read(editorProvider(projectId).notifier)
                        .autoSplitEvery(clip.id, 1000);
                  },
                ),
              _ActionChip(
                icon: Icons.delete_outline,
                label: 'Sil',
                danger: true,
                onPressed: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Klibi sil'),
                      content: Text('"${clip.displayName}" silinsin mi?'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx, false),
                          child: const Text('İptal'),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          child: const Text('Sil'),
                        ),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    await ref
                        .read(editorProvider(projectId).notifier)
                        .deleteClip(clip.id);
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'Böl: playhead seçili klibin içinde olmalı. '
            'Sıralama yalnızca ana video kanalında.',
            style: TextStyle(
              color: AppTheme.textSecondary.withValues(alpha: 0.8),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

class _TrimSliders extends ConsumerWidget {
  final String projectId;
  final ClipModel clip;

  const _TrimSliders({required this.projectId, required this.clip});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final max = clip.sourceDurationMs.toDouble().clamp(1.0, double.infinity).toDouble();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Kesim: ${TimeFormatter.formatMs(clip.trimStartMs)} → ${TimeFormatter.formatMs(clip.trimEndMs)}',
          style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
        ),
        Row(
          children: [
            const SizedBox(
              width: 40,
              child: Text('Baş', style: TextStyle(fontSize: 11)),
            ),
            Expanded(
              child: Slider(
                min: 0,
                max: max,
                value: clip.trimStartMs.toDouble().clamp(0.0, max).toDouble(),
                onChangeStart: (_) {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .beginContinuousEdit('trim_start_${clip.id}');
                },
                onChanged: (v) {
                  final start = v.round();
                  final end = clip.trimEndMs;
                  if (end - start < 100) return;
                  ref.read(editorProvider(projectId).notifier).trimClip(
                        clipId: clip.id,
                        trimStartMs: start,
                        trimEndMs: end,
                        continuous: true,
                      );
                },
                onChangeEnd: (_) {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .endContinuousEdit();
                },
              ),
            ),
          ],
        ),
        Row(
          children: [
            const SizedBox(
              width: 40,
              child: Text('Bit', style: TextStyle(fontSize: 11)),
            ),
            Expanded(
              child: Slider(
                min: 0,
                max: max,
                value: clip.trimEndMs.toDouble().clamp(0.0, max).toDouble(),
                onChangeStart: (_) {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .beginContinuousEdit('trim_end_${clip.id}');
                },
                onChanged: (v) {
                  final end = v.round();
                  final start = clip.trimStartMs;
                  if (end - start < 100) return;
                  ref.read(editorProvider(projectId).notifier).trimClip(
                        clipId: clip.id,
                        trimStartMs: start,
                        trimEndMs: end,
                        continuous: true,
                      );
                },
                onChangeEnd: (_) {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .endContinuousEdit();
                },
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _ActionChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onPressed;
  final bool danger;

  const _ActionChip({
    required this.icon,
    required this.label,
    required this.onPressed,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      avatar: Icon(icon, size: 16, color: danger ? AppTheme.danger : null),
      label: Text(label),
      onPressed: onPressed,
      backgroundColor: AppTheme.surface,
      side: BorderSide(
        color: danger ? AppTheme.danger.withValues(alpha: 0.5) : AppTheme.border,
      ),
    );
  }
}
