
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/aspect_ratio_catalog.dart';
import '../../../domain/models/project_model.dart';
import '../../providers/editor_provider.dart';
import '../../providers/project_list_provider.dart';
import '../../screens/editor/export_screen.dart';

class EditorTopBar extends ConsumerWidget {
  final ProjectModel project;
  final String projectId;

  const EditorTopBar({
    super.key,
    required this.project,
    required this.projectId,
  });

  Future<void> _rename(BuildContext context, WidgetRef ref) async {
    final controller = TextEditingController(text: project.name);
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Proje adı'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 48,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('İptal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );
    if (result == null || result.isEmpty) return;
    await ref.read(editorProvider(projectId).notifier).renameProject(result);
    await ref
        .read(projectListProvider.notifier)
        .renameProject(projectId, result);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(historyUiProvider(projectId));
    final live = ref.watch(editorProvider(projectId)).value ?? project;
    final ratio = AspectRatioCatalog.bySize(live.width, live.height);

    return Container(
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 4),
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(bottom: BorderSide(color: AppTheme.border)),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, size: 18),
            onPressed: () => Navigator.of(context).pop(),
          ),
          Expanded(
            child: InkWell(
              onTap: () => _rename(context, ref),
              borderRadius: BorderRadius.circular(8),
              child: Row(
                children: [
                  Flexible(
                    child: Text(
                      live.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Icon(Icons.edit, size: 14, color: AppTheme.textSecondary),
                ],
              ),
            ),
          ),
          // Ratio pill
          PopupMenuButton<String>(
            tooltip: 'Oran',
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppTheme.surfaceElevated,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.border),
              ),
              child: Text(
                ratio.id,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            onSelected: (id) async {
              final p =
                  AspectRatioCatalog.all.where((x) => x.id == id).firstOrNull;
              if (p != null) {
                await ref
                    .read(editorProvider(projectId).notifier)
                    .setAspectRatio(p);
              }
            },
            itemBuilder: (ctx) => [
              for (final p in AspectRatioCatalog.all)
                PopupMenuItem(
                  value: p.id,
                  child: Text(
                    '${p.label}${live.width == p.width && live.height == p.height ? ' ✓' : ''}',
                  ),
                ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.undo, size: 20),
            onPressed: history.canUndo
                ? () =>
                    ref.read(editorProvider(projectId).notifier).undo()
                : null,
          ),
          IconButton(
            icon: const Icon(Icons.redo, size: 20),
            onPressed: history.canRedo
                ? () =>
                    ref.read(editorProvider(projectId).notifier).redo()
                : null,
          ),
          const SizedBox(width: 4),
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: AppTheme.primaryGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ExportScreen(projectId: projectId),
                      ),
                    );
                  },
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Row(
                      children: [
                        Icon(Icons.ios_share, size: 16, color: Colors.white),
                        SizedBox(width: 6),
                        Text(
                          'Dışa Aktar',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
