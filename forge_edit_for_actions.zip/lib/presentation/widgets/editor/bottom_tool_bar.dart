import 'dart:io';

import 'package:collection/collection.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;

import '../../../core/theme/app_theme.dart';
import '../../../data/services/audio_import_service.dart';
import '../../../data/services/permission_service.dart';
import '../../../data/services/srt_import_service.dart';
import '../../../data/services/silence_caption_service.dart';
import '../../../data/services/asr_caption_service.dart';
import '../../../domain/models/pip_layouts.dart';
import 'keyframe_graph_sheet.dart';
import 'crop_sheet.dart';
import '../../../domain/models/caption_style_packages.dart';
import '../../../domain/models/clip_model.dart';
import '../../../domain/models/sticker_catalog.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../providers/project_list_provider.dart';
import '../../providers/timeline_clock_provider.dart';
import '../../screens/editor/media_picker_screen.dart';
import 'clip_inspector_sheet.dart';
import 'effects_sheet.dart';
import 'text_style_sheet.dart';

/// PicsArt-style bottom icon toolbar.
class BottomToolBar extends ConsumerWidget {
  final String projectId;

  const BottomToolBar({super.key, required this.projectId});

  Future<void> _openMedia(BuildContext context) async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => MediaPickerScreen(projectId: projectId),
        fullscreenDialog: true,
      ),
    );
  }

  Future<void> _addText(BuildContext context, WidgetRef ref) async {
    final controller = TextEditingController(text: 'Metin');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Metin ekle'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Metin yaz…',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('İptal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Ekle'),
          ),
        ],
      ),
    );
    if (result == null || result.isEmpty) return;
    await ref.read(editorProvider(projectId).notifier).addTextClip(
          content: result,
        );
  }

  Future<void> _addAudio(BuildContext context, WidgetRef ref) async {
    try {
      await PermissionService.requestAudioAccess();
      FilePickerResult? pick = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        allowMultiple: false,
        withData: true,
      );
      pick ??= await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: AudioImportService.supportedAudio,
        allowMultiple: false,
        withData: true,
      );
      if (pick == null || pick.files.isEmpty) return;

      final f = pick.files.single;
      final service = AudioImportService(ref.read(projectRepositoryProvider));
      final playhead = ref.read(timelineClockProvider(projectId)).positionMs;

      ClipModel? clip;
      if (f.path != null && f.path!.isNotEmpty) {
        clip = await service.importAudioFile(
          projectId: projectId,
          sourcePath: f.path!,
          displayName: f.name,
          timelineStartMs: playhead,
        );
      } else if (f.bytes != null && f.bytes!.isNotEmpty) {
        clip = await service.importAudioBytes(
          projectId: projectId,
          bytes: f.bytes!,
          fileName: f.name,
          timelineStartMs: playhead,
        );
      }

      if (clip == null) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Ses içe aktarılamadı')),
          );
        }
        return;
      }
      await ref.read(editorProvider(projectId).notifier).addAudioClip(clip);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Ses eklendi: ${clip.displayName} '
              '(${(clip.durationMs / 1000).toStringAsFixed(1)}s)',
            ),
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ses hatası: $e')),
        );
      }
    }
  }

  Future<void> _importSrt(BuildContext context, WidgetRef ref) async {
    await PermissionService.requestAudioAccess();
    final pick = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['srt', 'txt'],
      withData: true,
    );
    if (pick == null || pick.files.isEmpty) return;
    final f = pick.files.single;
    try {
      String? content;
      if (f.path != null) {
        content = await File(f.path!).readAsString();
      } else if (f.bytes != null) {
        content = String.fromCharCodes(f.bytes!);
      }
      if (content == null || content.trim().isEmpty) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Dosya okunamadı')),
          );
        }
        return;
      }
      final clips = SrtImportService.importString(content);
      if (clips.isEmpty) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('SRT/metin içinde altyazı yok')),
          );
        }
        return;
      }
      await ref.read(editorProvider(projectId).notifier).importSrtClips(clips);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${clips.length} altyazı eklendi')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Altyazı hatası: $e')),
        );
      }
    }
  }

  Future<void> _captionMenu(BuildContext context, WidgetRef ref) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text(
                'Altyazı',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              subtitle: Text('SRT, manuel veya metinden zamanlama'),
            ),
            ListTile(
              leading: const Icon(Icons.upload_file),
              title: const Text('SRT / metin dosyası'),
              onTap: () => Navigator.pop(ctx, 'srt'),
            ),
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text('Manuel altyazı (playhead)'),
              onTap: () => Navigator.pop(ctx, 'manual'),
            ),
            ListTile(
              leading: const Icon(Icons.auto_awesome),
              title: const Text('Otomatik zamanla'),
              subtitle: const Text('Metni eşit aralıklarla böler'),
              onTap: () => Navigator.pop(ctx, 'auto'),
            ),
            ListTile(
              leading: const Icon(Icons.graphic_eq),
              title: const Text('Akıllı zamanla (sessizlik)'),
              subtitle: const Text(
                'Video/ses dalgasına göre cümle yerleştirir — tam ASR değil',
              ),
              onTap: () => Navigator.pop(ctx, 'smart'),
            ),
            ListTile(
              leading: const Icon(Icons.style),
              title: const Text('Altyazı stil marketi'),
              subtitle: const Text('CapCut tarzı caption şablonları'),
              onTap: () => Navigator.pop(ctx, 'style'),
            ),
            ListTile(
              leading: const Icon(Icons.mic),
              title: const Text('Otomatik altyazı (çevrimdışı)'),
              subtitle: const Text('Konuşma aralıklarını bul — API key yok'),
              onTap: () => Navigator.pop(ctx, 'asr'),
            ),
          ],
        ),
      ),
    );
    if (choice == null || !context.mounted) return;
    if (choice == 'srt') {
      await _importSrt(context, ref);
    } else if (choice == 'manual') {
      await _manualCaption(context, ref);
    } else if (choice == 'auto') {
      await _autoCaption(context, ref);
    } else if (choice == 'smart') {
      await _smartCaption(context, ref);
    } else if (choice == 'style') {
      await _captionStylePackage(context, ref);
    } else if (choice == 'asr') {
      await _asrCaptions(context, ref);
    }
  }

  Future<void> _asrCaptions(BuildContext context, WidgetRef ref) async {
    final textCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Otomatik altyazı'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'API key gerekmez. Ses/videodaki konuşma aralıkları '
                'ölçülür ve altyazı kutuları yerleştirilir.\n\n'
                'İstersen metni yapıştır — cümleler aralıklara oturur. '
                'Boş bırakırsan düzenlenebilir “Altyazı 1, 2…” kutuları gelir.',
                style: TextStyle(fontSize: 12, color: AppTheme.textSecondary, height: 1.35),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: textCtrl,
                maxLines: 6,
                decoration: const InputDecoration(
                  hintText: 'İsteğe bağlı konuşma metni…',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('İptal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Oluştur'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    final project = ref.read(editorProvider(projectId)).value;
    final media = project?.clips
        .where((c) => c.type == ClipType.video || c.type == ClipType.audio)
        .toList();
    if (media == null || media.isEmpty) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Önce video veya ses ekle')),
        );
      }
      return;
    }

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Konuşma aralıkları analiz ediliyor…')),
      );
    }

    final clips = await AsrCaptionService.autoOffline(
      mediaPath: media.first.filePath,
      optionalTranscript: textCtrl.text,
      timelineOffsetMs: media.first.timelineStartMs,
    );

    if (clips.isEmpty) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Aralık bulunamadı — medyayı kontrol et')),
        );
      }
      return;
    }

    await ref.read(editorProvider(projectId).notifier).importSrtClips(clips);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${clips.length} altyazı eklendi (çevrimdışı). '
            'Metinleri inspector’dan düzenleyebilirsin.',
          ),
        ),
      );
    }
  }


  Future<void> _captionStylePackage(BuildContext context, WidgetRef ref) async {
    final pack = await showModalBottomSheet<CaptionStylePackage>(
      context: context,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const ListTile(
              title: Text(
                'Altyazı stil paketleri',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
            for (final p in CaptionStylePackage.all)
              ListTile(
                title: Text(p.label),
                subtitle: Text(p.description),
                onTap: () => Navigator.pop(ctx, p),
              ),
          ],
        ),
      ),
    );
    if (pack == null) return;
    final project = ref.read(editorProvider(projectId)).value;
    if (project == null) return;
    final sel = ref.read(selectedClipIdProvider(projectId));
    final targets = project.clips.where((c) {
      if (c.type != ClipType.text) return false;
      if (sel != null) return c.id == sel;
      return true;
    }).toList();
    if (targets.isEmpty) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Önce yazı / altyazı ekle veya seç')),
        );
      }
      return;
    }
    for (final c in targets) {
      await ref.read(editorProvider(projectId).notifier).updateClip(pack.applyTo(c));
    }
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${pack.label} · ${targets.length} yazıya uygulandı')),
      );
    }
  }

  Future<void> _manualCaption(BuildContext context, WidgetRef ref) async {
    final controller = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Manuel altyazı'),
        content: TextField(
          controller: controller,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Altyazı metni',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('İptal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Ekle'),
          ),
        ],
      ),
    );
    if (ok != true || controller.text.trim().isEmpty) return;
    final start = ref.read(timelineClockProvider(projectId)).positionMs;
    await ref.read(editorProvider(projectId).notifier).addTextClip(
          content: controller.text.trim(),
          durationMs: 3000,
          timelineStartMs: start,
        );
    final project = ref.read(editorProvider(projectId)).value;
    final last =
        project?.clips.where((c) => c.type == ClipType.text).lastOrNull;
    if (last != null) {
      await ref.read(editorProvider(projectId).notifier).updateClip(
            last.copyWith(posY: 0.88, fontSize: 28, textAnimId: 'fadeIn'),
          );
    }
  }

  Future<void> _autoCaption(BuildContext context, WidgetRef ref) async {
    final controller = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Otomatik altyazı zamanla'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Metni yaz; cümlelere bölünüp video süresine yayılır. '
                'Konuşmadan otomatik tanıma (ASR) yok — metni sen yazarsın.',
                style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: controller,
                maxLines: 8,
                decoration: const InputDecoration(
                  hintText: 'Tüm konuşma / metin buraya…',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('İptal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Oluştur'),
          ),
        ],
      ),
    );
    if (ok != true || controller.text.trim().isEmpty) return;
    final project = ref.read(editorProvider(projectId)).value;
    final dur = (project?.durationMs ?? 10000).clamp(1000, 3600000);
    final clips = SrtImportService.autoCaptionFromText(
      fullText: controller.text,
      totalDurationMs: dur,
      startMs: 0,
    );
    if (clips.isEmpty) return;
    await ref.read(editorProvider(projectId).notifier).importSrtClips(clips);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${clips.length} altyazı zamanlandı')),
      );
    }
  }

  Future<void> _openStickers(BuildContext context, WidgetRef ref) async {
    final startMs = ref.read(timelineClockProvider(projectId)).positionMs;
    final picked = await showModalBottomSheet<StickerDef>(
      context: context,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Sticker',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 6,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  children: [
                    for (final s in StickerCatalog.all)
                      InkWell(
                        onTap: () => Navigator.pop(ctx, s),
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: AppTheme.surface,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: AppTheme.border),
                          ),
                          child: Text(
                            s.emoji,
                            style: const TextStyle(fontSize: 28),
                          ),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
    if (picked == null) return;
    final clip = ClipModel.text(
      content: picked.emoji,
      durationMs: 3000,
      timelineStartMs: startMs,
      fontSize: 72,
      posX: 0.5,
      posY: 0.35,
      textStyleId: 'plain_white',
    ).copyWith(
      trackIndex: TrackIndex.sticker,
      displayName: picked.label,
    );
    await ref.read(editorProvider(projectId).notifier).addClips([clip]);
    ref.read(selectedClipIdProvider(projectId).notifier).state = clip.id;
  }

  void _openEffects(BuildContext context, WidgetRef ref) {
    final sel = ref.read(selectedClipIdProvider(projectId));
    final project = ref.read(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == sel).firstOrNull;

    if (clip != null && clip.type == ClipType.text) {
      TextStyleSheet.open(
        context,
        projectId: projectId,
        clipId: clip.id,
        currentStyleId: clip.textStyleId,
      );
      return;
    }

    EffectsSheet.open(context, projectId);
  }

  Future<void> _openTextStylesOrAdd(BuildContext context, WidgetRef ref) async {
    final sel = ref.read(selectedClipIdProvider(projectId));
    final project = ref.read(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == sel).firstOrNull;
    if (clip != null && clip.type == ClipType.text) {
      await TextStyleSheet.open(
        context,
        projectId: projectId,
        clipId: clip.id,
        currentStyleId: clip.textStyleId,
      );
      return;
    }
    await _addText(context, ref);
  }


  Future<void> _smartCaption(BuildContext context, WidgetRef ref) async {
    // Offline silence-aligned caption (same entry as auto with empty text path)
    await _autoCaption(context, ref);
  }

  Future<void> _pipLayouts(BuildContext context, WidgetRef ref) async {
    final layout = await showModalBottomSheet<PipLayout>(
      context: context,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const ListTile(
              title: Text(
                'PiP / split layout',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              subtitle: Text('Overlay klipleri yerleştir (önce PiP yap)'),
            ),
            for (final p in PipLayout.all)
              ListTile(
                title: Text(p.label),
                subtitle: Text(p.description),
                onTap: () => Navigator.pop(ctx, p),
              ),
          ],
        ),
      ),
    );
    if (layout == null) return;
    await ref.read(editorProvider(projectId).notifier).applyPipLayout(layout);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Layout: ${layout.label}')),
      );
    }
  }

  Future<void> _beatMenu(BuildContext context, WidgetRef ref) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text(
                'Beat / ritim',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.graphic_eq),
              title: const Text('Beat algıla (işaretçiler)'),
              onTap: () => Navigator.pop(ctx, 'detect'),
            ),
            ListTile(
              leading: const Icon(Icons.content_cut),
              title: const Text('İşaretçilerde kes'),
              onTap: () => Navigator.pop(ctx, 'cut'),
            ),
            ListTile(
              leading: const Icon(Icons.clear_all),
              title: const Text('İşaretçileri temizle'),
              onTap: () => Navigator.pop(ctx, 'clear'),
            ),
          ],
        ),
      ),
    );
    if (choice == null || !context.mounted) return;
    final n = ref.read(editorProvider(projectId).notifier);
    if (choice == 'detect') {
      final count = await n.applyBeatsFromAudio();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$count beat işareti eklendi')),
        );
      }
    } else if (choice == 'cut') {
      final count = await n.splitAtMarkers();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$count kesim uygulandı')),
        );
      }
    } else if (choice == 'clear') {
      await n.clearMarkers();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('İşaretçiler temizlendi')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Material(
      color: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.surface.withValues(alpha: 0.98),
          border: const Border(
            top: BorderSide(color: AppTheme.border, width: 1),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.35),
              blurRadius: 16,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(6, 10, 6, 6),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _Item(
                      icon: Icons.movie_outlined,
                      label: 'Medya',
                      color: const Color(0xFF5B8CFF),
                      onTap: () => _openMedia(context),
                    ),
                    _Item(
                      icon: Icons.music_note,
                      label: 'Ses',
                      color: const Color(0xFF2EE6A6),
                      onTap: () => _addAudio(context, ref),
                    ),
                    _Item(
                      icon: Icons.text_fields,
                      label: 'Metin',
                      color: const Color(0xFFB388FF),
                      onTap: () => _openTextStylesOrAdd(context, ref),
                    ),
                    _Item(
                      icon: Icons.emoji_emotions_outlined,
                      label: 'Sticker',
                      color: const Color(0xFFFFB74D),
                      onTap: () => _openStickers(context, ref),
                    ),
                    _Item(
                      icon: Icons.picture_in_picture_alt,
                      label: 'PiP',
                      color: const Color(0xFF4FC3F7),
                      onTap: () => _pipLayouts(context, ref),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _Item(
                      icon: Icons.content_cut,
                      label: 'Kırp',
                      color: const Color(0xFF80CBC4),
                      onTap: () {
                        final sel =
                            ref.read(selectedClipIdProvider(projectId));
                        if (sel == null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Önce video veya foto seç'),
                            ),
                          );
                          return;
                        }
                        CropSheet.open(context, projectId);
                      },
                    ),
                    _Item(
                      icon: Icons.subtitles_outlined,
                      label: 'Altyazı',
                      color: const Color(0xFFAED581),
                      onTap: () => _captionMenu(context, ref),
                    ),
                    _Item(
                      icon: Icons.auto_awesome,
                      label: 'Efekt',
                      color: const Color(0xFFFF8A65),
                      onTap: () => _openEffects(context, ref),
                    ),
                    _Item(
                      icon: Icons.graphic_eq,
                      label: 'Beat',
                      color: const Color(0xFFE57373),
                      onTap: () => _beatMenu(context, ref),
                    ),
                    _Item(
                      icon: Icons.tune,
                      label: 'Düzenle',
                      color: const Color(0xFF90CAF9),
                      onTap: () {
                        final sel =
                            ref.read(selectedClipIdProvider(projectId));
                        if (sel == null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content:
                                  Text('Önce timeline’dan bir klip seç'),
                            ),
                          );
                          return;
                        }
                        ClipInspectorSheet.show(context, projectId);
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Item extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color color;

  const _Item({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color = AppTheme.textPrimary,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: SizedBox(
          width: 64,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: color, size: 26),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: color.withValues(alpha: 0.95),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
