import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/clip_model.dart';
import '../../../domain/models/keyframe.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../providers/timeline_clock_provider.dart';

/// Simple finger-friendly keyframe curve editor (opacity / X / Y).
class KeyframeGraphSheet extends ConsumerStatefulWidget {
  final String projectId;
  final String clipId;

  const KeyframeGraphSheet({
    super.key,
    required this.projectId,
    required this.clipId,
  });

  static Future<void> open(
    BuildContext context, {
    required String projectId,
    required String clipId,
  }) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => KeyframeGraphSheet(
        projectId: projectId,
        clipId: clipId,
      ),
    );
  }

  @override
  ConsumerState<KeyframeGraphSheet> createState() => _KeyframeGraphSheetState();
}

class _KeyframeGraphSheetState extends ConsumerState<KeyframeGraphSheet> {
  /// 0=opacity 1=posX 2=posY
  int _channel = 0;

  ClipModel? get _clip {
    final p = ref.watch(editorProvider(widget.projectId)).value;
    if (p == null) return null;
    for (final c in p.clips) {
      if (c.id == widget.clipId) return c;
    }
    return null;
  }

  Future<void> _addAtPlayhead() async {
    await ref
        .read(editorProvider(widget.projectId).notifier)
        .addKeyframeAtPlayhead(widget.clipId);
  }

  Future<void> _clear() async {
    await ref
        .read(editorProvider(widget.projectId).notifier)
        .clearKeyframes(widget.clipId);
  }

  @override
  Widget build(BuildContext context) {
    final clip = _clip;
    final clock = ref.watch(timelineClockProvider(widget.projectId)).positionMs;
    if (clip == null) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Text('Klip yok'),
      );
    }
    final local = (clock - clip.timelineStartMs).clamp(0, clip.durationMs);
    final keys = [...clip.keyframes]
      ..sort((a, b) => a.offsetMs.compareTo(b.offsetMs));

    return SafeArea(
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * 0.55,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Keyframe grafiği',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
              ),
              const SizedBox(height: 4),
              Text(
                'Playhead: ${local}ms · ${keys.length} nokta — grafiğe dokunarak değer ayarla',
                style: const TextStyle(
                  fontSize: 12,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 12),
              SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('Opacity')),
                  ButtonSegment(value: 1, label: Text('X')),
                  ButtonSegment(value: 2, label: Text('Y')),
                ],
                selected: {_channel},
                onSelectionChanged: (s) => setState(() => _channel = s.first),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: GestureDetector(
                  onTapDown: (d) async {
                    final box = context.findRenderObject() as RenderBox?;
                    // Use local from gesture
                  },
                  onPanUpdate: (d) async {
                    final box =
                        context.findRenderObject() as RenderBox?;
                  },
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      return GestureDetector(
                        onTapDown: (d) => _onGraphTap(
                          d.localPosition,
                          constraints.biggest,
                          clip,
                          local,
                        ),
                        child: CustomPaint(
                          painter: _CurvePainter(
                            keys: keys,
                            channel: _channel,
                            durationMs: clip.durationMs <= 0
                                ? 1
                                : clip.durationMs,
                            playheadMs: local,
                            base: _channel == 0
                                ? clip.opacity
                                : (_channel == 1 ? clip.posX : clip.posY),
                          ),
                          child: const SizedBox.expand(),
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _addAtPlayhead,
                      icon: const Icon(Icons.add),
                      label: const Text('Playhead KF'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _clear,
                      icon: const Icon(Icons.clear_all),
                      label: const Text('Temizle'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _onGraphTap(
    Offset local,
    Size size,
    ClipModel clip,
    int playheadLocal,
  ) async {
    final t = (local.dx / size.width).clamp(0.0, 1.0);
    final v = (1.0 - local.dy / size.height).clamp(0.0, 1.0);
    final offsetMs = (t * clip.durationMs).round();
    final keys = [...clip.keyframes]
      ..removeWhere((k) => (k.offsetMs - offsetMs).abs() < 60);
    keys.add(
      ClipKeyframe(
        offsetMs: offsetMs,
        opacity: _channel == 0 ? v : null,
        posX: _channel == 1 ? v : null,
        posY: _channel == 2 ? v : null,
      ),
    );
    keys.sort((a, b) => a.offsetMs.compareTo(b.offsetMs));
    // Merge with existing channel values on nearby keys
    await ref.read(editorProvider(widget.projectId).notifier).updateClip(
          clip.copyWith(keyframes: keys),
        );
  }
}

class _CurvePainter extends CustomPainter {
  final List<ClipKeyframe> keys;
  final int channel;
  final int durationMs;
  final int playheadMs;
  final double base;

  _CurvePainter({
    required this.keys,
    required this.channel,
    required this.durationMs,
    required this.playheadMs,
    required this.base,
  });

  double? _val(ClipKeyframe k) {
    switch (channel) {
      case 0:
        return k.opacity;
      case 1:
        return k.posX;
      default:
        return k.posY;
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = AppTheme.surfaceElevated;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Offset.zero & size,
        const Radius.circular(12),
      ),
      bg,
    );
    final grid = Paint()
      ..color = AppTheme.border
      ..strokeWidth = 1;
    for (var i = 1; i < 4; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final pts = <Offset>[];
    final withVal = keys.where((k) => _val(k) != null).toList()
      ..sort((a, b) => a.offsetMs.compareTo(b.offsetMs));
    if (withVal.isEmpty) {
      final y = (1 - base) * size.height;
      pts.add(Offset(0, y));
      pts.add(Offset(size.width, y));
    } else {
      for (final k in withVal) {
        final x = (k.offsetMs / durationMs).clamp(0.0, 1.0) * size.width;
        final y = (1 - (_val(k) ?? base)) * size.height;
        pts.add(Offset(x, y));
      }
    }

    final line = Paint()
      ..color = AppTheme.primary
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke;
    if (pts.length >= 2) {
      final path = Path()..moveTo(pts.first.dx, pts.first.dy);
      for (var i = 1; i < pts.length; i++) {
        path.lineTo(pts[i].dx, pts[i].dy);
      }
      canvas.drawPath(path, line);
    }
    final dot = Paint()..color = AppTheme.accent;
    for (final p in pts) {
      canvas.drawCircle(p, 5, dot);
    }

    // playhead
    final px = (playheadMs / durationMs).clamp(0.0, 1.0) * size.width;
    canvas.drawLine(
      Offset(px, 0),
      Offset(px, size.height),
      Paint()
        ..color = AppTheme.playhead
        ..strokeWidth = 1.5,
    );
  }

  @override
  bool shouldRepaint(covariant _CurvePainter old) => true;
}
