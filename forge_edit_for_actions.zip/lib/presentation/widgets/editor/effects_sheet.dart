import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/clip_model.dart';
import '../../../domain/models/effect_models.dart';
import '../../../domain/models/effect_presets.dart';
import '../../providers/editor_provider.dart';
import '../../providers/effect_preview_provider.dart';
import '../../providers/preview_provider.dart';
import 'effect_preview_widgets.dart';
import 'text_style_sheet.dart';

/// Filtre & geçiş: önce önizle, sonra uygula.
class EffectsSheet extends ConsumerWidget {
  final String projectId;

  const EffectsSheet({super.key, required this.projectId});

  static Future<void> open(BuildContext context, String projectId) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => EffectsSheet(projectId: projectId),
    ).whenComplete(() {
      try {
        ProviderScope.containerOf(context)
            .read(effectPreviewProvider(projectId).notifier)
            .state = EffectPreviewState.empty;
      } catch (_) {}
    });
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedId = ref.watch(selectedClipIdProvider(projectId));
    final project = ref.watch(editorProvider(projectId)).value;
    final clip = project?.clips.where((c) => c.id == selectedId).firstOrNull;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        child: clip == null
            ? const Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Filtre / geçiş için video veya foto klip seç.\n'
                  'Yazı stilleri için metin klip seç → Metin veya Efekt.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppTheme.textSecondary, height: 1.4),
                ),
              )
            : clip.type == ClipType.text
                ? Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          'Yazı stilleri (~100 adet)',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () {
                            Navigator.pop(context);
                            TextStyleSheet.open(
                              context,
                              projectId: projectId,
                              clipId: clip.id,
                              currentStyleId: clip.textStyleId,
                            );
                          },
                          icon: const Icon(Icons.text_fields),
                          label: const Text('Stilleri aç'),
                        ),
                      ],
                    ),
                  )
                : _EffectsBody(projectId: projectId, clip: clip),
      ),
    );
  }
}

class _EffectsBody extends ConsumerStatefulWidget {
  final String projectId;
  final ClipModel clip;

  const _EffectsBody({required this.projectId, required this.clip});

  @override
  ConsumerState<_EffectsBody> createState() => _EffectsBodyState();
}

class _EffectsBodyState extends ConsumerState<_EffectsBody> {
  String? _previewFilterId;
  double _previewIntensity = 1.0;
  String? _previewTransitionId;
  int _transitionReplay = 0;

  String get projectId => widget.projectId;
  ClipModel get clip {
    final live = ref.watch(editorProvider(projectId)).value;
    return live?.clips.where((c) => c.id == widget.clip.id).firstOrNull ??
        widget.clip;
  }

  void _pushFilterPreview(String id, double intensity) {
    setState(() {
      _previewFilterId = id;
      _previewIntensity = intensity;
      _previewTransitionId = null;
    });
    ref.read(effectPreviewProvider(projectId).notifier).state =
        EffectPreviewState(
      filterId: id,
      filterIntensity: intensity,
    );
  }

  void _pushTransitionPreview(String id) {
    setState(() {
      _previewTransitionId = id;
      _previewFilterId = null;
      _transitionReplay++;
    });
    ref.read(effectPreviewProvider(projectId).notifier).state =
        EffectPreviewState(
      transitionId: id,
      playingTransition: true,
    );
  }

  void _clearTempPreview() {
    ref.read(effectPreviewProvider(projectId).notifier).state =
        EffectPreviewState.empty;
  }

  @override
  void dispose() {
    // Provider may be disposed with widget; try clear via container if needed
    super.dispose();
  }

  Future<void> _applyFilter(String id, {bool all = false}) async {
    // Ensure visible strength (users often leave slider low)
    final inten = id == 'none'
        ? 1.0
        : _previewIntensity.clamp(0.55, 1.0);
    setState(() => _previewIntensity = inten);
    if (all) {
      await ref.read(editorProvider(projectId).notifier).applyFilterToAllVideos(
            id,
            inten,
          );
    } else {
      await ref.read(editorProvider(projectId).notifier).updateClip(
            clip.copyWith(
              filterId: id,
              filterIntensity: inten,
            ),
          );
    }
    // Keep live preview override in sync so video shows filter immediately
    ref.read(effectPreviewProvider(projectId).notifier).state =
        EffectPreviewState(filterId: id, filterIntensity: inten);
    _clearTempPreview();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            id == 'none'
                ? 'Filtre kaldırıldı'
                : 'Filtre uygulandı: ${EffectCatalog.filterByName(id).label}',
          ),
          duration: const Duration(milliseconds: 1200),
        ),
      );
    }
  }

  Future<void> _applyTransition(String id) async {
    await ref.read(editorProvider(projectId).notifier).updateClip(
          clip.copyWith(
            transitionId: id,
            transitionDurationMs:
                clip.transitionDurationMs.clamp(100, 2000),
          ),
        );
    _clearTempPreview();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            id == 'none'
                ? 'Geçiş kaldırıldı'
                : 'Geçiş uygulandı: ${EffectCatalog.transitionByName(id).label}',
          ),
          duration: const Duration(milliseconds: 1200),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isVideo =
        clip.type == ClipType.video || clip.type == ClipType.image;
    final h = MediaQuery.sizeOf(context).height * 0.85;

    return SizedBox(
      height: h,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: AppTheme.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Text(
            'Filtre & Geçiş — ${clip.displayName}',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 4),
          const Text(
            'Önce «Önizle», beğenirsen «Uygula». Önizleme projeye yazılmaz.',
            style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 12),
          // Live demo stage
          Container(
            height: 120,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.border),
            ),
            clipBehavior: Clip.antiAlias,
            child: _previewTransitionId != null
                ? Center(
                    child: TransitionDemo(
                      key: ValueKey('tr_$_previewTransitionId$_transitionReplay'),
                      style: EffectCatalog.transitionByName(
                            _previewTransitionId!,
                          ).previewStyle,
                      size: 100,
                      autoPlay: true,
                    ),
                  )
                : Center(
                    child: FilterSwatch(
                      filterId: _previewFilterId ?? clip.filterId,
                      intensity: _previewFilterId != null
                          ? _previewIntensity
                          : clip.filterIntensity,
                      size: 100,
                      selected: true,
                    ),
                  ),
          ),
          if (_previewFilterId != null || _previewTransitionId != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      _previewTransitionId != null
                          ? 'Geçiş önizleme: ${EffectCatalog.transitionByName(_previewTransitionId!).label}'
                          : 'Filtre önizleme: ${EffectCatalog.filterByName(_previewFilterId!).label}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppTheme.primary,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      setState(() {
                        _previewFilterId = null;
                        _previewTransitionId = null;
                      });
                      _clearTempPreview();
                    },
                    child: const Text('Temizle'),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView(
              children: [
                const Text('Hazır paketler',
                    style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                const Text(
                  'Tek dokunuş: filtre + geçiş + yazı stili',
                  style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 88,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: EffectPreset.all.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, i) {
                      final pack = EffectPreset.all[i];
                      return Material(
                        color: AppTheme.surfaceElevated,
                        borderRadius: BorderRadius.circular(14),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () async {
                            await ref
                                .read(editorProvider(projectId).notifier)
                                .applyEffectPreset(pack);
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Paket: ${pack.label}'),
                                  duration: const Duration(milliseconds: 1200),
                                ),
                              );
                            }
                          },
                          child: Container(
                            width: 120,
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: AppTheme.border),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  pack.label,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13,
                                  ),
                                ),
                                const Spacer(),
                                Text(
                                  pack.description,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 10,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const Divider(height: 28),
                if (isVideo) ...[
                  const Text('Filtreler',
                      style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: EffectCatalog.filters.length,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: 0.72,
                    ),
                    itemBuilder: (context, i) {
                      final f = EffectCatalog.filters[i];
                      final selected = clip.filterId == f.id.name;
                      final previewing = _previewFilterId == f.id.name;
                      return _FilterTile(
                        label: f.label,
                        filterId: f.id.name,
                        selected: selected,
                        previewing: previewing,
                        intensity: previewing
                            ? _previewIntensity
                            : (selected ? clip.filterIntensity : 1.0),
                        onPreview: () =>
                            _pushFilterPreview(f.id.name, _previewIntensity),
                        onApply: () => _applyFilter(f.id.name),
                        onApplyAll: () => _applyFilter(f.id.name, all: true),
                      );
                    },
                  ),
                  if ((_previewFilterId ?? clip.filterId) != 'none') ...[
                    const SizedBox(height: 8),
                    Text(
                      'Yoğunluk: ${((_previewFilterId != null ? _previewIntensity : clip.filterIntensity) * 100).round()}%',
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    Slider(
                      value: (_previewFilterId != null
                              ? _previewIntensity
                              : clip.filterIntensity)
                          .clamp(0.0, 1.0),
                      onChanged: (v) {
                        setState(() => _previewIntensity = v);
                        if (_previewFilterId != null) {
                          _pushFilterPreview(_previewFilterId!, v);
                        }
                      },
                    ),
                  ],
                  const Divider(height: 28),
                ],
                const Text('Videolar arası geçiş',
                    style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                const Text(
                  'Bu klibin bitişinde sonraki klibe uygulanır. Önizle → Uygula.',
                  style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 8),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: EffectCatalog.transitions.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: 0.68,
                  ),
                  itemBuilder: (context, i) {
                    final tr = EffectCatalog.transitions[i];
                    final selected = clip.transitionId == tr.id.name;
                    final previewing = _previewTransitionId == tr.id.name;
                    return _TransitionTile(
                      def: tr,
                      selected: selected,
                      previewing: previewing,
                      onPreview: () => _pushTransitionPreview(tr.id.name),
                      onApply: () => _applyTransition(tr.id.name),
                    );
                  },
                ),
                if (clip.transitionId != 'none' ||
                    _previewTransitionId != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Süre: ${clip.transitionDurationMs} ms',
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                  Slider(
                    min: 100,
                    max: 2000,
                    divisions: 19,
                    value:
                        clip.transitionDurationMs.toDouble().clamp(100, 2000),
                    onChangeStart: (_) {
                      ref
                          .read(editorProvider(projectId).notifier)
                          .beginContinuousEdit('trdur_${clip.id}');
                    },
                    onChanged: (v) {
                      ref.read(editorProvider(projectId).notifier).updateClip(
                            clip.copyWith(transitionDurationMs: v.round()),
                            continuous: true,
                          );
                    },
                    onChangeEnd: (_) {
                      ref
                          .read(editorProvider(projectId).notifier)
                          .endContinuousEdit();
                    },
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterTile extends StatelessWidget {
  final String label;
  final String filterId;
  final bool selected;
  final bool previewing;
  final double intensity;
  final VoidCallback onPreview;
  final VoidCallback onApply;
  final VoidCallback? onApplyAll;

  const _FilterTile({
    required this.label,
    required this.filterId,
    required this.selected,
    required this.previewing,
    required this.intensity,
    required this.onPreview,
    required this.onApply,
    this.onApplyAll,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: previewing
            ? AppTheme.primary.withValues(alpha: 0.12)
            : AppTheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: selected
              ? AppTheme.primary
              : previewing
                  ? AppTheme.accent
                  : AppTheme.border,
          width: selected || previewing ? 2 : 1,
        ),
      ),
      padding: const EdgeInsets.all(6),
      child: Column(
        children: [
          Expanded(
            child: FilterSwatch(
              filterId: filterId,
              intensity: intensity,
              size: 48,
              selected: selected,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 28,
                  child: TextButton(
                    onPressed: onPreview,
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                      foregroundColor: AppTheme.primary,
                    ),
                    child: const Text('Önizle', style: TextStyle(fontSize: 11)),
                  ),
                ),
              ),
              Expanded(
                child: SizedBox(
                  height: 28,
                  child: TextButton(
                    onPressed: onApply,
                    onLongPress: onApplyAll,
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                      foregroundColor: AppTheme.accent,
                    ),
                    child: const Text('Uygula', style: TextStyle(fontSize: 11)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _TransitionTile extends StatelessWidget {
  final TransitionDef def;
  final bool selected;
  final bool previewing;
  final VoidCallback onPreview;
  final VoidCallback onApply;

  const _TransitionTile({
    required this.def,
    required this.selected,
    required this.previewing,
    required this.onPreview,
    required this.onApply,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: previewing
            ? AppTheme.primary.withValues(alpha: 0.12)
            : AppTheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: selected
              ? AppTheme.primary
              : previewing
                  ? AppTheme.accent
                  : AppTheme.border,
          width: selected || previewing ? 2 : 1,
        ),
      ),
      padding: const EdgeInsets.all(6),
      child: Column(
        children: [
          Expanded(
            child: previewing
                ? TransitionDemo(
                    style: def.previewStyle,
                    size: 52,
                    autoPlay: true,
                  )
                : Icon(
                    transitionIcon(def.id.name),
                    size: 28,
                    color: selected ? AppTheme.primary : AppTheme.textSecondary,
                  ),
          ),
          Text(
            def.label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
          ),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 28,
                  child: TextButton(
                    onPressed: onPreview,
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                      foregroundColor: AppTheme.primary,
                    ),
                    child: const Text('Önizle', style: TextStyle(fontSize: 11)),
                  ),
                ),
              ),
              Expanded(
                child: SizedBox(
                  height: 28,
                  child: TextButton(
                    onPressed: onApply,
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                      foregroundColor: AppTheme.accent,
                    ),
                    child: const Text('Uygula', style: TextStyle(fontSize: 11)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
