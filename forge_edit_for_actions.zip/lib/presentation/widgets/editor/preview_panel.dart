import 'dart:io';

import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:video_player/video_player.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/time_formatter.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../providers/timeline_clock_provider.dart';
import '../../providers/effect_preview_provider.dart';
import '../../../domain/models/clip_model.dart';
import '../../../domain/models/keyframe.dart';
import '../../../domain/timeline_ops.dart';
import '../../../domain/models/text_style_catalog.dart';
import '../../../domain/models/text_anim_catalog.dart';
import 'filter_matrix.dart';
import 'transition_overlay.dart';

/// Real video preview using video_player.
///
/// Stage 3 capabilities:
/// - Plays the selected clip from its copied file path
/// - Play / pause
/// - Position + duration text
/// - Loading and error states
/// - Proper controller dispose via provider
///
/// Continuous multi-clip play + timeline clock scrub are wired via providers.
class PreviewPanel extends ConsumerWidget {
  final String projectId;

  const PreviewPanel({super.key, required this.projectId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final editorState = ref.watch(editorProvider(projectId));
    final previewAsync = ref.watch(previewProvider(projectId));
    final hasClips = editorState.value?.clips.isNotEmpty ?? false;

    return Container(
      color: Colors.black,
      child: Column(
        children: [
          Expanded(
            child: !hasClips
                ? const _EmptyPreview()
                : previewAsync.when(
                    loading: () => const Center(
                      child: CircularProgressIndicator(color: AppTheme.primary),
                    ),
                    error: (e, _) => _ErrorPreview(message: e.toString()),
                    data: (preview) {
                      if (preview.error != null) {
                        return _ErrorPreview(message: preview.error!);
                      }
                      if (preview.isImage) {
                        final project = editorState.value;
                        final clip = project?.clips
                            .where((c) => c.id == preview.clipId)
                            .firstOrNull;
                        if (clip == null) {
                          return const Center(
                            child: Text(
                              'Görsel seçilmedi',
                              style: TextStyle(color: AppTheme.textSecondary),
                            ),
                          );
                        }
                        return Stack(
                          fit: StackFit.expand,
                          children: [
                            Center(
                              child: Opacity(
                                opacity: clip.opacity.clamp(0.0, 1.0),
                                child: Transform.flip(
                                  flipX: clip.flipHorizontal,
                                  child: Image.file(
                                  File(clip.filePath),
                                  fit: BoxFit.contain,
                                  errorBuilder: (_, __, ___) => _ErrorPreview(
                                    message:
                                        'Görsel yüklenemedi\n${clip.displayName}',
                                  ),
                                  ),
                                ),
                              ),
                            ),
                            _TextOverlays(projectId: projectId),
                          ],
                        );
                      }
                      if (!preview.hasVideo) {
                        // Text-only / no media under playhead: still show overlays
                        return Stack(
                          fit: StackFit.expand,
                          children: [
                            const ColoredBox(color: Colors.black),
                            const Center(
                              child: Text(
                                'Video yok — metni sürükle / pinch ile boyutla',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: AppTheme.textSecondary,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                            _TextOverlays(projectId: projectId),
                          ],
                        );
                      }
                      final project = editorState.value;
                      final sel = preview.clipId;
                      final clip = project?.clips
                          .where((c) => c.id == sel)
                          .firstOrNull;
                      final ar = (project?.width ?? 16) /
                          ((project?.height ?? 9) == 0
                              ? 9
                              : (project?.height ?? 9));
                      return Center(
                        child: AspectRatio(
                          aspectRatio: ar,
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: AppTheme.primary.withValues(alpha: 0.55),
                                width: 1.5,
                              ),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Stack(
                        fit: StackFit.expand,
                        children: [
                          if (preview.hasTransitionLayer &&
                              preview.outgoingController != null)
                            TransitionOverlay(
                              outgoing: preview.outgoingController!,
                              incoming: preview.controller!,
                              progress: preview.transitionOpacity,
                              kind: preview.transitionKind ?? 'crossfade',
                            )
                          else
                            Opacity(
                              opacity: _edgeFadeOpacity(
                                clip: clip,
                                timelineMs: ref
                                    .watch(timelineClockProvider(projectId))
                                    .positionMs,
                              ),
                              child: Builder(
                                builder: (context) {
                                  final ov = ref.watch(
                                    effectPreviewProvider(projectId),
                                  );
                                  final fid = ov.filterId ??
                                      clip?.filterId ??
                                      'none';
                                  final inten = ov.filterId != null
                                      ? ov.filterIntensity
                                      : (clip?.filterIntensity ?? 1.0);
                                  final media = Transform.flip(
                                    flipX: clip?.flipHorizontal ?? false,
                                    flipY: clip?.flipVertical ?? false,
                                    child: _VideoSurface(
                                      controller: preview.controller!,
                                      fitMode: clip?.fitMode ?? 'contain',
                                    ),
                                  );
                                  return FilteredPreview(
                                    filterId: fid,
                                    intensity: inten,
                                    forTexture: true,
                                    child: clip != null
                                        ? _CroppedMedia(clip: clip, child: media)
                                        : media,
                                  );
                                },
                              ),
                            ),
                          _TextOverlays(projectId: projectId),
                        ],
                      ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
          // Transport controls
          if (hasClips) _TransportBar(projectId: projectId),
        ],
      ),
    );
  }
}

class _TextOverlays extends ConsumerWidget {
  final String projectId;

  const _TextOverlays({required this.projectId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final project = ref.watch(editorProvider(projectId)).value;
    final timelineMs =
        ref.watch(timelineClockProvider(projectId)).positionMs;
    final selectedId = ref.watch(selectedClipIdProvider(projectId));

    final overlays = (project?.clips ?? const <ClipModel>[])
        .where((clip) =>
            clip.type == ClipType.text &&
            timelineMs >= clip.timelineStartMs &&
            timelineMs < clip.timelineEndMs)
        .toList();

    // Always show selected text even if playhead is slightly outside
    if (selectedId != null && project != null) {
      final sel = project.clips.where((c) => c.id == selectedId).firstOrNull;
      if (sel != null &&
          sel.type == ClipType.text &&
          !overlays.any((c) => c.id == sel.id)) {
        overlays.add(sel);
      }
    }

    if (overlays.isEmpty) {
      return const SizedBox.shrink();
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final w = constraints.maxWidth;
        final h = constraints.maxHeight;
        return Stack(
          children: overlays.map((clip) {
            final selected = clip.id == selectedId;
            final localMs =
                (timelineMs - clip.timelineStartMs).clamp(0, clip.durationMs);
            final kfX = KeyframeEval.posXAt(clip.keyframes, localMs, clip.posX);
            final kfY = KeyframeEval.posYAt(clip.keyframes, localMs, clip.posY);
            final kfOp =
                KeyframeEval.opacityAt(clip.keyframes, localMs, clip.opacity);
            final x = (kfX * 2 - 1).clamp(-1.0, 1.0).toDouble();
            final y = (kfY * 2 - 1).clamp(-1.0, 1.0).toDouble();

            final alignment = clip.textAlign == 0
                ? TextAlign.left
                : clip.textAlign == 2
                    ? TextAlign.right
                    : TextAlign.center;

            final styleDef = TextStyleCatalog.byId(clip.textStyleId);

            return Positioned.fill(
              child: Align(
                alignment: Alignment(x, y),
                child: Opacity(
                  opacity: kfOp.clamp(0.0, 1.0),
                  child: _DraggableText(
                    projectId: projectId,
                    clip: clip,
                    selected: selected,
                    width: w,
                    height: h,
                    alignment: alignment,
                    styleDef: styleDef,
                  ),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

class _DraggableText extends ConsumerStatefulWidget {
  final String projectId;
  final ClipModel clip;
  final bool selected;
  final double width;
  final double height;
  final TextAlign alignment;
  final TextStyleDef styleDef;

  const _DraggableText({
    required this.projectId,
    required this.clip,
    required this.selected,
    required this.width,
    required this.height,
    required this.alignment,
    required this.styleDef,
  });

  @override
  ConsumerState<_DraggableText> createState() => _DraggableTextState();
}

class _DraggableTextState extends ConsumerState<_DraggableText> {
  double _baseFont = 32;
  double _posX = 0.5;
  double _posY = 0.5;

  @override
  Widget build(BuildContext context) {
    final clip = widget.clip;
    final selected = widget.selected;
    final projectId = widget.projectId;
    final w = widget.width;
    final h = widget.height;
    final timelineMs =
        ref.watch(timelineClockProvider(projectId)).positionMs;
    final localMs =
        (timelineMs - clip.timelineStartMs).clamp(0, clip.durationMs);
    final anim = _TextAnimEval.evaluate(
      animId: clip.textAnimId,
      localMs: localMs,
      durationMs: clip.durationMs <= 0 ? 1 : clip.durationMs,
      rawText: TextStyleResolver.displayText(clip.textContent, widget.styleDef),
    );

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        ref.read(selectedClipIdProvider(projectId).notifier).state = clip.id;
      },
      onScaleStart: (_) {
        ref.read(selectedClipIdProvider(projectId).notifier).state = clip.id;
        final live = ref.read(editorProvider(projectId)).value;
        final c =
            live?.clips.where((x) => x.id == clip.id).firstOrNull ?? clip;
        _baseFont = c.fontSize;
        _posX = c.posX;
        _posY = c.posY;
        ref
            .read(editorProvider(projectId).notifier)
            .beginContinuousEdit('textxf_${clip.id}');
      },
      onScaleUpdate: (d) {
        if (w > 0 && h > 0) {
          _posX = (_posX + d.focalPointDelta.dx / w).clamp(0.0, 1.0);
          _posY = (_posY + d.focalPointDelta.dy / h).clamp(0.0, 1.0);
        }
        final font = d.pointerCount >= 2
            ? (_baseFont * d.scale).clamp(12.0, 160.0)
            : null;
        ref.read(editorProvider(projectId).notifier).updateTextClip(
              clipId: clip.id,
              posX: _posX,
              posY: _posY,
              fontSize: font,
              continuous: true,
            );
      },
      onScaleEnd: (_) {
        ref.read(editorProvider(projectId).notifier).endContinuousEdit();
      },
      child: Opacity(
        opacity: anim.opacity,
        child: Transform.translate(
          offset: Offset(anim.dx, anim.dy),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: selected
                        ? AppTheme.primary
                        : Colors.transparent,
                    width: selected ? 2 : 0,
                  ),
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.black.withValues(alpha: 0.55),
                ),
                child: Text(
                  anim.text,
                  textAlign: widget.alignment,
                  style: TextStyleResolver.resolve(
                    def: widget.styleDef,
                    fontSize: clip.fontSize.clamp(8.0, 200.0).toDouble(),
                    colorArgb: clip.textColorArgb,
                  ).copyWith(
                    shadows: [
                      if (clip.textStrokeWidth > 0.5 || clip.textGlow > 0.05)
                        Shadow(
                          color: Colors.black.withValues(
                            alpha: 0.85 + clip.textGlow.clamp(0, 1) * 0.15,
                          ),
                          blurRadius: 2 + clip.textStrokeWidth + clip.textGlow * 8,
                          offset: Offset.zero,
                        ),
                      if (clip.textStrokeWidth > 0.5)
                        Shadow(
                          color: Colors.black,
                          blurRadius: 0,
                          offset: Offset(clip.textStrokeWidth * 0.4, 0),
                        ),
                      if (clip.textStrokeWidth > 0.5)
                        Shadow(
                          color: Colors.black,
                          blurRadius: 0,
                          offset: Offset(-clip.textStrokeWidth * 0.4, 0),
                        ),
                    ],
                  ),
                ),
              ),
              if (selected)
                Positioned(
                  right: -6,
                  bottom: -6,
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                      color: AppTheme.primary,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 1.5),
                    ),
                    child: const Icon(
                      Icons.open_with,
                      size: 11,
                      color: Colors.white,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TextAnimEval {
  final double opacity;
  final double dx;
  final double dy;
  final double scale;
  final double rotation; // radians
  final String text;

  const _TextAnimEval({
    required this.opacity,
    required this.dx,
    required this.dy,
    required this.text,
    this.scale = 1.0,
    this.rotation = 0.0,
  });

  static double _easeOutBack(double t) {
    const c = 1.70158;
    final x = t - 1;
    return 1 + (c + 1) * x * x * x + c * x * x;
  }

  static _TextAnimEval evaluate({
    required String animId,
    required int localMs,
    required int durationMs,
    required String rawText,
  }) {
    const intro = 420.0;
    const outro = 400.0;
    final tIn = (localMs / intro).clamp(0.0, 1.0);
    final tOut = durationMs > outro
        ? ((durationMs - localMs) / outro).clamp(0.0, 1.0)
        : 1.0;
    final mid = durationMs > 0
        ? (localMs / durationMs).clamp(0.0, 1.0)
        : 0.0;
    switch (animId) {
      case 'fadeIn':
        return _TextAnimEval(opacity: tIn, dx: 0, dy: 0, text: rawText);
      case 'fadeOut':
        return _TextAnimEval(opacity: tOut, dx: 0, dy: 0, text: rawText);
      case 'fadeInOut':
        return _TextAnimEval(
          opacity: tIn < 1 ? tIn : tOut,
          dx: 0,
          dy: 0,
          text: rawText,
        );
      case 'slideUp':
        return _TextAnimEval(
          opacity: tIn,
          dx: 0,
          dy: (1 - tIn) * 48,
          text: rawText,
        );
      case 'slideDown':
        return _TextAnimEval(
          opacity: tIn,
          dx: 0,
          dy: -(1 - tIn) * 48,
          text: rawText,
        );
      case 'slideLeft':
        return _TextAnimEval(
          opacity: tIn,
          dx: (1 - tIn) * 64,
          dy: 0,
          text: rawText,
        );
      case 'slideRight':
        return _TextAnimEval(
          opacity: tIn,
          dx: -(1 - tIn) * 64,
          dy: 0,
          text: rawText,
        );
      case 'typewriter':
        final n = rawText.isEmpty
            ? 0
            : ((rawText.length) * mid).floor().clamp(0, rawText.length);
        return _TextAnimEval(
          opacity: 1,
          dx: 0,
          dy: 0,
          text: rawText.substring(0, n),
        );
      case 'pop':
        final s = 0.4 + 0.6 * _easeOutBack(tIn);
        return _TextAnimEval(
          opacity: tIn,
          dx: 0,
          dy: 0,
          scale: s,
          text: rawText,
        );
      case 'bounce':
        final bounce = tIn < 1
            ? (1 - tIn) * 40 * (1 - (tIn * 2 - 1).abs())
            : 0.0;
        return _TextAnimEval(
          opacity: tIn,
          dx: 0,
          dy: bounce,
          scale: 0.85 + 0.15 * tIn,
          text: rawText,
        );
      case 'zoomIn':
        return _TextAnimEval(
          opacity: tIn,
          dx: 0,
          dy: 0,
          scale: 0.5 + 0.5 * tIn,
          text: rawText,
        );
      case 'zoomOut':
        return _TextAnimEval(
          opacity: tOut,
          dx: 0,
          dy: 0,
          scale: 1.0 + (1 - tOut) * 0.4,
          text: rawText,
        );
      case 'shake':
        final sh = tIn < 1
            ? (1 - tIn) * 8 * ((localMs ~/ 40) % 2 == 0 ? 1 : -1)
            : 0.0;
        return _TextAnimEval(
          opacity: tIn.clamp(0.3, 1.0),
          dx: sh.toDouble(),
          dy: 0,
          text: rawText,
        );
      case 'pulse':
        final pulse = 1.0 + 0.08 * (1 + (mid * 6.28).sinApprox);
        return _TextAnimEval(
          opacity: 1,
          dx: 0,
          dy: 0,
          scale: pulse,
          text: rawText,
        );
      case 'spin':
        return _TextAnimEval(
          opacity: tIn,
          dx: 0,
          dy: 0,
          scale: 0.7 + 0.3 * tIn,
          rotation: (1 - tIn) * 0.6,
          text: rawText,
        );
      case 'rise':
        return _TextAnimEval(
          opacity: tIn,
          dx: 0,
          dy: (1 - tIn) * 56,
          scale: 0.9 + 0.1 * tIn,
          text: rawText,
        );
      case 'drop':
        return _TextAnimEval(
          opacity: tIn,
          dx: 0,
          dy: -(1 - tIn) * 72,
          scale: 1.1 - 0.1 * tIn,
          text: rawText,
        );
      case 'blurIn':
        return _TextAnimEval(
          opacity: tIn,
          dx: 0,
          dy: 0,
          scale: 1.15 - 0.15 * tIn,
          text: rawText,
        );
      case 'glitch':
        final g = tIn < 1
            ? ((localMs ~/ 30) % 3 - 1) * (1 - tIn) * 10.0
            : 0.0;
        return _TextAnimEval(
          opacity: tIn.clamp(0.4, 1.0),
          dx: g,
          dy: -g * 0.3,
          text: rawText,
        );
      case 'wave':
        final w = 6.0 * (mid * 12.56).sinApprox;
        return _TextAnimEval(
          opacity: 1,
          dx: w,
          dy: 0,
          text: rawText,
        );
      default:
        return _TextAnimEval(opacity: 1, dx: 0, dy: 0, text: rawText);
    }
  }
}

extension on double {
  double get sinApprox {
    // Cheap sin for UI (radians)
    var x = this % 6.283185307179586;
    if (x > 3.141592653589793) x -= 6.283185307179586;
    return x - (x * x * x) / 6;
  }
}

class _VideoSurface extends StatelessWidget {
  final VideoPlayerController controller;
  final String fitMode;

  const _VideoSurface({
    required this.controller,
    this.fitMode = 'contain',
  });

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const Center(
        child: CircularProgressIndicator(color: AppTheme.primary),
      );
    }

    final video = SizedBox(
      width: size.width,
      height: size.height,
      child: VideoPlayer(controller),
    );

    return LayoutBuilder(
      builder: (context, constraints) {
        final boxW = constraints.maxWidth;
        final boxH = constraints.maxHeight;
        if (boxW <= 0 || boxH <= 0) {
          return Center(child: AspectRatio(
            aspectRatio: controller.value.aspectRatio,
            child: VideoPlayer(controller),
          ));
        }
        final fit = fitMode == 'cover' ? BoxFit.cover : BoxFit.contain;
        return ClipRect(
          child: FittedBox(
            fit: fit,
            alignment: Alignment.center,
            child: video,
          ),
        );
      },
    );
  }
}

class _TransportBar extends ConsumerWidget {
  final String projectId;

  const _TransportBar({required this.projectId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final previewAsync = ref.watch(previewProvider(projectId));
    final preview = previewAsync.value;
    final clock = ref.watch(timelineClockProvider(projectId));
    final editor = ref.watch(editorProvider(projectId)).value;
    final hasVisual = editor?.clips.any(
          (c) => c.type == ClipType.video || c.type == ClipType.image,
        ) ??
        false;
    final isPlaying = clock.isPlaying;
    final isReady = hasVisual;
    // Prefer project clock for continuous play; fall back to controller times.
    final position = isPlaying || (preview?.hasVideo ?? false)
        ? Duration(milliseconds: clock.positionMs)
        : (preview?.position ?? Duration.zero);
    final duration = editor != null && editor.durationMs > 0
        ? Duration(milliseconds: editor.durationMs)
        : (preview?.duration ?? Duration.zero);

    return Container(
      height: 48,
      color: AppTheme.surface,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          IconButton(
            icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow),
            color: AppTheme.textPrimary,
            onPressed: isReady
                ? () => ref.read(previewProvider(projectId).notifier).togglePlay()
                : null,
          ),
          IconButton(
            icon: Icon(
              clock.loopEnabled ? Icons.repeat_on : Icons.repeat,
              size: 22,
            ),
            color: clock.loopEnabled ? AppTheme.primary : AppTheme.textSecondary,
            tooltip: clock.loopEnabled ? 'Döngü açık' : 'Döngü kapalı',
            onPressed: () =>
                ref.read(timelineClockProvider(projectId).notifier).toggleLoop(),
          ),
          Text(
            TimeFormatter.formatMs(position.inMilliseconds),
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 12,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
          Expanded(
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                trackHeight: 2,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 12),
                activeTrackColor: AppTheme.primary,
                inactiveTrackColor: AppTheme.border,
                thumbColor: AppTheme.primary,
              ),
              child: Slider(
                value: duration.inMilliseconds == 0
                    ? 0
                    : (position.inMilliseconds / duration.inMilliseconds)
                        .clamp(0.0, 1.0),
                onChanged: isReady
                    ? (v) {
                        var ms = (v * duration.inMilliseconds).round();
                        final proj = ref.read(editorProvider(projectId)).value;
                        if (proj != null) {
                          ms = TimelineOps.snapMs(
                            ms,
                            proj.clips,
                            markersMs: proj.markersMs,
                          );
                        }
                        ref
                            .read(previewProvider(projectId).notifier)
                            .scrubToProjectMs(ms);
                      }
                    : null,
              ),
            ),
          ),
          Text(
            TimeFormatter.formatMs(duration.inMilliseconds),
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 12,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
    );
  }
}

class _EmptyPreview extends StatelessWidget {
  const _EmptyPreview();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.movie_creation_outlined,
              size: 48,
              color: AppTheme.textSecondary.withValues(alpha: 0.7),
            ),
            const SizedBox(height: 12),
            const Text(
              'Projen boş',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 16,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Alttan Medya ile video/foto ekle\n'
              'Ses, Metin ve Efekt de oradan',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 13,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class _ErrorPreview extends StatelessWidget {
  final String message;

  const _ErrorPreview({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48, color: AppTheme.danger),
            const SizedBox(height: 12),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}


double _edgeFadeOpacity({ClipModel? clip, required int timelineMs}) {
  if (clip == null) return 1.0;
  var o = clip.opacity.clamp(0.0, 1.0);
  final local = timelineMs - clip.timelineStartMs;
  final dur = clip.durationMs <= 0 ? 1 : clip.durationMs;
  if (clip.fadeInMs > 0 && local < clip.fadeInMs) {
    o *= (local / clip.fadeInMs).clamp(0.0, 1.0);
  }
  if (clip.fadeOutMs > 0 && local > dur - clip.fadeOutMs) {
    o *= ((dur - local) / clip.fadeOutMs).clamp(0.0, 1.0);
  }
  return o.clamp(0.0, 1.0);
}


class _CroppedMedia extends StatelessWidget {
  final ClipModel clip;
  final Widget child;

  const _CroppedMedia({required this.clip, required this.child});

  @override
  Widget build(BuildContext context) {
    if (!clip.hasCrop) return child;
    return LayoutBuilder(
      builder: (context, constraints) {
        final w = constraints.maxWidth;
        final h = constraints.maxHeight;
        if (w <= 0 || h <= 0) return child;
        final l = clip.cropLeft.clamp(0.0, 0.45);
        final tp = clip.cropTop.clamp(0.0, 0.45);
        final r = clip.cropRight.clamp(0.0, 0.45);
        final b = clip.cropBottom.clamp(0.0, 0.45);
        final keepW = 1.0 - l - r;
        final keepH = 1.0 - tp - b;
        if (keepW <= 0.05 || keepH <= 0.05) return child;
        // Scale content so cropped region fills view
        final scaleX = 1.0 / keepW;
        final scaleY = 1.0 / keepH;
        final scale = scaleX > scaleY ? scaleX : scaleY;
        final dx = (l - r) * w * scale * 0.5;
        final dy = (tp - b) * h * scale * 0.5;
        return ClipRect(
          child: Transform.translate(
            offset: Offset(-l * w * scale + (scale - 1) * w * 0.5 - dx * 0.0,
                -tp * h * scale + (scale - 1) * h * 0.5),
            child: Transform.scale(
              scale: scale,
              alignment: Alignment(
                -1 + 2 * (l + keepW / 2),
                -1 + 2 * (tp + keepH / 2),
              ),
              child: child,
            ),
          ),
        );
      },
    );
  }
}
