import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/clip_model.dart';
import '../../../domain/models/project_templates.dart';
import '../../providers/editor_provider.dart';
import '../editor/editor_screen.dart';
import '../editor/media_picker_screen.dart';

/// CapCut-style step wizard: fill each template media slot.
class TemplateSlotWizardScreen extends ConsumerStatefulWidget {
  final String projectId;
  final ProjectTemplate template;

  const TemplateSlotWizardScreen({
    super.key,
    required this.projectId,
    required this.template,
  });

  @override
  ConsumerState<TemplateSlotWizardScreen> createState() =>
      _TemplateSlotWizardScreenState();
}

class _TemplateSlotWizardScreenState
    extends ConsumerState<TemplateSlotWizardScreen> {
  int _step = 0;
  final Map<int, String> _filled = {}; // slot index → clip id

  List<TemplateMediaSlot> get _slots {
    final t = widget.template;
    if (t.slots.isNotEmpty) return t.slots;
    // Synthetic slots from mediaSlots count
    final n = t.mediaSlots.clamp(1, 8);
    final each = (t.durationMs / n).floor().clamp(500, 60000);
    return [
      for (var i = 0; i < n; i++)
        TemplateMediaSlot(
          label: 'Medya ${i + 1}',
          startMs: i * each,
          durationMs: each,
        ),
    ];
  }

  Future<void> _pickForSlot(int index) async {
    final slot = _slots[index];
    final before = ref.read(editorProvider(widget.projectId)).value;
    final beforeIds =
        before?.clips.map((c) => c.id).toSet() ?? <String>{};

    final added = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => MediaPickerScreen(projectId: widget.projectId),
        fullscreenDialog: true,
      ),
    );
    if (!mounted) return;
    // Editor state already updated by media picker commit (no full reload).
    final project = ref.read(editorProvider(widget.projectId)).value;
    if (project == null) return;

    final newVisuals = project.clips
        .where((c) =>
            (c.type == ClipType.video || c.type == ClipType.image) &&
            !beforeIds.contains(c.id))
        .toList();
    final ClipModel? target = newVisuals.isNotEmpty
        ? newVisuals.last
        : () {
            final list = project.clips
                .where((c) =>
                    c.type == ClipType.video || c.type == ClipType.image)
                .toList();
            return list.isEmpty ? null : list.last;
          }();
    if (target == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Medya seçilmedi')),
        );
      }
      return;
    }

    final maxSrc =
        target.sourceDurationMs > 0 ? target.sourceDurationMs : slot.durationMs;
    final dur = slot.durationMs.clamp(100, maxSrc);
    final updated = target.copyWith(
      timelineStartMs: slot.startMs,
      trimStartMs: 0,
      trimEndMs: dur,
      trackIndex: TrackIndex.video,
      displayName: slot.label,
    );
    await ref.read(editorProvider(widget.projectId).notifier).updateClip(updated);

    final guides = project.clips
        .where((c) =>
            c.trackIndex == TrackIndex.sticker &&
            (c.displayName == slot.label ||
                c.textContent.contains(slot.label)))
        .map((c) => c.id)
        .toList();
    for (final id in guides) {
      await ref.read(editorProvider(widget.projectId).notifier).deleteClip(id);
    }

    setState(() => _filled[index] = target.id);
  }

  void _finish() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => EditorScreen(projectId: widget.projectId),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final slots = _slots;
    final slot = slots[_step.clamp(0, slots.length - 1)];
    final done = _filled.length >= slots.length;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: Text('Şablon: ${widget.template.title}'),
        backgroundColor: AppTheme.surface,
        actions: [
          TextButton(
            onPressed: _finish,
            child: const Text('Atla'),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Adım ${_step + 1} / ${slots.length}',
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: (_step + 1) / slots.length,
              color: AppTheme.primary,
              backgroundColor: AppTheme.border,
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppTheme.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppTheme.border),
              ),
              child: Column(
                children: [
                  Icon(
                    Icons.movie_creation_outlined,
                    size: 48,
                    color: widget.template.accent,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    slot.label,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Başlangıç ${(slot.startMs / 1000).toStringAsFixed(1)}s · '
                    'Süre ${(slot.durationMs / 1000).toStringAsFixed(1)}s',
                    style: const TextStyle(color: AppTheme.textSecondary),
                  ),
                  const SizedBox(height: 16),
                  if (_filled.containsKey(_step))
                    const Chip(
                      avatar: Icon(Icons.check, size: 16, color: Colors.green),
                      label: Text('Dolduruldu'),
                    ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: () => _pickForSlot(_step),
                    icon: const Icon(Icons.add_photo_alternate_outlined),
                    label: Text(
                      _filled.containsKey(_step)
                          ? 'Medyayı değiştir'
                          : 'Galeri / video seç',
                    ),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(48),
                    ),
                  ),
                ],
              ),
            ),
            const Spacer(),
            Row(
              children: [
                if (_step > 0)
                  OutlinedButton(
                    onPressed: () => setState(() => _step--),
                    child: const Text('Geri'),
                  ),
                const Spacer(),
                if (_step < slots.length - 1)
                  ElevatedButton(
                    onPressed: () => setState(() => _step++),
                    child: const Text('İleri'),
                  )
                else
                  ElevatedButton.icon(
                    onPressed: _finish,
                    icon: const Icon(Icons.check),
                    label: Text(done ? 'Editöre geç' : 'Editöre geç'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
