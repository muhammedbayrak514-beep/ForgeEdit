import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/project_model.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../widgets/editor/bottom_tool_bar.dart';
import '../../widgets/editor/clip_inspector_sheet.dart';
import '../../widgets/editor/editor_top_bar.dart';
import '../../widgets/editor/preview_panel.dart';
import '../../widgets/editor/timeline_panel.dart';
import '../../widgets/editor/editor_onboarding_overlay.dart';
import '../../../core/prefs/app_prefs.dart';

/// Editor layout:
/// Preview (large) → optional "Klip düzenle" chip → timeline → bottom tools.
/// Clip inspector opens as a bottom sheet (does not crush the preview).
class EditorScreen extends ConsumerStatefulWidget {
  final String projectId;

  const EditorScreen({super.key, required this.projectId});

  @override
  ConsumerState<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends ConsumerState<EditorScreen> {
  bool _showOnboarding = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      ref.read(editorProvider(widget.projectId).notifier).load();
      final done = await AppPrefs.isEditorOnboardingDone();
      if (!done && mounted) setState(() => _showOnboarding = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    final editorState = ref.watch(editorProvider(widget.projectId));

    return Stack(
      children: [
        Scaffold(
          backgroundColor: AppTheme.background,
          body: SafeArea(
            child: editorState.when(
              loading: () => const Center(
                child: CircularProgressIndicator(color: AppTheme.primary),
              ),
              error: (e, _) => _ErrorView(
                message: e.toString(),
                onBack: () => Navigator.of(context).pop(),
              ),
              data: (project) => _EditorBody(
                project: project,
                projectId: widget.projectId,
              ),
            ),
          ),
        ),
        if (_showOnboarding)
          EditorOnboardingOverlay(
            onDismissed: () => setState(() => _showOnboarding = false),
          ),
      ],
    );
  }
}

class _EditorBody extends ConsumerWidget {
  final ProjectModel project;
  final String projectId;

  const _EditorBody({required this.project, required this.projectId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedId = ref.watch(selectedClipIdProvider(projectId));
    final hasSelection = selectedId != null;

    final size = MediaQuery.sizeOf(context);
    final narrow = size.width < 600;
    final timelineH = narrow
        ? (size.height * 0.28).clamp(160.0, 200.0)
        : 220.0;

    return Column(
      children: [
        EditorTopBar(project: project, projectId: projectId),
        Expanded(child: PreviewPanel(projectId: projectId)),
        if (hasSelection)
          Material(
            color: AppTheme.surface,
            child: InkWell(
              onTap: () => ClipInspectorSheet.show(context, projectId),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: Row(
                  children: [
                    const Icon(Icons.tune, size: 18, color: AppTheme.primary),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        narrow
                            ? 'Klip düzenle'
                            : 'Klip düzenle — kes, sıra, opaklık…',
                        style: const TextStyle(fontSize: 13),
                      ),
                    ),
                    TextButton(
                      onPressed: () =>
                          ClipInspectorSheet.show(context, projectId),
                      child: const Text('Aç'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        SizedBox(
          height: timelineH,
          child: TimelinePanel(projectId: projectId),
        ),
        BottomToolBar(projectId: projectId),
      ],
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onBack;

  const _ErrorView({required this.message, required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: onBack, child: const Text('Geri')),
          ],
        ),
      ),
    );
  }
}
