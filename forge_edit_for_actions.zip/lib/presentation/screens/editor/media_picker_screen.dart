import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/services/media_import_service.dart';
import '../../../data/services/permission_service.dart';
import '../../providers/editor_provider.dart';
import '../../providers/project_list_provider.dart';

/// Media type filter for the picker grid.
enum _MediaFilter { all, image, video }

/// Full-screen media picker with infinite scroll and image/video tabs.
///
/// Selection and import are separate steps:
/// 1. User selects one or more assets (checkmarks)
/// 2. User taps "Ekle" → import runs → result shown → pop on success
class MediaPickerScreen extends ConsumerStatefulWidget {
  final String projectId;

  const MediaPickerScreen({super.key, required this.projectId});

  @override
  ConsumerState<MediaPickerScreen> createState() => _MediaPickerScreenState();
}

class _MediaPickerScreenState extends ConsumerState<MediaPickerScreen> {
  static const int _pageSize = 80;

  PermissionState? _permissionState;
  List<AssetPathEntity> _albums = [];
  AssetPathEntity? _currentAlbum;
  List<AssetEntity> _assets = [];
  final Set<AssetEntity> _selected = {};

  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = true;
  int _page = 0;
  int _albumAssetCount = 0;

  bool _importing = false;
  String? _error;
  String _statusMessage = '';
  _MediaFilter _filter = _MediaFilter.all;

  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    _init();
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_hasMore || _loadingMore || _loading) return;
    if (!_scrollController.hasClients) return;
    final pos = _scrollController.position;
    if (pos.pixels >= pos.maxScrollExtent - 480) {
      _loadMore();
    }
  }

  RequestType get _requestType {
    switch (_filter) {
      case _MediaFilter.all:
        return RequestType.common;
      case _MediaFilter.image:
        return RequestType.image;
      case _MediaFilter.video:
        return RequestType.video;
    }
  }

  FilterOptionGroup get _filterOption {
    return FilterOptionGroup(
      imageOption: const FilterOption(
        sizeConstraint: SizeConstraint(ignoreSize: true),
        needTitle: true,
      ),
      videoOption: const FilterOption(
        durationConstraint: DurationConstraint(
          min: Duration.zero,
          max: Duration(hours: 24),
        ),
        sizeConstraint: SizeConstraint(ignoreSize: true),
        needTitle: true,
      ),
      orders: [
        const OrderOption(type: OrderOptionType.createDate, asc: false),
      ],
    );
  }

  Future<void> _init() async {
    setState(() {
      _loading = true;
      _error = null;
      _assets = [];
      _page = 0;
      _hasMore = true;
      _selected.clear();
    });

    // Ensure legacy storage on older Android, then photo_manager permission.
    await PermissionService.ensureLegacyStorageIfNeeded();
    final state = await PermissionService.requestPhotoAccess();
    if (!mounted) return;

    setState(() => _permissionState = state);

    if (!PermissionService.canAccessMedia(state)) {
      setState(() {
        _loading = false;
        _error = state == PermissionState.denied
            ? 'Medya erişim izni reddedildi. Ayarlardan Fotoğraf ve Video iznini aç.'
            : 'Medya erişimi yok. Video için ayrıca Video izni gerekir.';
      });
      return;
    }

    try {
      await _reloadAlbumsAndAssets();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Medya listesi yüklenemedi: $e';
      });
    }
  }

  Future<void> _reloadAlbumsAndAssets() async {
    setState(() {
      _loading = true;
      _error = null;
      _assets = [];
      _page = 0;
      _hasMore = true;
    });

    final paths = await PhotoManager.getAssetPathList(
      type: _requestType,
      onlyAll: false,
      filterOption: _filterOption,
    );
    if (!mounted) return;

    if (paths.isEmpty) {
      setState(() {
        _loading = false;
        _albums = [];
        _currentAlbum = null;
        _assets = [];
        _albumAssetCount = 0;
        _hasMore = false;
      });
      return;
    }

    // Prefer the "All" album; fall back to first.
    AssetPathEntity album;
    try {
      album = paths.firstWhere((p) => p.isAll);
    } catch (_) {
      album = paths.first;
    }

    // Keep selection of current album if still present after filter change.
    if (_currentAlbum != null) {
      final match = paths.where((p) => p.id == _currentAlbum!.id);
      if (match.isNotEmpty) {
        album = match.first;
      }
    }

    final count = await album.assetCountAsync;
    final page = await album.getAssetListPaged(page: 0, size: _pageSize);

    if (!mounted) return;
    setState(() {
      _albums = paths;
      _currentAlbum = album;
      _assets = page;
      _albumAssetCount = count;
      _page = 0;
      _hasMore = page.length >= _pageSize && _assets.length < count;
      _loading = false;
    });
  }

  Future<void> _loadMore() async {
    if (_loadingMore || !_hasMore || _currentAlbum == null) return;
    setState(() => _loadingMore = true);

    try {
      final nextPage = _page + 1;
      final page = await _currentAlbum!.getAssetListPaged(
        page: nextPage,
        size: _pageSize,
      );
      if (!mounted) return;

      if (page.isEmpty) {
        setState(() {
          _hasMore = false;
          _loadingMore = false;
        });
        return;
      }

      // Deduplicate by id (some OEMs overlap pages).
      final existingIds = _assets.map((a) => a.id).toSet();
      final fresh = page.where((a) => !existingIds.contains(a.id)).toList();

      setState(() {
        _assets = [..._assets, ...fresh];
        _page = nextPage;
        _hasMore = page.length >= _pageSize && _assets.length < _albumAssetCount;
        _loadingMore = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loadingMore = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Daha fazla yüklenemedi: $e'),
          backgroundColor: AppTheme.danger,
        ),
      );
    }
  }

  Future<void> _switchAlbum(AssetPathEntity album) async {
    if (_currentAlbum?.id == album.id) return;
    setState(() {
      _currentAlbum = album;
      _loading = true;
      _assets = [];
      _page = 0;
      _hasMore = true;
      _selected.clear();
    });

    try {
      final count = await album.assetCountAsync;
      final page = await album.getAssetListPaged(page: 0, size: _pageSize);
      if (!mounted) return;
      setState(() {
        _assets = page;
        _albumAssetCount = count;
        _page = 0;
        _hasMore = page.length >= _pageSize && page.length < count;
        _loading = false;
      });
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(0);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Albüm yüklenemedi: $e';
      });
    }
  }

  Future<void> _setFilter(_MediaFilter filter) async {
    if (_filter == filter) return;
    setState(() {
      _filter = filter;
      _selected.clear();
    });
    await _reloadAlbumsAndAssets();
  }

  void _toggleSelection(AssetEntity asset) {
    setState(() {
      if (_selected.contains(asset)) {
        _selected.remove(asset);
      } else {
        _selected.add(asset);
      }
    });
  }

  Future<void> _onAddPressed() async {
    if (_selected.isEmpty || _importing) return;

    setState(() {
      _importing = true;
      _statusMessage = 'Dosyalar doğrulanıyor...';
    });

    try {
      final editorNotifier =
          ref.read(editorProvider(widget.projectId).notifier);
      final currentProject =
          ref.read(editorProvider(widget.projectId)).value;
      final timelineStart = currentProject?.durationMs ?? 0;

      final importService = MediaImportService(
        ref.read(projectRepositoryProvider),
      );

      setState(() => _statusMessage = 'İçe aktarılıyor...');

      final result = await importService.importAssets(
        projectId: widget.projectId,
        assets: _selected.toList(),
        timelineStartMs: timelineStart,
      );

      if (!mounted) return;

      if (result.added.isNotEmpty) {
        await editorNotifier.addClips(result.added);
      }

      if (!mounted) return;

      if (result.isFullSuccess) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${result.added.length} medya eklendi'),
            backgroundColor: AppTheme.accent.withValues(alpha: 0.9),
          ),
        );
        Navigator.of(context).pop(true);
      } else if (result.hasPartialSuccess) {
        final failNames =
            result.failures.map((f) => f.originalName).join(', ');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '${result.added.length} eklendi, ${result.failures.length} başarısız: $failNames',
            ),
            duration: const Duration(seconds: 5),
          ),
        );
        Navigator.of(context).pop(true);
      } else {
        final msg = result.failures.isNotEmpty
            ? result.failures.first.errorMessage ?? 'İçe aktarma başarısız'
            : 'Hiçbir dosya eklenemedi';
        setState(() {
          _importing = false;
          _statusMessage = '';
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(msg),
              backgroundColor: AppTheme.danger,
            ),
          );
        }
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _importing = false;
        _statusMessage = '';
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Beklenmeyen hata: $e'),
          backgroundColor: AppTheme.danger,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Medya Seç'),
        actions: [
          if (_albumAssetCount > 0)
            Padding(
              padding: const EdgeInsets.only(right: 4),
              child: Center(
                child: Text(
                  '$_albumAssetCount öğe',
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          if (_selected.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Center(
                child: Text(
                  '${_selected.length} seçili',
                  style: const TextStyle(
                    color: AppTheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          _buildFilterChips(),
          if (_albums.length > 1) _buildAlbumBar(),
          Expanded(child: _buildBody()),
        ],
      ),
      bottomNavigationBar: _buildBottomBar(),
    );
  }

  Widget _buildFilterChips() {
    Widget chip(String label, _MediaFilter value, IconData icon) {
      final selected = _filter == value;
      return FilterChip(
        avatar: Icon(icon, size: 16, color: selected ? AppTheme.primary : AppTheme.textSecondary),
        label: Text(label),
        selected: selected,
        onSelected: _importing ? null : (_) => _setFilter(value),
        selectedColor: AppTheme.primary.withValues(alpha: 0.3),
        labelStyle: TextStyle(
          color: selected ? AppTheme.textPrimary : AppTheme.textSecondary,
          fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
          fontSize: 13,
        ),
        backgroundColor: AppTheme.surfaceElevated,
        side: BorderSide(color: selected ? AppTheme.primary : AppTheme.border),
        showCheckmark: false,
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: Row(
        children: [
          chip('Tümü', _MediaFilter.all, Icons.perm_media_outlined),
          const SizedBox(width: 8),
          chip('Fotoğraf', _MediaFilter.image, Icons.image_outlined),
          const SizedBox(width: 8),
          chip('Video', _MediaFilter.video, Icons.videocam_outlined),
        ],
      ),
    );
  }

  Widget _buildAlbumBar() {
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: _albums.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final album = _albums[i];
          final selected = _currentAlbum?.id == album.id;
          return ChoiceChip(
            label: Text(
              album.isAll ? 'Tüm medya' : album.name,
              overflow: TextOverflow.ellipsis,
            ),
            selected: selected,
            onSelected: _importing || _loading
                ? null
                : (_) => _switchAlbum(album),
            selectedColor: AppTheme.primary.withValues(alpha: 0.3),
            labelStyle: TextStyle(
              color: selected ? AppTheme.textPrimary : AppTheme.textSecondary,
              fontSize: 12,
            ),
            backgroundColor: AppTheme.surfaceElevated,
            side: BorderSide(
              color: selected ? AppTheme.primary : AppTheme.border,
            ),
          );
        },
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: AppTheme.primary),
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock_outline, size: 48, color: AppTheme.danger),
              const SizedBox(height: 16),
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppTheme.textPrimary),
              ),
              const SizedBox(height: 24),
              if (_permissionState == PermissionState.denied ||
                  _permissionState == PermissionState.restricted ||
                  _permissionState == PermissionState.limited)
                ElevatedButton(
                  onPressed: () => PermissionService.openSettings(),
                  child: const Text('Ayarları Aç'),
                ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: _init,
                child: const Text('Tekrar Dene'),
              ),
            ],
          ),
        ),
      );
    }

    if (_assets.isEmpty) {
      final hint = _filter == _MediaFilter.video
          ? 'Video bulunamadı.\nAyarlar → Uygulamalar → ForgeEdit → İzinler →\nFotoğraflar ve videolar izninin açık olduğundan emin ol.'
          : 'Bu albümde medya yok';
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            hint,
            textAlign: TextAlign.center,
            style: const TextStyle(color: AppTheme.textSecondary),
          ),
        ),
      );
    }

    final itemCount = _assets.length + (_hasMore ? 1 : 0);

    return Column(
      children: [
        if (_importing)
          const LinearProgressIndicator(
            backgroundColor: AppTheme.surface,
            color: AppTheme.primary,
          ),
        if (_statusMessage.isNotEmpty)
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              _statusMessage,
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 13,
              ),
            ),
          ),
        Expanded(
          child: GridView.builder(
            controller: _scrollController,
            padding: const EdgeInsets.all(8),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              mainAxisSpacing: 6,
              crossAxisSpacing: 6,
              childAspectRatio: 1,
            ),
            itemCount: itemCount,
            itemBuilder: (context, index) {
              if (index >= _assets.length) {
                return const Center(
                  child: SizedBox(
                    width: 28,
                    height: 28,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppTheme.primary,
                    ),
                  ),
                );
              }
              final asset = _assets[index];
              final isSelected = _selected.contains(asset);
              return _AssetThumb(
                asset: asset,
                isSelected: isSelected,
                onTap: _importing ? null : () => _toggleSelection(asset),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildBottomBar() {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        decoration: BoxDecoration(
          color: AppTheme.surface.withValues(alpha: 0.98),
          border: const Border(top: BorderSide(color: AppTheme.border)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.35),
              blurRadius: 16,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                _selected.isEmpty
                    ? (_hasMore
                        ? '${_assets.length} / $_albumAssetCount yüklü'
                        : '${_assets.length} medya')
                    : '${_selected.length} seçili',
                style: TextStyle(
                  color: _selected.isEmpty
                      ? AppTheme.textSecondary
                      : AppTheme.primary,
                  fontSize: 13,
                  fontWeight:
                      _selected.isEmpty ? FontWeight.w500 : FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(width: 12),
            FilledButton.icon(
              onPressed:
                  _selected.isEmpty || _importing ? null : _onAddPressed,
              icon: _importing
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.add_rounded, size: 20),
              label: Text(_importing ? 'Ekleniyor…' : 'Ekle'),
              style: FilledButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AssetThumb extends StatelessWidget {
  final AssetEntity asset;
  final bool isSelected;
  final VoidCallback? onTap;

  const _AssetThumb({
    required this.asset,
    required this.isSelected,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        fit: StackFit.expand,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: AssetEntityImage(
              asset,
              isOriginal: false,
              thumbnailSize: const ThumbnailSize.square(200),
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: AppTheme.surfaceElevated,
                child: Icon(
                  asset.type == AssetType.video
                      ? Icons.videocam_off
                      : Icons.broken_image,
                  color: AppTheme.textSecondary,
                ),
              ),
            ),
          ),
          if (asset.type == AssetType.video)
            Positioned(
              left: 4,
              bottom: 4,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.play_arrow, size: 12, color: Colors.white),
                    const SizedBox(width: 2),
                    Text(
                      _formatDuration(asset.duration),
                      style: const TextStyle(color: Colors.white, fontSize: 10),
                    ),
                  ],
                ),
              ),
            ),
          if (isSelected)
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.primary, width: 3),
                color: AppTheme.primary.withValues(alpha: 0.25),
              ),
            ),
          Positioned(
            top: 4,
            right: 4,
            child: Icon(
              isSelected ? Icons.check_circle : Icons.circle_outlined,
              color: isSelected ? AppTheme.primary : Colors.white70,
              size: 22,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDuration(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }
}
