import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/services/export_service.dart';
import '../../../data/services/gallery_save_service.dart';
import '../../../domain/export/export_plan.dart';
import '../../../domain/export/export_error_messages.dart';
import '../../providers/editor_provider.dart';
import '../../widgets/common/ui_kit.dart';

class ExportScreen extends ConsumerStatefulWidget {
  final String projectId;

  const ExportScreen({super.key, required this.projectId});

  @override
  ConsumerState<ExportScreen> createState() => _ExportScreenState();
}

class _ExportScreenState extends ConsumerState<ExportScreen> {
  final _service = ExportService();
  ExportSettings _settings = const ExportSettings();
  ExportProgress? _progress;
  bool _running = false;
  bool _syncedFromProject = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_syncedFromProject) return;
    final project = ref.read(editorProvider(widget.projectId)).value;
    if (project != null) {
      _settings = ExportSettings(
        width: project.width,
        height: project.height,
        fps: project.frameRate,
        quality: 'balanced',
        muteOriginalAudio: _settings.muteOriginalAudio,
      );
      _syncedFromProject = true;
    }
  }

  Future<void> _start() async {
    if (_service.isBusy || _running) return;
    final project = ref.read(editorProvider(widget.projectId)).value;
    if (project == null) return;

    setState(() {
      _running = true;
      _progress = const ExportProgress(
        phase: ExportPhase.validating,
        message: 'Başlatılıyor…',
      );
    });

    final result = await _service.export(
      project: project,
      settings: _settings,
      onProgress: (p) {
        if (mounted) setState(() => _progress = p);
      },
    );

    if (!mounted) return;

    // FFmpeg writes only to app-private storage. Push into the system gallery
    // so the user sees the MP4 in Gallery / Google Photos / Files.
    ExportProgress finalProgress = result;
    if (result.phase == ExportPhase.done &&
        result.outputPath != null &&
        result.outputPath!.isNotEmpty) {
      setState(() {
        _progress = ExportProgress(
          phase: ExportPhase.done,
          message: 'Galeriye kaydediliyor…',
          fraction: 1,
          outputPath: result.outputPath,
          warnings: result.warnings,
        );
      });

      final save = await GallerySaveService.saveVideoToGallery(
        filePath: result.outputPath!,
        title: project.name,
      );

      if (!mounted) return;

      if (save.success) {
        final warnings = List<String>.from(result.warnings);
        finalProgress = ExportProgress(
          phase: ExportPhase.done,
          message: 'Galeriye kaydedildi',
          fraction: 1,
          outputPath: save.galleryPath ?? result.outputPath,
          warnings: warnings,
        );
      } else {
        final warnings = List<String>.from(result.warnings)
          ..add(
            save.error ??
                'Galeriye kopyalanamadı. Dosya uygulama klasöründe duruyor.',
          );
        finalProgress = ExportProgress(
          phase: ExportPhase.done,
          message: 'Export bitti (galeri kaydı başarısız)',
          fraction: 1,
          outputPath: result.outputPath,
          warnings: warnings,
        );
      }
    }

    if (mounted) {
      if (finalProgress.phase == ExportPhase.failed) {
        finalProgress = ExportProgress(
          phase: ExportPhase.failed,
          message: ExportErrorMessages.humanize(
            finalProgress.error ?? finalProgress.message,
          ),
          fraction: finalProgress.fraction,
          error: finalProgress.error,
          warnings: finalProgress.warnings,
        );
      }
      setState(() {
        _progress = finalProgress;
        _running = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final project = ref.watch(editorProvider(widget.projectId)).value;
    final p = _progress;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Dışa Aktar'),
        actions: [
          if (_running)
            TextButton(
              onPressed: () => _service.requestCancel(),
              child: const Text('İptal'),
            ),
        ],
      ),
      body: project == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
              children: [
                FeSectionCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        project.name,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.w800,
                              letterSpacing: -0.3,
                            ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'FFmpeg · libx264 · MP4 · galeriye kaydedilir',
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                FeSectionCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const FeSectionTitle('Çözünürlük'),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final res in [
                            (854, 480, '480p'),
                            (1280, 720, '720p'),
                            (1920, 1080, '1080p'),
                            (3840, 2160, '4K'),
                          ])
                            FeChip(
                              label: '${res.$3}',
                              selected: _settings.width == res.$1 &&
                                  _settings.height == res.$2,
                              onTap: _running
                                  ? null
                                  : () => setState(() {
                                        _settings = _settings.copyWith(
                                          width: res.$1,
                                          height: res.$2,
                                        );
                                      }),
                            ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      const FeSectionTitle('Sosyal preset'),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final preset in [
                            (1080, 1920, 'TikTok / Reels', '9:16'),
                            (1080, 1080, 'Instagram', '1:1'),
                            (1920, 1080, 'YouTube', '16:9'),
                            (1080, 1350, 'IG Portrait', '4:5'),
                          ])
                            FeChip(
                              label: '${preset.$3}',
                              icon: Icons.phone_android,
                              selected: _settings.width == preset.$1 &&
                                  _settings.height == preset.$2,
                              onTap: _running
                                  ? null
                                  : () => setState(() {
                                        _settings = _settings.copyWith(
                                          width: preset.$1,
                                          height: preset.$2,
                                        );
                                      }),
                            ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      const FeSectionTitle('Kalite'),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        children: [
                          for (final q in [
                            ('fast', 'Hızlı'),
                            ('balanced', 'Dengeli'),
                            ('high', 'Yüksek'),
                          ])
                            FeChip(
                              label: q.$2,
                              selected: _settings.quality == q.$1,
                              onTap: _running
                                  ? null
                                  : () => setState(() {
                                        _settings =
                                            _settings.copyWith(quality: q.$1);
                                      }),
                            ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      const FeSectionTitle('FPS'),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        children: [
                          for (final fps in [24, 30])
                            FeChip(
                              label: '$fps fps',
                              selected: _settings.fps == fps,
                              onTap: _running
                                  ? null
                                  : () => setState(() {
                                        _settings =
                                            _settings.copyWith(fps: fps);
                                      }),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                FeSectionCard(
                  child: Column(
                    children: [
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        title: const Text(
                          'Orijinal video sesini kapat',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        subtitle: const Text('Sadece eklenen müzik / ses kalsın'),
                        value: _settings.muteOriginalAudio,
                        onChanged: _running
                            ? null
                            : (v) => setState(
                                  () => _settings = _settings.copyWith(
                                    muteOriginalAudio: v,
                                  ),
                                ),
                      ),
                      const Divider(height: 20),
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        title: const Text(
                          'Sadece işaret aralığı (In/Out)',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        subtitle: Text(
                          _settings.rangeStartMs != null
                              ? 'In ${_settings.rangeStartMs}ms → Out ${_settings.rangeEndMs}ms'
                              : 'Kapalı — tüm timeline',
                        ),
                        value: _settings.rangeStartMs != null,
                        onChanged: _running
                            ? null
                            : (v) {
                                final project = ref
                                    .read(editorProvider(widget.projectId))
                                    .value;
                                final markers =
                                    project?.markersMs ?? const <int>[];
                                if (!v) {
                                  setState(() => _settings =
                                      _settings.copyWith(clearRange: true));
                                  return;
                                }
                                if (markers.length >= 2) {
                                  final sorted = [...markers]..sort();
                                  setState(() {
                                    _settings = _settings.copyWith(
                                      rangeStartMs: sorted.first,
                                      rangeEndMs: sorted.last,
                                    );
                                  });
                                } else {
                                  final dur = project?.durationMs ?? 0;
                                  setState(() {
                                    _settings = _settings.copyWith(
                                      rangeStartMs: 0,
                                      rangeEndMs: dur > 0 ? dur : 3000,
                                    );
                                  });
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        'İpucu: Timeline’da 2 işaret koy (In/Out)',
                                      ),
                                    ),
                                  );
                                }
                              },
                      ),
                    ],
                  ),
                ),
                if (p != null) ...[
                  const SizedBox(height: 16),
                  FeSectionCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          p.message,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        if (p.fraction != null) ...[
                          const SizedBox(height: 12),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: LinearProgressIndicator(
                              value: p.fraction,
                              minHeight: 8,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            '${(p.fraction! * 100).toStringAsFixed(0)}%',
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 12,
                            ),
                          ),
                        ] else if (_running)
                          const Padding(
                            padding: EdgeInsets.only(top: 12),
                            child: LinearProgressIndicator(minHeight: 8),
                          ),
                        if (p.outputPath != null) ...[
                          const SizedBox(height: 12),
                          SelectableText(
                            'Dosya: ${p.outputPath}',
                            style: const TextStyle(
                              color: AppTheme.accent,
                              fontSize: 12,
                            ),
                          ),
                        ],
                        if (p.error != null) ...[
                          const SizedBox(height: 8),
                          Text(
                            ExportErrorMessages.humanize(p.error),
                            style: const TextStyle(color: AppTheme.danger),
                          ),
                        ],
                        if (p.warnings.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          ...p.warnings.map(
                            (w) => Text(
                              w,
                              style: const TextStyle(
                                color: AppTheme.warning,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 20),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Donanım hızlandırma'),
                  subtitle: const Text('MediaCodec (Android) — hızlı export'),
                  value: _settings.useHardwareEncode,
                  onChanged: _running
                      ? null
                      : (v) => setState(() {
                            _settings =
                                _settings.copyWith(useHardwareEncode: v);
                          }),
                ),
                const SizedBox(height: 8),
                FePrimaryButton(
                  label: _running ? 'İşleniyor…' : 'MP4 olarak dışa aktar',
                  icon: Icons.file_upload_outlined,
                  loading: _running,
                  onPressed: _running ? null : _start,
                ),
                if (p != null &&
                    p.phase == ExportPhase.done &&
                    p.outputPath != null) ...[
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final path = p.outputPath!;
                      if (await File(path).exists()) {
                        await Share.shareXFiles(
                          [XFile(path)],
                          text: 'ForgeEdit export',
                        );
                      }
                    },
                    icon: const Icon(Icons.share),
                    label: const Text('Paylaş'),
                  ),
                ],
              ],
            ),
    );
  }
}
