import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/project_model.dart';
import '../../../domain/models/project_templates.dart';
import '../../providers/project_list_provider.dart';
import '../editor/editor_screen.dart';
import '../templates/template_gallery_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _navIndex = 0;

  Future<void> _createNewProject() async {
    final project =
        await ref.read(projectListProvider.notifier).createProject();
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => EditorScreen(projectId: project.id)),
    );
    ref.read(projectListProvider.notifier).refresh();
  }

  Future<void> _createFromTemplate(ProjectTemplate tpl) async {
    final project = await ref
        .read(projectListProvider.notifier)
        .createFromTemplate(tpl);
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => EditorScreen(projectId: project.id)),
    );
    ref.read(projectListProvider.notifier).refresh();
  }

  Future<void> _openProject(ProjectModel p) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => EditorScreen(projectId: p.id)),
    );
    ref.read(projectListProvider.notifier).refresh();
  }

  Future<void> _rename(ProjectModel p) async {
    final c = TextEditingController(text: p.name);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Yeniden adlandır'),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('İptal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );
    if (name != null && name.isNotEmpty) {
      await ref.read(projectListProvider.notifier).renameProject(p.id, name);
    }
  }

  @override
  Widget build(BuildContext context) {
    final projectsAsync = ref.watch(projectListProvider);

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: _navIndex == 3
                  ? const _SettingsPlaceholder()
                  : _HomeBody(
                          projectsAsync: projectsAsync,
                          onNew: _createNewProject,
                          onOpen: _openProject,
                          onRename: _rename,
                          onDelete: (id) => ref
                              .read(projectListProvider.notifier)
                              .deleteProject(id),
                          onDuplicate: (p) => ref
                              .read(projectListProvider.notifier)
                              .duplicateProject(p.id),
                          onTemplate: _createFromTemplate,
                          onSeeAllTemplates: () => setState(() => _navIndex = 2),
                        ),
            ),
            _BottomNav(
              index: _navIndex,
              onChanged: (i) {
                if (i == 2) {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const TemplateGalleryScreen(),
                    ),
                  );
                  return;
                }
                setState(() => _navIndex = i);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _HomeBody extends StatelessWidget {
  final AsyncValue<List<ProjectModel>> projectsAsync;
  final VoidCallback onNew;
  final void Function(ProjectModel) onOpen;
  final void Function(ProjectModel) onRename;
  final void Function(String) onDelete;
  final void Function(ProjectModel) onDuplicate;
  final void Function(ProjectTemplate) onTemplate;
  final VoidCallback onSeeAllTemplates;

  const _HomeBody({
    required this.projectsAsync,
    required this.onNew,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
    required this.onDuplicate,
    required this.onTemplate,
    required this.onSeeAllTemplates,
  });

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        gradient: AppTheme.primaryGradient,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.primary.withValues(alpha: 0.4),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Text(
                          'F',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 24,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'ForgeEdit',
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 22,
                              letterSpacing: -0.5,
                            ),
                          ),
                          Text(
                            'Video düzenleyici',
                            style: TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                    DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: AppTheme.primaryGradient,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: onNew,
                          borderRadius: BorderRadius.circular(16),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 12,
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.add, color: Colors.white, size: 20),
                                SizedBox(width: 6),
                                Text(
                                  'Yeni',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                // Templates banner
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: onSeeAllTemplates,
                    borderRadius: BorderRadius.circular(18),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        gradient: LinearGradient(
                          colors: [
                            AppTheme.primary.withValues(alpha: 0.85),
                            const Color(0xFF8B6CFF).withValues(alpha: 0.75),
                            AppTheme.surfaceElevated,
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border: Border.all(
                          color: AppTheme.primary.withValues(alpha: 0.4),
                        ),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.dashboard_customize_rounded,
                              color: Colors.white, size: 28),
                          SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Şablonlar',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 17,
                                    color: Colors.white,
                                  ),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  'CapCut tarzı hazır video şablonları',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.white70,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Icon(Icons.chevron_right, color: Colors.white70),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Category chips
                SizedBox(
                  height: 72,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final item in [
                        (Icons.play_circle_fill, 'Reels', Color(0xFF7C5CFF)),
                        (Icons.landscape, 'Vlog', Color(0xFF5B8CFF)),
                        (Icons.favorite, 'Geçişler', Color(0xFFE040FB)),
                        (Icons.movie, 'Tanıtım', Color(0xFFFF9800)),
                        (Icons.music_note, 'Müzikli', Color(0xFF00BCD4)),
                      ])
                        Padding(
                          padding: const EdgeInsets.only(right: 10),
                          child: InkWell(
                            onTap: onSeeAllTemplates,
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              width: 72,
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              decoration: BoxDecoration(
                                color: AppTheme.surfaceElevated,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: AppTheme.border),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(item.$1, color: item.$3, size: 22),
                                  const SizedBox(height: 6),
                                  Text(
                                    item.$2,
                                    style: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    const Text(
                      'Projelerim',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 18,
                      ),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: onSeeAllTemplates,
                      child: const Text('Tümünü gör >'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        projectsAsync.when(
          loading: () => const SliverFillRemaining(
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (e, _) => SliverFillRemaining(
            child: Center(child: Text('$e')),
          ),
          data: (projects) {
            if (projects.isEmpty) {
              return SliverFillRemaining(
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 88,
                        height: 88,
                        decoration: BoxDecoration(
                          gradient: AppTheme.primaryGradient,
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: const Icon(Icons.movie_creation_rounded,
                            size: 44, color: Colors.white),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        'Henüz proje yok',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 18,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Yeni proje veya şablon ile başla',
                        style: TextStyle(color: AppTheme.textSecondary),
                      ),
                      const SizedBox(height: 20),
                      FilledButton.icon(
                        onPressed: onNew,
                        icon: const Icon(Icons.add),
                        label: const Text('İlk projeyi oluştur'),
                      ),
                    ],
                  ),
                ),
              );
            }
            return SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: 0.92,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, i) {
                    final p = projects[i];
                    return _ProjectThumbCard(
                      project: p,
                      onTap: () => onOpen(p),
                      onRename: () => onRename(p),
                      onDelete: () => onDelete(p.id),
                      onDuplicate: () => onDuplicate(p),
                    );
                  },
                  childCount: projects.length,
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class _ProjectThumbCard extends StatelessWidget {
  final ProjectModel project;
  final VoidCallback onTap;
  final VoidCallback onRename;
  final VoidCallback onDelete;
  final VoidCallback onDuplicate;

  const _ProjectThumbCard({
    required this.project,
    required this.onTap,
    required this.onRename,
    required this.onDelete,
    required this.onDuplicate,
  });

  @override
  Widget build(BuildContext context) {
    final sec = (project.durationMs / 1000).round();
    final mm = (sec ~/ 60).toString().padLeft(2, '0');
    final ss = (sec % 60).toString().padLeft(2, '0');
    final dateFmt = DateFormat('d MMM yyyy');

    return Material(
      color: AppTheme.surfaceElevated,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        onLongPress: onRename,
        borderRadius: BorderRadius.circular(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              flex: 3,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(16),
                  ),
                  gradient: LinearGradient(
                    colors: [
                      AppTheme.primary.withValues(alpha: 0.35),
                      AppTheme.surfaceHigh,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Stack(
                  children: [
                    const Center(
                      child: Icon(
                        Icons.play_circle_fill,
                        size: 44,
                        color: Colors.white70,
                      ),
                    ),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '$mm:$ss',
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 6, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      project.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      dateFmt.format(project.updatedAt),
                      style: const TextStyle(
                        fontSize: 11,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    const Spacer(),
                    Row(
                      children: [
                        Text(
                          '${project.clips.length} klip',
                          style: const TextStyle(
                            fontSize: 10,
                            color: AppTheme.textTertiary,
                          ),
                        ),
                        const Spacer(),
                        InkWell(
                          onTap: onDuplicate,
                          child: const Icon(Icons.copy, size: 16,
                              color: AppTheme.textSecondary),
                        ),
                        const SizedBox(width: 8),
                        InkWell(
                          onTap: onDelete,
                          child: const Icon(Icons.delete_outline, size: 16,
                              color: AppTheme.textSecondary),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BottomNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;

  const _BottomNav({required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(top: BorderSide(color: AppTheme.border)),
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 58,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _navItem(0, Icons.home_rounded, 'Ana Sayfa'),
              _navItem(1, Icons.folder_outlined, 'Projeler'),
              _navItem(2, Icons.grid_view_rounded, 'Şablonlar'),
              _navItem(3, Icons.settings_outlined, 'Ayarlar'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navItem(int i, IconData icon, String label) {
    final sel = index == i || (i == 1 && index == 0);
    // Projeler and Ana sayfa both show home body for simplicity when index 0 or 1
    final active = i == 0 ? index == 0 || index == 1 : index == i;
    return InkWell(
      onTap: () => onChanged(i == 1 ? 0 : i),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: active ? AppTheme.primary : AppTheme.textTertiary,
            size: 24,
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: active ? FontWeight.w700 : FontWeight.w500,
              color: active ? AppTheme.primary : AppTheme.textTertiary,
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsPlaceholder extends StatelessWidget {
  const _SettingsPlaceholder();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.settings, size: 48, color: AppTheme.textSecondary),
            SizedBox(height: 12),
            Text(
              'Ayarlar',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
            ),
            SizedBox(height: 8),
            Text(
              'ForgeEdit v0.1 — yerel projeler, FFmpeg export',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}
