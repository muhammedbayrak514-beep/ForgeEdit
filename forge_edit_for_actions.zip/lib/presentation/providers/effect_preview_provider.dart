import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Temporary effect/transition preview (not written to project until applied).
class EffectPreviewState {
  final String? filterId;
  final double filterIntensity;
  final String? transitionId;
  final bool playingTransition;

  const EffectPreviewState({
    this.filterId,
    this.filterIntensity = 1.0,
    this.transitionId,
    this.playingTransition = false,
  });

  static const empty = EffectPreviewState();

  EffectPreviewState copyWith({
    String? filterId,
    double? filterIntensity,
    String? transitionId,
    bool? playingTransition,
    bool clearFilter = false,
    bool clearTransition = false,
  }) {
    return EffectPreviewState(
      filterId: clearFilter ? null : (filterId ?? this.filterId),
      filterIntensity: filterIntensity ?? this.filterIntensity,
      transitionId: clearTransition ? null : (transitionId ?? this.transitionId),
      playingTransition: playingTransition ?? this.playingTransition,
    );
  }
}

final effectPreviewProvider =
    StateProvider.family<EffectPreviewState, String>((ref, projectId) {
  return EffectPreviewState.empty;
});
