import 'package:uuid/uuid.dart';

import 'models/clip_model.dart';
import 'models/project_model.dart';
import 'package:collection/collection.dart';

/// Pure timeline operations. Main video track packing never moves audio/text.
class TimelineOps {
  static const _uuid = Uuid();
  static const int minTrimDurationMs = 100;
  static const int snapThresholdMs = 120;

  /// Snap [ms] to nearby clip edges / zero when within threshold.
  static int snapMs(
    int ms,
    List<ClipModel> clips, {
    int? thresholdMs,
    List<int> markersMs = const [],
  }) {
    final th = thresholdMs ?? snapThresholdMs;
    final points = <int>{0};
    for (final c in clips) {
      points.add(c.timelineStartMs);
      points.add(c.timelineEndMs);
    }
    for (final m in markersMs) {
      points.add(m);
    }
    var best = ms;
    var bestDist = th + 1;
    for (final p in points) {
      final d = (ms - p).abs();
      if (d < bestDist) {
        bestDist = d;
        best = p;
      }
    }
    return bestDist <= th ? best : ms;
  }


  static List<ClipModel> mainTrackClips(ProjectModel project) {
    final list =
        project.clips.where((c) => c.trackIndex == TrackIndex.video).toList()
          ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));
    return list;
  }

  /// Pack only track 0. Audio (1) and text (2) keep their timelineStartMs.
  static ProjectModel packMainTrack(ProjectModel project) {
    final main = mainTrackClips(project);
    final others =
        project.clips.where((c) => c.trackIndex != TrackIndex.video).toList();
    var cursor = 0;
    final packed = <ClipModel>[];
    for (final c in main) {
      packed.add(c.copyWith(timelineStartMs: cursor));
      cursor += c.durationMs;
    }
    return project.copyWith(
      clips: [...packed, ...others],
      updatedAt: DateTime.now(),
    );
  }

  static ProjectModel trimClip({
    required ProjectModel project,
    required String clipId,
    required int newTrimStartMs,
    required int newTrimEndMs,
  }) {
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return project;

    final maxSrc = clip.sourceDurationMs > 0 ? clip.sourceDurationMs : newTrimEndMs;
    var start = newTrimStartMs.clamp(0, maxSrc);
    var end = newTrimEndMs.clamp(0, maxSrc);
    if (end - start < minTrimDurationMs) {
      if (start + minTrimDurationMs <= maxSrc) {
        end = start + minTrimDurationMs;
      } else {
        start = (end - minTrimDurationMs).clamp(0, maxSrc);
      }
    }
    if (start >= end) return project;

    final updated = clip.copyWith(trimStartMs: start, trimEndMs: end);
    var next = project.updateClip(updated);
    if (clip.trackIndex == TrackIndex.video) {
      next = packMainTrack(next);
    }
    return next;
  }

  /// Resize clip from left or right edge (PicsArt-style handles).
  ///
  /// [deltaTimelineMs] positive = edge moves to the right on the timeline.
  /// Left edge: keeps the right edge fixed (timeline end).
  /// Right edge: keeps the left edge fixed (timeline start).
  static ProjectModel resizeClipEdge({
    required ProjectModel project,
    required String clipId,
    required bool fromLeft,
    required int deltaTimelineMs,
  }) {
    if (deltaTimelineMs == 0) return project;
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return project;

    final speed = clip.speed <= 0 ? 1.0 : clip.speed;
    final minDur = minTrimDurationMs;
    // Max duration for source-bound media (video/audio)
    final maxTrimSpan = clip.sourceDurationMs > 0
        ? clip.sourceDurationMs
        : 10 * 60 * 1000;
    final maxDurTimeline = clip.type == ClipType.video || clip.type == ClipType.audio
        ? (maxTrimSpan / speed).round().clamp(minDur, 24 * 3600 * 1000)
        : 10 * 60 * 1000; // text/image can grow up to 10 min

    final oldDur = clip.durationMs;
    final oldStart = clip.timelineStartMs;
    final oldEnd = oldStart + oldDur;

    int newStart = oldStart;
    int newDur = oldDur;

    if (fromLeft) {
      newStart = (oldStart + deltaTimelineMs).clamp(0, oldEnd - minDur);
      newDur = oldEnd - newStart;
    } else {
      newDur = (oldDur + deltaTimelineMs).clamp(minDur, maxDurTimeline);
      newStart = oldStart;
    }
    newDur = newDur.clamp(minDur, maxDurTimeline);

    // Map timeline duration → source trim window
    final neededTrimSpan = (newDur * speed).round().clamp(minDur, 24 * 3600 * 1000);

    int newTrimStart = clip.trimStartMs;
    int newTrimEnd = clip.trimEndMs;
    int newSource = clip.sourceDurationMs;

    if (clip.type == ClipType.video || clip.type == ClipType.audio) {
      if (fromLeft) {
        // Keep trimEnd fixed when possible; move trimStart
        newTrimEnd = clip.trimEndMs;
        newTrimStart = (newTrimEnd - neededTrimSpan).clamp(0, newTrimEnd - minDur);
        // If not enough headroom on the left, clamp duration
        final actualSpan = newTrimEnd - newTrimStart;
        newDur = (actualSpan / speed).round().clamp(minDur, maxDurTimeline);
        if (fromLeft) {
          newStart = oldEnd - newDur;
          if (newStart < 0) {
            newStart = 0;
            newDur = oldEnd.clamp(minDur, maxDurTimeline);
          }
        }
      } else {
        newTrimStart = clip.trimStartMs;
        newTrimEnd = (newTrimStart + neededTrimSpan).clamp(newTrimStart + minDur, maxTrimSpan);
        final actualSpan = newTrimEnd - newTrimStart;
        newDur = (actualSpan / speed).round().clamp(minDur, maxDurTimeline);
      }
    } else {
      // Text / image: duration is synthetic — grow source as needed
      newSource = neededTrimSpan < 100 ? 100 : neededTrimSpan;
      newTrimStart = 0;
      newTrimEnd = newSource;
    }

    var updated = clip.copyWith(
      timelineStartMs: newStart,
      trimStartMs: newTrimStart,
      trimEndMs: newTrimEnd,
      sourceDurationMs: newSource,
    );
    var next = project.updateClip(updated);
    if (clip.trackIndex == TrackIndex.video) {
      next = packMainTrack(next);
    }
    return next;
  }

  static ProjectModel? splitClip({
    required ProjectModel project,
    required String clipId,
    required int projectTimeMs,
  }) {
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return null;
    if (clip.type == ClipType.text) return null; // text: edit duration instead

    if (projectTimeMs <= clip.timelineStartMs ||
        projectTimeMs >= clip.timelineEndMs) {
      return null;
    }

    final offsetInClip = projectTimeMs - clip.timelineStartMs;
    // Map timeline offset → source using average of speed ramp.
    final s0 = clip.speed <= 0 ? 1.0 : clip.speed;
    final s1 = clip.speedEnd <= 0 ? s0 : clip.speedEnd;
    final avgSp = ((s0 + s1) / 2).clamp(0.05, 8.0);
    final sourceSplit =
        clip.trimStartMs + (offsetInClip * avgSp).round();

    if (sourceSplit - clip.trimStartMs < minTrimDurationMs ||
        clip.trimEndMs - sourceSplit < minTrimDurationMs) {
      return null;
    }

    final left = clip.copyWith(trimEndMs: sourceSplit);

    final right = clip.copyWith(
      id: _uuid.v4(),
      displayName: '${clip.displayName} (2)',
      trimStartMs: sourceSplit,
      timelineStartMs: projectTimeMs,
    );

    final without = project.clips.where((c) => c.id != clipId).toList();
    var next = project.copyWith(
      clips: [...without, left, right],
      updatedAt: DateTime.now(),
    );
    if (clip.trackIndex == TrackIndex.video) {
      next = packMainTrack(next);
    }
    return next;
  }

  static ProjectModel deleteClip({
    required ProjectModel project,
    required String clipId,
  }) {
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    final next = project.removeClip(clipId);
    if (clip != null && clip.trackIndex == TrackIndex.video) {
      return packMainTrack(next);
    }
    return next.copyWith(updatedAt: DateTime.now());
  }

  static ProjectModel deleteClips({
    required ProjectModel project,
    required Iterable<String> clipIds,
  }) {
    var next = project;
    final ids = clipIds.toSet();
    var touchedVideo = false;
    for (final id in ids) {
      final c = next.clips.where((x) => x.id == id).firstOrNull;
      if (c != null && c.trackIndex == TrackIndex.video) touchedVideo = true;
      next = next.removeClip(id);
    }
    if (touchedVideo) next = packMainTrack(next);
    return next.copyWith(updatedAt: DateTime.now());
  }

  /// Paste a deep copy of [source] at [timelineStartMs].
  static ProjectModel pasteClip({
    required ProjectModel project,
    required ClipModel source,
    required int timelineStartMs,
  }) {
    final start = snapMs(
      timelineStartMs,
      project.clips,
      markersMs: project.markersMs,
    );
    final copy = source.copyWith(
      id: _uuid.v4(),
      timelineStartMs: start < 0 ? 0 : start,
    );
    var next = project.addClip(copy);
    if (copy.trackIndex == TrackIndex.video) {
      next = packMainTrack(next);
    }
    return next;
  }

  static ProjectModel duplicateClip({
    required ProjectModel project,
    required String clipId,
  }) {
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return project;
    final copy = clip.copyWith(
      id: _uuid.v4(),
      timelineStartMs: clip.timelineEndMs,
      displayName: '${clip.displayName} kopya',
    );
    var next = project.addClip(copy);
    if (clip.trackIndex == TrackIndex.video) {
      next = packMainTrack(next);
    }
    return next.copyWith(updatedAt: DateTime.now());
  }

  /// Split a video/image clip into equal chunks of [intervalMs].
  static ProjectModel autoSplitEvery({
    required ProjectModel project,
    required String clipId,
    required int intervalMs,
  }) {
    if (intervalMs < 200) return project;
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return project;
    if (clip.type != ClipType.video && clip.type != ClipType.image) {
      return project;
    }
    final dur = clip.durationMs;
    if (dur <= intervalMs) return project;

    final pieces = <ClipModel>[];
    var localStart = clip.trimStartMs;
    final trimEnd = clip.trimEndMs;
    var i = 0;
    while (localStart + minTrimDurationMs < trimEnd) {
      final localEnd = (localStart + (intervalMs * clip.speed).round())
          .clamp(localStart + minTrimDurationMs, trimEnd);
      pieces.add(clip.copyWith(
        id: i == 0 ? clip.id : _uuid.v4(),
        trimStartMs: localStart,
        trimEndMs: localEnd,
        displayName: i == 0 ? clip.displayName : '${clip.displayName} ·${i + 1}',
      ));
      localStart = localEnd;
      i++;
      if (localEnd >= trimEnd) break;
    }
    if (pieces.isEmpty) return project;

    final others = project.clips.where((c) => c.id != clipId).toList();
    var next = project.copyWith(clips: [...others, ...pieces]);
    if (clip.trackIndex == TrackIndex.video) {
      next = packMainTrack(next);
    }
    return next.copyWith(updatedAt: DateTime.now());
  }

  static ProjectModel reorderMainTrack({
    required ProjectModel project,
    required String clipId,
    required int newIndex,
  }) {
    final main = mainTrackClips(project);
    final others =
        project.clips.where((c) => c.trackIndex != TrackIndex.video).toList();
    final from = main.indexWhere((c) => c.id == clipId);
    if (from < 0) return project;
    if (main[from].locked) return project;

    final item = main.removeAt(from);
    final to = newIndex.clamp(0, main.length);
    main.insert(to, item);

    var cursor = 0;
    final packed = <ClipModel>[];
    for (final c in main) {
      packed.add(c.copyWith(timelineStartMs: cursor));
      cursor += c.durationMs;
    }

    return project.copyWith(
      clips: [...packed, ...others],
      updatedAt: DateTime.now(),
    );
  }

  /// Free-place audio/text (or any clip) at an absolute timeline start.
  static ProjectModel setClipTimelineStart({
    required ProjectModel project,
    required String clipId,
    required int timelineStartMs,
  }) {
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.locked) return project;
    final others = project.clips.where((c) => c.id != clipId).toList();
    final snapped = snapMs(
      timelineStartMs.clamp(0, 24 * 3600 * 1000),
      others,
      markersMs: project.markersMs,
    );
    if (snapped == clip.timelineStartMs) return project;
    return project.updateClip(
      clip.copyWith(timelineStartMs: snapped),
    );
  }

  static ProjectModel moveClip({
    required ProjectModel project,
    required String clipId,
    required int direction,
  }) {
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return project;

    // Main track: reorder among video clips
    if (clip.trackIndex == TrackIndex.video) {
      final main = mainTrackClips(project);
      final from = main.indexWhere((c) => c.id == clipId);
      if (from < 0) return project;
      final to = from + direction;
      if (to < 0 || to >= main.length) return project;
      return reorderMainTrack(project: project, clipId: clipId, newIndex: to);
    }

    // Audio/text: nudge timelineStartMs by 500ms steps (simple Stage 6)
    const step = 500;
    final newStart =
        (clip.timelineStartMs + direction * step).clamp(0, 24 * 3600 * 1000);
    return project.updateClip(clip.copyWith(timelineStartMs: newStart));
  }

  /// Text-based edit: remove [startMs, endMs) from main video track and close gap.
  /// Affects video/image clips on track 0 that overlap the range.
  static ProjectModel cutMainRangeAndCloseGap({
    required ProjectModel project,
    required int rangeStartMs,
    required int rangeEndMs,
  }) {
    if (rangeEndMs <= rangeStartMs) return project;
    final gap = rangeEndMs - rangeStartMs;
    final result = <ClipModel>[];
    for (final c in project.clips) {
      if (c.trackIndex != TrackIndex.video) {
        // Shift later non-video clips that start after range to keep sync optional:
        // Only pack main; leave overlays/text absolute unless they sit in range.
        if (c.timelineStartMs >= rangeEndMs) {
          result.add(c.copyWith(timelineStartMs: c.timelineStartMs - gap));
        } else if (c.timelineEndMs <= rangeStartMs) {
          result.add(c);
        } else if (c.type == ClipType.text ||
            c.trackIndex == TrackIndex.sticker ||
            c.trackIndex == TrackIndex.audio) {
          // Drop text fully inside deleted range
          if (c.timelineStartMs >= rangeStartMs &&
              c.timelineEndMs <= rangeEndMs) {
            continue;
          }
          result.add(c);
        } else {
          result.add(c);
        }
        continue;
      }

      final cs = c.timelineStartMs;
      final ce = c.timelineEndMs;
      // no overlap
      if (ce <= rangeStartMs) {
        result.add(c);
        continue;
      }
      if (cs >= rangeEndMs) {
        result.add(c.copyWith(timelineStartMs: cs - gap));
        continue;
      }
      // Fully inside → remove
      if (cs >= rangeStartMs && ce <= rangeEndMs) {
        continue;
      }
      // Overlap left part only
      if (cs < rangeStartMs && ce > rangeStartMs && ce <= rangeEndMs) {
        final keepDur = rangeStartMs - cs;
        final newTrimEnd = c.trimStartMs +
            (keepDur * ((c.speed + (c.speedEnd <= 0 ? c.speed : c.speedEnd)) / 2)
                    .clamp(0.1, 8.0))
                .round();
        result.add(c.copyWith(
          trimEndMs: newTrimEnd.clamp(c.trimStartMs + minTrimDurationMs,
              c.sourceDurationMs > 0 ? c.sourceDurationMs : newTrimEnd),
        ));
        continue;
      }
      // Overlap right part only
      if (cs >= rangeStartMs && cs < rangeEndMs && ce > rangeEndMs) {
        final cutInto = rangeEndMs - cs;
        final avgSp =
            ((c.speed + (c.speedEnd <= 0 ? c.speed : c.speedEnd)) / 2)
                .clamp(0.1, 8.0);
        final trimAdvance = (cutInto * avgSp).round();
        result.add(c.copyWith(
          timelineStartMs: rangeStartMs,
          trimStartMs: (c.trimStartMs + trimAdvance)
              .clamp(0, c.trimEndMs - minTrimDurationMs),
        ));
        continue;
      }
      // Spans entire range → split into left + right
      if (cs < rangeStartMs && ce > rangeEndMs) {
        final avgSp =
            ((c.speed + (c.speedEnd <= 0 ? c.speed : c.speedEnd)) / 2)
                .clamp(0.1, 8.0);
        final leftDur = rangeStartMs - cs;
        final leftTrimEnd = c.trimStartMs + (leftDur * avgSp).round();
        final left = c.copyWith(
          id: _uuid.v4(),
          trimEndMs: leftTrimEnd.clamp(
              c.trimStartMs + minTrimDurationMs, c.trimEndMs),
        );
        final rightAdvance = ((rangeEndMs - cs) * avgSp).round();
        final right = c.copyWith(
          id: _uuid.v4(),
          timelineStartMs: rangeStartMs,
          trimStartMs: (c.trimStartMs + rightAdvance)
              .clamp(0, c.trimEndMs - minTrimDurationMs),
        );
        result.add(left);
        result.add(right);
        continue;
      }
      result.add(c);
    }
    return packMainTrack(project.copyWith(clips: result, updatedAt: DateTime.now()));
  }


}
