import 'clip_model.dart';
import 'effect_models.dart';

/// One-tap look packs (filter + transition + optional text style/anim).
class EffectPreset {
  final String id;
  final String label;
  final String description;
  final String filterId;
  final double filterIntensity;
  final String transitionId;
  final int transitionDurationMs;
  final String? textStyleId;
  final String? textAnimId;

  const EffectPreset({
    required this.id,
    required this.label,
    required this.description,
    required this.filterId,
    this.filterIntensity = 0.85,
    required this.transitionId,
    this.transitionDurationMs = 500,
    this.textStyleId,
    this.textAnimId,
  });

  static const all = <EffectPreset>[
    EffectPreset(
      id: 'cinematic',
      label: 'Sinematik',
      description: 'Sıcak ton + fade + zarif yazı',
      filterId: 'warm',
      filterIntensity: 0.7,
      transitionId: 'fadeBlack',
      transitionDurationMs: 700,
      textStyleId: 'classic_playfair',
      textAnimId: 'fadeIn',
    ),
    EffectPreset(
      id: 'vlog',
      label: 'Vlog',
      description: 'Canlı renk + kaydırma geçiş',
      filterId: 'vivid',
      filterIntensity: 0.75,
      transitionId: 'slideLeft',
      transitionDurationMs: 400,
      textStyleId: 'modern_bold',
      textAnimId: 'pop',
    ),
    EffectPreset(
      id: 'retro',
      label: 'Retro',
      description: 'Sepya + dissolve',
      filterId: 'sepia',
      filterIntensity: 0.9,
      transitionId: 'dissolve',
      transitionDurationMs: 600,
      textStyleId: 'classic_gold',
      textAnimId: 'typewriter',
    ),
    EffectPreset(
      id: 'noir',
      label: 'Noir',
      description: 'Siyah-beyaz + fade',
      filterId: 'noir',
      filterIntensity: 1.0,
      transitionId: 'crossfade',
      transitionDurationMs: 500,
      textStyleId: 'plain_white',
      textAnimId: 'fadeInOut',
    ),
    EffectPreset(
      id: 'dreamy',
      label: 'Rüya',
      description: 'Solgun + yumuşak geçiş',
      filterId: 'fade',
      filterIntensity: 0.8,
      transitionId: 'crossfade',
      transitionDurationMs: 800,
      textStyleId: 'minimal_soft_shadow',
      textAnimId: 'rise',
    ),
    EffectPreset(
      id: 'energy',
      label: 'Enerji',
      description: 'Kontrast + wipe',
      filterId: 'highContrast',
      filterIntensity: 0.85,
      transitionId: 'wipeLeft',
      transitionDurationMs: 350,
      textStyleId: 'modern_bold',
      textAnimId: 'shake',
    ),
    EffectPreset(
      id: 'cool_tone',
      label: 'Soğuk ton',
      description: 'Mavi filtre + slide',
      filterId: 'cool',
      filterIntensity: 0.8,
      transitionId: 'slideUp',
      transitionDurationMs: 450,
      textStyleId: 'modern_blue',
      textAnimId: 'slideUp',
    ),
    EffectPreset(
      id: 'vintage_film',
      label: 'Eski film',
      description: 'Vintage + pixel geçiş',
      filterId: 'vintage',
      filterIntensity: 0.9,
      transitionId: 'pixelize',
      transitionDurationMs: 500,
      textStyleId: 'classic_serif',
      textAnimId: 'fadeIn',
    ),
  ];

  /// Apply pack to all main video clips + text clips in project.
  static ProjectApply applyToClips(List<ClipModel> clips, EffectPreset pack) {
    final out = <ClipModel>[];
    for (final c in clips) {
      if (c.type == ClipType.video || c.type == ClipType.image) {
        if (c.trackIndex == TrackIndex.video) {
          out.add(c.copyWith(
            filterId: pack.filterId,
            filterIntensity: pack.filterIntensity,
            transitionId: pack.transitionId,
            transitionDurationMs: pack.transitionDurationMs,
          ));
          continue;
        }
      }
      if (c.type == ClipType.text) {
        out.add(c.copyWith(
          textStyleId: pack.textStyleId ?? c.textStyleId,
          textAnimId: pack.textAnimId ?? c.textAnimId,
        ));
        continue;
      }
      out.add(c);
    }
    return ProjectApply(out);
  }
}

class ProjectApply {
  final List<ClipModel> clips;
  const ProjectApply(this.clips);
}
