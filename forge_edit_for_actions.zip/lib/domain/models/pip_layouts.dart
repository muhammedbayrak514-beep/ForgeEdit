import 'clip_model.dart';

class PipLayoutSlot {
  final double posX;
  final double posY;
  final double scale;

  const PipLayoutSlot({
    required this.posX,
    required this.posY,
    required this.scale,
  });
}

class PipLayout {
  final String id;
  final String label;
  final String description;
  final List<PipLayoutSlot> slots;

  const PipLayout({
    required this.id,
    required this.label,
    required this.description,
    required this.slots,
  });

  static const all = <PipLayout>[
    PipLayout(
      id: 'corner',
      label: 'Köşe PiP',
      description: 'Sağ alt küçük pencere',
      slots: [
        PipLayoutSlot(posX: 0.78, posY: 0.78, scale: 0.35),
      ],
    ),
    PipLayout(
      id: 'split_v',
      label: 'Dikey split',
      description: 'Sol / sağ yarı',
      slots: [
        PipLayoutSlot(posX: 0.25, posY: 0.5, scale: 0.5),
        PipLayoutSlot(posX: 0.75, posY: 0.5, scale: 0.5),
      ],
    ),
    PipLayout(
      id: 'split_h',
      label: 'Yatay split',
      description: 'Üst / alt yarı',
      slots: [
        PipLayoutSlot(posX: 0.5, posY: 0.25, scale: 0.5),
        PipLayoutSlot(posX: 0.5, posY: 0.75, scale: 0.5),
      ],
    ),
    PipLayout(
      id: 'grid_2x2',
      label: '2×2 grid',
      description: 'Dört eşit panel',
      slots: [
        PipLayoutSlot(posX: 0.25, posY: 0.25, scale: 0.48),
        PipLayoutSlot(posX: 0.75, posY: 0.25, scale: 0.48),
        PipLayoutSlot(posX: 0.25, posY: 0.75, scale: 0.48),
        PipLayoutSlot(posX: 0.75, posY: 0.75, scale: 0.48),
      ],
    ),
    PipLayout(
      id: 'triple',
      label: 'Üçlü',
      description: 'Büyük sol + iki sağ',
      slots: [
        PipLayoutSlot(posX: 0.28, posY: 0.5, scale: 0.55),
        PipLayoutSlot(posX: 0.78, posY: 0.28, scale: 0.4),
        PipLayoutSlot(posX: 0.78, posY: 0.72, scale: 0.4),
      ],
    ),
  ];
}
