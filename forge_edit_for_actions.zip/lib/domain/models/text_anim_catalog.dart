/// CapCut-style preset text / sticker animations (preview + export-friendly ids).
class TextAnimDef {
  final String id;
  final String label;
  final String description;
  final String category; // text | sticker | both

  const TextAnimDef({
    required this.id,
    required this.label,
    required this.description,
    this.category = 'both',
  });
}

class TextAnimCatalog {
  static const String defaultId = 'none';

  static const all = <TextAnimDef>[
    TextAnimDef(id: 'none', label: 'Yok', description: 'Animasyon yok'),
    TextAnimDef(id: 'fadeIn', label: 'Fade In', description: 'Belirme'),
    TextAnimDef(id: 'fadeOut', label: 'Fade Out', description: 'Kaybolma'),
    TextAnimDef(id: 'fadeInOut', label: 'Fade In-Out', description: 'Giriş + çıkış'),
    TextAnimDef(id: 'slideUp', label: 'Yukarı kay', description: 'Alttan gelir'),
    TextAnimDef(id: 'slideDown', label: 'Aşağı kay', description: 'Üstten gelir'),
    TextAnimDef(id: 'slideLeft', label: 'Sola kay', description: 'Sağdan gelir'),
    TextAnimDef(id: 'slideRight', label: 'Sağa kay', description: 'Soldan gelir'),
    TextAnimDef(id: 'typewriter', label: 'Daktilo', description: 'Harf harf yazar', category: 'text'),
    TextAnimDef(id: 'pop', label: 'Pop', description: 'Büyüyerek belirir'),
    TextAnimDef(id: 'bounce', label: 'Bounce', description: 'Zıplayarak gelir'),
    TextAnimDef(id: 'zoomIn', label: 'Zoom In', description: 'Yakınlaşarak'),
    TextAnimDef(id: 'zoomOut', label: 'Zoom Out', description: 'Uzaklaşarak çıkar'),
    TextAnimDef(id: 'shake', label: 'Salla', description: 'Hafif titreşim'),
    TextAnimDef(id: 'pulse', label: 'Pulse', description: 'Nabız gibi scale'),
    TextAnimDef(id: 'spin', label: 'Dön', description: 'Hafif rotasyon girişi'),
    TextAnimDef(id: 'rise', label: 'Yüksel', description: 'Fade + yukarı'),
    TextAnimDef(id: 'drop', label: 'Düş', description: 'Yukarıdan düşer'),
    TextAnimDef(id: 'blurIn', label: 'Netleş', description: 'Belirsizden net (yaklaşık)'),
    TextAnimDef(id: 'glitch', label: 'Glitch', description: 'Titrek giriş'),
    TextAnimDef(id: 'wave', label: 'Dalga', description: 'Yatay salınım'),
  ];

  static List<TextAnimDef> forText() =>
      all.where((a) => a.category == 'both' || a.category == 'text').toList();

  static List<TextAnimDef> forSticker() =>
      all.where((a) => a.category == 'both' || a.category == 'sticker').toList();

  static TextAnimDef byId(String id) =>
      all.firstWhere((a) => a.id == id, orElse: () => all.first);
}
