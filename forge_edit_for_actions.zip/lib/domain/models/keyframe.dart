import 'package:equatable/equatable.dart';

/// A keyframe relative to the clip's timeline start (offsetMs).
class ClipKeyframe extends Equatable {
  final int offsetMs;
  final double? opacity;
  final double? posX;
  final double? posY;
  final double? scale;

  const ClipKeyframe({
    required this.offsetMs,
    this.opacity,
    this.posX,
    this.posY,
    this.scale,
  });

  Map<String, dynamic> toJson() => {
        'offsetMs': offsetMs,
        if (opacity != null) 'opacity': opacity,
        if (posX != null) 'posX': posX,
        if (posY != null) 'posY': posY,
        if (scale != null) 'scale': scale,
      };

  factory ClipKeyframe.fromJson(Map<String, dynamic> json) {
    return ClipKeyframe(
      offsetMs: json['offsetMs'] as int? ?? 0,
      opacity: (json['opacity'] as num?)?.toDouble(),
      posX: (json['posX'] as num?)?.toDouble(),
      posY: (json['posY'] as num?)?.toDouble(),
      scale: (json['scale'] as num?)?.toDouble(),
    );
  }

  @override
  List<Object?> get props => [offsetMs, opacity, posX, posY, scale];
}

/// Linear interpolation helpers for keyframe lists.
class KeyframeEval {
  static double _lerp(double a, double b, double t) => a + (b - a) * t;

  /// Evaluate [property] at local [timeMs] (0 = clip start).
  /// Falls back to [base] when no keyframes define that channel.
  static double eval({
    required List<ClipKeyframe> keys,
    required int timeMs,
    required double base,
    required double? Function(ClipKeyframe k) pick,
  }) {
    if (keys.isEmpty) return base;
    final sorted = [...keys]..sort((a, b) => a.offsetMs.compareTo(b.offsetMs));
    final withVal = sorted.where((k) => pick(k) != null).toList();
    if (withVal.isEmpty) return base;

    if (timeMs <= withVal.first.offsetMs) return pick(withVal.first)!;
    if (timeMs >= withVal.last.offsetMs) return pick(withVal.last)!;

    for (var i = 0; i < withVal.length - 1; i++) {
      final a = withVal[i];
      final b = withVal[i + 1];
      if (timeMs >= a.offsetMs && timeMs <= b.offsetMs) {
        final span = (b.offsetMs - a.offsetMs).clamp(1, 1 << 30);
        final t = ((timeMs - a.offsetMs) / span).clamp(0.0, 1.0);
        return _lerp(pick(a)!, pick(b)!, t);
      }
    }
    return base;
  }

  static double opacityAt(List<ClipKeyframe> keys, int localMs, double base) =>
      eval(keys: keys, timeMs: localMs, base: base, pick: (k) => k.opacity);

  static double posXAt(List<ClipKeyframe> keys, int localMs, double base) =>
      eval(keys: keys, timeMs: localMs, base: base, pick: (k) => k.posX);

  static double posYAt(List<ClipKeyframe> keys, int localMs, double base) =>
      eval(keys: keys, timeMs: localMs, base: base, pick: (k) => k.posY);

  static double scaleAt(List<ClipKeyframe> keys, int localMs, double base) =>
      eval(keys: keys, timeMs: localMs, base: base, pick: (k) => k.scale);
}
