/// Catalog of filters / transitions (preview + export).

enum FilterId {
  none,
  grayscale,
  sepia,
  warm,
  cool,
  highContrast,
  muted,
  vivid,
  vintage,
  bright,
  noir,
  fade,
  chromakey,
  filmGrain,
  vhs,
  glitch,
  lensFlare,
}

/// Transition ids — names map to FFmpeg xfade where possible.
enum TransitionId {
  none,
  crossfade,
  fadeBlack,
  fadeWhite,
  wipeLeft,
  wipeRight,
  wipeUp,
  wipeDown,
  slideLeft,
  slideRight,
  slideUp,
  slideDown,
  circleOpen,
  circleClose,
  dissolve,
  pixelize,
  radial,
  diagTl,
  hblur,
  distance,
}

class FilterDef {
  final FilterId id;
  final String label;
  final String description;
  final bool previewSupported;

  const FilterDef({
    required this.id,
    required this.label,
    required this.description,
    this.previewSupported = true,
  });
}

class TransitionDef {
  final TransitionId id;
  final String label;
  final String description;
  final bool exportReady;
  /// In-app preview style: fade | wipe | slide | circle | pixel | blur
  final String previewStyle;

  const TransitionDef({
    required this.id,
    required this.label,
    required this.description,
    this.exportReady = true,
    this.previewStyle = 'fade',
  });
}

class EffectCatalog {
  static const filters = <FilterDef>[
    FilterDef(id: FilterId.none, label: 'Yok', description: 'Filtre yok'),
    FilterDef(id: FilterId.grayscale, label: 'Siyah-beyaz', description: 'Gri tonlama'),
    FilterDef(id: FilterId.sepia, label: 'Sepya', description: 'Sıcak kahverengi'),
    FilterDef(id: FilterId.warm, label: 'Sıcak', description: 'Turuncu vurgu'),
    FilterDef(id: FilterId.cool, label: 'Soğuk', description: 'Mavi vurgu'),
    FilterDef(id: FilterId.highContrast, label: 'Kontrast', description: 'Yüksek kontrast'),
    FilterDef(id: FilterId.muted, label: 'Soluk', description: 'Düşük doygunluk'),
    FilterDef(id: FilterId.vivid, label: 'Canlı', description: 'Yüksek doygunluk'),
    FilterDef(id: FilterId.vintage, label: 'Vintage', description: 'Eski film hissi'),
    FilterDef(id: FilterId.bright, label: 'Parlak', description: 'Aydınlık'),
    FilterDef(id: FilterId.noir, label: 'Noir', description: 'Koyu siyah-beyaz'),
    FilterDef(id: FilterId.fade, label: 'Solgun', description: 'Yumuşak soluk'),
    FilterDef(id: FilterId.chromakey, label: 'Yeşil ekran', description: 'Chroma key (export)', previewSupported: false),
    FilterDef(id: FilterId.filmGrain, label: 'Film Grain', description: 'Sinematik gren'),
    FilterDef(id: FilterId.vhs, label: 'VHS', description: 'Eski kaset hissi'),
    FilterDef(id: FilterId.glitch, label: 'Glitch', description: 'Dijital bozulma'),
    FilterDef(id: FilterId.lensFlare, label: 'Lens Flare', description: 'Işık patlaması tonu'),
  ];

  static const transitions = <TransitionDef>[
    TransitionDef(id: TransitionId.none, label: 'Kesme', description: 'Anında kesme', previewStyle: 'none'),
    TransitionDef(id: TransitionId.crossfade, label: 'Çapraz', description: 'Dissolve', previewStyle: 'fade'),
    TransitionDef(id: TransitionId.fadeBlack, label: 'Siyaha sol', description: 'Siyah üzerinden', previewStyle: 'fadeBlack'),
    TransitionDef(id: TransitionId.fadeWhite, label: 'Beyaza sol', description: 'Beyaz üzerinden', previewStyle: 'fadeWhite'),
    TransitionDef(id: TransitionId.wipeLeft, label: 'Sola sil', description: 'Soldan sağa', previewStyle: 'wipeLeft'),
    TransitionDef(id: TransitionId.wipeRight, label: 'Sağa sil', description: 'Sağdan sola', previewStyle: 'wipeRight'),
    TransitionDef(id: TransitionId.wipeUp, label: 'Yukarı sil', description: 'Aşağıdan yukarı', previewStyle: 'wipeUp'),
    TransitionDef(id: TransitionId.wipeDown, label: 'Aşağı sil', description: 'Yukarıdan aşağı', previewStyle: 'wipeDown'),
    TransitionDef(id: TransitionId.slideLeft, label: 'Sola kay', description: 'Slide left', previewStyle: 'slideLeft'),
    TransitionDef(id: TransitionId.slideRight, label: 'Sağa kay', description: 'Slide right', previewStyle: 'slideRight'),
    TransitionDef(id: TransitionId.slideUp, label: 'Yukarı kay', description: 'Slide up', previewStyle: 'slideUp'),
    TransitionDef(id: TransitionId.slideDown, label: 'Aşağı kay', description: 'Slide down', previewStyle: 'slideDown'),
    TransitionDef(id: TransitionId.circleOpen, label: 'Daire aç', description: 'Merkezden açılır', previewStyle: 'circleOpen'),
    TransitionDef(id: TransitionId.circleClose, label: 'Daire kapa', description: 'Merkeze kapanır', previewStyle: 'circleClose'),
    TransitionDef(id: TransitionId.dissolve, label: 'Dağıl', description: 'Grenli dissolve', previewStyle: 'fade'),
    TransitionDef(id: TransitionId.pixelize, label: 'Piksel', description: 'Pikselize geçiş', previewStyle: 'pixel'),
    TransitionDef(id: TransitionId.radial, label: 'Radyal', description: 'Dairesel silme', previewStyle: 'circleOpen'),
    TransitionDef(id: TransitionId.diagTl, label: 'Çapraz köşe', description: 'Sol üst diyagonal', previewStyle: 'wipeLeft'),
    TransitionDef(id: TransitionId.hblur, label: 'Bulanık', description: 'Yatay blur geçiş', previewStyle: 'fade'),
    TransitionDef(id: TransitionId.distance, label: 'Mesafe', description: 'Zoom-ish mesafe', previewStyle: 'fade'),
  ];

  static FilterDef filterById(FilterId id) =>
      filters.firstWhere((f) => f.id == id, orElse: () => filters.first);

  static TransitionDef transitionById(TransitionId id) =>
      transitions.firstWhere((t) => t.id == id, orElse: () => transitions.first);

  static FilterDef filterByName(String name) {
    final id = FilterId.values.asNameMap()[name] ?? FilterId.none;
    return filterById(id);
  }

  static TransitionDef transitionByName(String name) {
    final id = TransitionId.values.asNameMap()[name] ?? TransitionId.none;
    return transitionById(id);
  }
}
