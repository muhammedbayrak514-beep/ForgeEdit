import 'clip_model.dart';

/// CapCut-style auto-caption templates (market).
class CaptionStylePackage {
  final String id;
  final String label;
  final String description;
  final String textStyleId;
  final double fontSize;
  final double posY;
  final String textAnimId;
  final double stroke;
  final double glow;
  final bool uppercase;

  const CaptionStylePackage({
    required this.id,
    required this.label,
    required this.description,
    required this.textStyleId,
    required this.fontSize,
    required this.posY,
    this.textAnimId = 'fadeIn',
    this.stroke = 0,
    this.glow = 0,
    this.uppercase = false,
  });

  static const all = <CaptionStylePackage>[
    CaptionStylePackage(
      id: 'bottom_band',
      label: 'Alt bant',
      description: 'Klasik altyazı',
      textStyleId: 'plain_white',
      fontSize: 28,
      posY: 0.88,
      stroke: 2,
    ),
    CaptionStylePackage(
      id: 'reels_bold',
      label: 'Reels kalın',
      description: 'Büyük, ortalanmış',
      textStyleId: 'modern_bold',
      fontSize: 36,
      posY: 0.72,
      textAnimId: 'pop',
      stroke: 3,
      glow: 0.4,
    ),
    CaptionStylePackage(
      id: 'story_soft',
      label: 'Story yumuşak',
      description: 'Üstte hafif metin',
      textStyleId: 'minimal_soft_shadow',
      fontSize: 24,
      posY: 0.18,
      textAnimId: 'slideDown',
    ),
    CaptionStylePackage(
      id: 'karaoke',
      label: 'Karaoke',
      description: 'Ritim / neon',
      textStyleId: 'neon_pink',
      fontSize: 32,
      posY: 0.78,
      textAnimId: 'typewriter',
      stroke: 2,
      glow: 0.5,
    ),
    CaptionStylePackage(
      id: 'cinematic',
      label: 'Sinematik',
      description: 'Küçük alt kenar',
      textStyleId: 'classic_playfair',
      fontSize: 22,
      posY: 0.9,
      textAnimId: 'fadeIn',
    ),
    CaptionStylePackage(
      id: 'word_pop',
      label: 'Word Pop',
      description: 'Kelime kelime pop',
      textStyleId: 'modern_bold',
      fontSize: 40,
      posY: 0.5,
      textAnimId: 'pop',
      stroke: 4,
      glow: 0.3,
      uppercase: true,
    ),
    CaptionStylePackage(
      id: 'box_caption',
      label: 'Kutu altyazı',
      description: 'Güçlü kutu hissi',
      textStyleId: 'minimal_bold',
      fontSize: 26,
      posY: 0.85,
      textAnimId: 'fadeInOut',
      stroke: 1,
    ),
    CaptionStylePackage(
      id: 'yellow_outline',
      label: 'Sarı kontur',
      description: 'MrBeast tarzı',
      textStyleId: 'modern_bold',
      fontSize: 34,
      posY: 0.75,
      textAnimId: 'bounce',
      stroke: 5,
      glow: 0.2,
      uppercase: true,
    ),
    CaptionStylePackage(
      id: 'minimal_top',
      label: 'Minimal üst',
      description: 'İnce üst yazı',
      textStyleId: 'minimal_light',
      fontSize: 20,
      posY: 0.12,
      textAnimId: 'fadeIn',
    ),
    CaptionStylePackage(
      id: 'glitch_caption',
      label: 'Glitch caption',
      description: 'Titrek giriş',
      textStyleId: 'modern_coral',
      fontSize: 30,
      posY: 0.7,
      textAnimId: 'glitch',
      stroke: 2,
    ),
  ];

  ClipModel applyTo(ClipModel textClip) {
    var content = textClip.textContent;
    if (uppercase && content.isNotEmpty) {
      content = content.toUpperCase();
    }
    return textClip.copyWith(
      textContent: content,
      textStyleId: textStyleId,
      fontSize: fontSize,
      posY: posY,
      posX: 0.5,
      textAnimId: textAnimId,
      textStrokeWidth: stroke,
      textGlow: glow,
    );
  }
}
