
/// Bezier-inspired speed ramp presets (CapCut-style).
class SpeedRampPreset {
  final String id;
  final String label;
  final String description;
  /// Start / end playback rate.
  final double speedStart;
  final double speedEnd;

  const SpeedRampPreset({
    required this.id,
    required this.label,
    required this.description,
    required this.speedStart,
    required this.speedEnd,
  });

  static const all = <SpeedRampPreset>[
    SpeedRampPreset(
      id: 'constant',
      label: 'Sabit',
      description: 'Değişmeyen hız',
      speedStart: 1.0,
      speedEnd: 1.0,
    ),
    SpeedRampPreset(
      id: 'heroic',
      label: 'Heroic',
      description: 'Yavaş giriş → hızlı çıkış',
      speedStart: 0.5,
      speedEnd: 2.0,
    ),
    SpeedRampPreset(
      id: 'bullet_time',
      label: 'Bullet Time',
      description: 'Hızlı → aşırı yavaş',
      speedStart: 1.5,
      speedEnd: 0.25,
    ),
    SpeedRampPreset(
      id: 'montage',
      label: 'Montage',
      description: 'Orta → çok hızlı',
      speedStart: 1.0,
      speedEnd: 3.0,
    ),
    SpeedRampPreset(
      id: 'ease_in',
      label: 'Ease In',
      description: 'Yavaş başla',
      speedStart: 0.4,
      speedEnd: 1.0,
    ),
    SpeedRampPreset(
      id: 'ease_out',
      label: 'Ease Out',
      description: 'Yavaş bitir',
      speedStart: 1.0,
      speedEnd: 0.4,
    ),
    SpeedRampPreset(
      id: 'dramtic',
      label: 'Dramatik',
      description: 'Çok yavaş → normal',
      speedStart: 0.3,
      speedEnd: 1.2,
    ),
  ];

  /// Sample rate at progress t∈[0,1] with ease-in-out curve.
  double sample(double t) {
    final u = t.clamp(0.0, 1.0);
    // smoothstep cubic
    final s = u * u * (3 - 2 * u);
    return speedStart + (speedEnd - speedStart) * s;
  }
}
