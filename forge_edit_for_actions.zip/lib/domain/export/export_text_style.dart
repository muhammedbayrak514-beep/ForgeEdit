
import 'dart:ui' show FontWeight, Offset;

import '../models/clip_model.dart';
import '../models/keyframe.dart';
import '../models/text_style_catalog.dart';

/// Maps a text [ClipModel] + catalog style into FFmpeg drawtext parameters.
class ExportTextStyle {
  final String text;
  final int fontSize;
  final String fontcolor;
  final String xExpr;
  final String yExpr;
  final String alphaExpr;
  final String startSec;
  final String endSec;
  final double shadowX;
  final double shadowY;
  final String? shadowColor;
  final bool preferBold;

  const ExportTextStyle({
    required this.text,
    required this.fontSize,
    required this.fontcolor,
    required this.xExpr,
    required this.yExpr,
    required this.alphaExpr,
    required this.startSec,
    required this.endSec,
    this.shadowX = 0,
    this.shadowY = 0,
    this.shadowColor,
    this.preferBold = false,
  });

  static String _escapeDrawtext(String raw) {
    return raw
        .replaceAll(r'\', r'\\')
        .replaceAll(':', r'\:')
        .replaceAll("'", r"\'")
        .replaceAll('%', r'\%');
  }

  static String _rgb(int argb) {
    final r = ((argb >> 16) & 0xFF).toRadixString(16).padLeft(2, '0');
    final g = ((argb >> 8) & 0xFF).toRadixString(16).padLeft(2, '0');
    final b = (argb & 0xFF).toRadixString(16).padLeft(2, '0');
    return '#$r$g$b';
  }

  static String _shadowRgba(int argb, {double alpha = 0.75}) {
    final r = (argb >> 16) & 0xFF;
    final g = (argb >> 8) & 0xFF;
    final b = argb & 0xFF;
    return '0x${r.toRadixString(16).padLeft(2, '0')}'
        '${g.toRadixString(16).padLeft(2, '0')}'
        '${b.toRadixString(16).padLeft(2, '0')}'
        '@${alpha.toStringAsFixed(2)}';
  }

  /// Piecewise linear FFmpeg expression for project-time [t] in seconds.
  static String _piecewiseExpr({
    required List<ClipKeyframe> keys,
    required double Function(ClipKeyframe) pick,
    required double base,
    required int clipStartMs,
    required double Function(double v) mapValue,
  }) {
    final withVal = keys.where((k) => true).toList()
      ..sort((a, b) => a.offsetMs.compareTo(b.offsetMs));
    // Only keys that define this channel — use pick via nullable pattern in caller
    final pts = <({double t, double v})>[];
    for (final k in withVal) {
      final raw = pick(k);
      pts.add((t: (clipStartMs + k.offsetMs) / 1000.0, v: mapValue(raw)));
    }
    if (pts.isEmpty) {
      return mapValue(base).toStringAsFixed(3);
    }
    if (pts.length == 1) {
      return pts.first.v.toStringAsFixed(3);
    }
    // Build nested if(lt(t,t1), lerp, if(...))
    String lerp(double t0, double v0, double t1, double v1) {
      // v0 + (v1-v0)*(t-t0)/(t1-t0)
      final den = (t1 - t0).abs() < 1e-6 ? 1e-6 : (t1 - t0);
      return '($v0+($v1-($v0))*((t-($t0))/($den)))';
    }

    String build(int i) {
      if (i >= pts.length - 1) {
        return pts.last.v.toStringAsFixed(6);
      }
      final a = pts[i];
      final b = pts[i + 1];
      final mid = lerp(a.t, a.v, b.t, b.v);
      if (i == 0) {
        return 'if(lt(t\\,${a.t.toStringAsFixed(3)})\\,${a.v.toStringAsFixed(6)}\\,'
            'if(lt(t\\,${b.t.toStringAsFixed(3)})\\,$mid\\,${build(i + 1)}))';
      }
      return 'if(lt(t\\,${b.t.toStringAsFixed(3)})\\,$mid\\,${build(i + 1)})';
    }

    return build(0);
  }

  static ExportTextStyle fromClip(
    ClipModel clip, {
    required int frameWidth,
    required int frameHeight,
  }) {
    final def = TextStyleCatalog.byId(clip.textStyleId);
    final raw = TextStyleResolver.displayText(clip.textContent, def);
    final colorArgb = def.presetColorArgb ?? clip.textColorArgb;
    final preferBold = def.weight.value >= 600;

    double sx = 0, sy = 0;
    String? shadowCol;
    if (def.shadowBlur > 0 || def.shadowOffset != Offset.zero) {
      sx = def.shadowOffset.dx == 0 && def.shadowBlur > 0
          ? 2
          : def.shadowOffset.dx;
      sy = def.shadowOffset.dy == 0 && def.shadowBlur > 0
          ? 2
          : def.shadowOffset.dy;
      shadowCol = _shadowRgba(def.shadowColorArgb);
    }

    final startSec = (clip.timelineStartMs / 1000.0).toStringAsFixed(3);
    final endSec = (clip.timelineEndMs / 1000.0).toStringAsFixed(3);

    final staticX = (clip.posX * frameWidth).toStringAsFixed(1);
    final staticY = (clip.posY * frameHeight).toStringAsFixed(1);

    String xExpr = staticX;
    String yExpr = staticY;
    String alphaExpr = clip.opacity.clamp(0.0, 1.0).toStringAsFixed(3);

    final kfs = clip.keyframes;
    if (kfs.isNotEmpty) {
      final opKeys =
          kfs.where((k) => k.opacity != null).toList();
      final xKeys = kfs.where((k) => k.posX != null).toList();
      final yKeys = kfs.where((k) => k.posY != null).toList();

      if (opKeys.isNotEmpty) {
        alphaExpr = _piecewiseExpr(
          keys: opKeys,
          pick: (k) => k.opacity!,
          base: clip.opacity,
          clipStartMs: clip.timelineStartMs,
          mapValue: (v) => v.clamp(0.0, 1.0),
        );
      }
      if (xKeys.isNotEmpty) {
        xExpr = _piecewiseExpr(
          keys: xKeys,
          pick: (k) => k.posX!,
          base: clip.posX,
          clipStartMs: clip.timelineStartMs,
          mapValue: (v) => (v * frameWidth),
        );
      }
      if (yKeys.isNotEmpty) {
        yExpr = _piecewiseExpr(
          keys: yKeys,
          pick: (k) => k.posY!,
          base: clip.posY,
          clipStartMs: clip.timelineStartMs,
          mapValue: (v) => (v * frameHeight),
        );
      }
    }

    return ExportTextStyle(
      text: _escapeDrawtext(raw),
      fontSize: clip.fontSize.round().clamp(12, 200),
      fontcolor: _rgb(colorArgb),
      xExpr: xExpr,
      yExpr: yExpr,
      alphaExpr: alphaExpr,
      startSec: startSec,
      endSec: endSec,
      shadowX: sx,
      shadowY: sy,
      shadowColor: shadowCol,
      preferBold: preferBold,
    );
  }

  String toDrawtext({String? fontFile}) {
    final fontPart =
        (fontFile != null && fontFile.isNotEmpty) ? ":fontfile=$fontFile" : '';
    final shadowPart = (shadowColor != null)
        ? ':shadowx=${shadowX.toStringAsFixed(1)}'
            ':shadowy=${shadowY.toStringAsFixed(1)}'
            ':shadowcolor=$shadowColor'
        : '';
    final box = "box=1:boxcolor=black@0.55:boxborderw=12";
    // alpha= on drawtext; x/y expressions
    return "drawtext=text='$text':fontsize=$fontSize:fontcolor=$fontcolor:"
        "$box:"
        "x='$xExpr':y='$yExpr':alpha='$alphaExpr'"
        "$fontPart$shadowPart:enable='between(t\\,$startSec\\,$endSec)'";
  }
}

/// Builds the multi-input audio mix filter graph (testable).
class ExportAudioMix {
  static String build({
    required List<ClipModel> clips,
    required double videoDurSec,
    bool includeOriginal = true,
  }) {
    if (clips.isEmpty) return '';
    final dur = videoDurSec.clamp(0.1, 3600.0).toStringAsFixed(3);
    final labels = <String>[];
    final parts = <String>[];

    if (includeOriginal) {
      parts.add(
        '[0:a]apad=whole_dur=$dur,atrim=0:$dur,asetpts=PTS-STARTPTS[oa]',
      );
      labels.add('[oa]');
    }

    for (var i = 0; i < clips.length; i++) {
      final a = clips[i];
      final aStart = (a.trimStartMs / 1000.0).toStringAsFixed(3);
      final aEnd = ((a.trimStartMs + a.durationMs) / 1000.0)
          .clamp(0.1, 3600.0)
          .toStringAsFixed(3);
      final vol = a.muted
          ? '0'
          : a.volume.clamp(0.0, 2.0).toStringAsFixed(2);
      final delayMs = a.timelineStartMs.clamp(0, 24 * 3600 * 1000);
      final inIdx = i + 1;
      final lab = 'a$i';
      final fadeParts = <String>['volume=$vol'];
      switch (a.audioEffectId) {
        case 'echo':
          fadeParts.add('aecho=0.8:0.88:60:0.4');
          break;
        case 'reverb':
          fadeParts.add('aecho=0.8:0.9:1000:0.3');
          break;
        case 'robot':
          fadeParts.add('asetrate=44100*0.85,aresample=44100,atempo=1.15');
          break;
      }
      if (a.fadeInMs > 0) {
        final fin = (a.fadeInMs / 1000.0).clamp(0.01, 30.0).toStringAsFixed(3);
        fadeParts.add('afade=t=in:st=0:d=$fin');
      }
      if (a.fadeOutMs > 0) {
        final fout =
            (a.fadeOutMs / 1000.0).clamp(0.01, 30.0).toStringAsFixed(3);
        final st = ((a.durationMs - a.fadeOutMs) / 1000.0)
            .clamp(0.0, 3600.0)
            .toStringAsFixed(3);
        fadeParts.add('afade=t=out:st=$st:d=$fout');
      }
      final chain = fadeParts.join(',');
      parts.add(
        '[$inIdx:a]atrim=start=$aStart:end=$aEnd,asetpts=PTS-STARTPTS,'
        'adelay=$delayMs|$delayMs,apad=whole_dur=$dur,'
        '$chain[$lab]',
      );
      labels.add('[$lab]');
    }

    final n = labels.length;
    if (n == 1) {
      parts.add('${labels.first}anull[aout]');
    } else {
      parts.add(
        '${labels.join('')}amix=inputs=$n:duration=longest:dropout_transition=0[aout]',
      );
    }
    return parts.join(';');
  }

  static String buildBgOnly({
    required List<ClipModel> clips,
    required double videoDurSec,
  }) =>
      build(clips: clips, videoDurSec: videoDurSec, includeOriginal: false);
}
