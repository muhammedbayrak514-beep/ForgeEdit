class ExportErrorMessages {
  static String humanize(String? raw) {
    if (raw == null || raw.trim().isEmpty) {
      return 'Export başarısız. Tekrar dene veya klipleri sadeleştir.';
    }
    final s = raw.toLowerCase();
    if (s.contains('xfade') || s.contains('merge') || s.contains('offset')) {
      return 'Geçiş birleştirilemedi. Geçişleri "Kesme" yapıp tekrar dene.';
    }
    if (s.contains('drawtext') || s.contains('font') || s.contains('text')) {
      return 'Metin katmanı uygulanamadı. Yazı stillerini sadeleştirip dene.';
    }
    if (s.contains('audio') ||
        s.contains('amix') ||
        s.contains('atempo') ||
        s.contains('afade') ||
        s.contains('no audio') ||
        s.contains('stream map')) {
      return 'Ses karışımı başarısız. Ses kliplerini kontrol et veya '
          '"Orijinal video sesini kapat"ı dene.';
    }
    if (s.contains('chromakey')) {
      return 'Yeşil ekran filtresi başarısız. Filtreyi kaldırıp dene.';
    }
    if (s.contains('no space') ||
        s.contains('enospc') ||
        s.contains('space left')) {
      return 'Depolama dolu. Yer açıp tekrar dene.';
    }
    if (s.contains('permission') ||
        s.contains('eacces') ||
        s.contains('eperm')) {
      return 'Dosya izni yok. Uygulama depolama iznini kontrol et.';
    }
    if (s.contains('cancel')) {
      return 'Export iptal edildi.';
    }
    if (s.contains('bulunamadı') || s.contains('no such file')) {
      return 'Medya dosyası eksik. Klibi silip yeniden içe aktar.';
    }
    if (s.contains('codec') || s.contains('decoder') || s.contains('encoder')) {
      return 'Video/ses kodeği desteklenmiyor. Dosyayı MP4/MP3 olarak yeniden ekle.';
    }
    if (s.contains('timeout') || s.contains('killed')) {
      return 'Export zaman aşımına uğradı. Daha kısa proje veya "Hızlı" kalite dene.';
    }
    if (s.contains('doğrulama') ||
        s.contains('proje boş') ||
        s.contains('dışa aktarılacak')) {
      return raw;
    }
    final short =
        raw.length > 140 ? raw.substring(0, 140) + '…' : raw;
    return 'Export hatası: ' + short;
  }

  static String fromValidation(List<String> messages) {
    if (messages.isEmpty) {
      return 'Proje dışa aktarılamaz. Klip ekleyip tekrar dene.';
    }
    return messages.map(humanize).join('\n');
  }
}
