
import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/domain/models/keyframe.dart';
import 'package:forge_edit/domain/models/clip_model.dart';
import 'package:forge_edit/domain/timeline_ops.dart';

void main() {
  test('keyframe opacity lerps', () {
    final keys = [
      const ClipKeyframe(offsetMs: 0, opacity: 0),
      const ClipKeyframe(offsetMs: 1000, opacity: 1),
    ];
    expect(KeyframeEval.opacityAt(keys, 0, 1.0), 0);
    expect(KeyframeEval.opacityAt(keys, 1000, 1.0), 1);
    expect(KeyframeEval.opacityAt(keys, 500, 1.0), closeTo(0.5, 0.01));
  });

  test('snap includes markers', () {
    final v = ClipModel(
      id: 'v',
      type: ClipType.video,
      filePath: '/t.mp4',
      displayName: 'v',
      sourceDurationMs: 5000,
      trimEndMs: 5000,
      timelineStartMs: 0,
    );
    final snapped = TimelineOps.snapMs(980, [v], markersMs: const [1000]);
    expect(snapped, 1000);
  });
}
