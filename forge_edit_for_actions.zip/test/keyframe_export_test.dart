
import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/domain/export/export_text_style.dart';
import 'package:forge_edit/domain/models/clip_model.dart';
import 'package:forge_edit/domain/models/keyframe.dart';

void main() {
  test('keyframe opacity produces alpha expression in drawtext', () {
    final clip = ClipModel(
      id: 't',
      type: ClipType.text,
      filePath: '',
      displayName: 't',
      sourceDurationMs: 2000,
      trimEndMs: 2000,
      timelineStartMs: 0,
      textContent: 'Hi',
      opacity: 1,
      keyframes: const [
        ClipKeyframe(offsetMs: 0, opacity: 0),
        ClipKeyframe(offsetMs: 1000, opacity: 1),
      ],
    );
    final s = ExportTextStyle.fromClip(clip, frameWidth: 1280, frameHeight: 720);
    final dt = s.toDrawtext();
    expect(dt.contains('alpha='), true);
    expect(dt.contains('if(lt(t'), true);
  });
}
