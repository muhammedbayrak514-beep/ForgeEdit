import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/domain/models/clip_model.dart';
import 'package:forge_edit/domain/models/effect_models.dart';

void main() {
  test('filter fields roundtrip and default for old json', () {
    final old = {
      'id': '1',
      'type': 'video',
      'filePath': '/v.mp4',
      'displayName': 'v',
      'sourceDurationMs': 1000,
      'trimStartMs': 0,
      'trimEndMs': 1000,
      'timelineStartMs': 0,
    };
    final c = ClipModel.fromJson(old);
    expect(c.filterId, 'none');
    expect(c.transitionId, 'none');

    final withFilter = c.copyWith(
      filterId: FilterId.sepia.name,
      filterIntensity: 0.7,
      transitionId: TransitionId.crossfade.name,
      transitionDurationMs: 800,
    );
    final again = ClipModel.fromJson(withFilter.toJson());
    expect(again.filterId, 'sepia');
    expect(again.filterIntensity, 0.7);
    expect(again.transitionId, 'crossfade');
    expect(again.transitionDurationMs, 800);
  });

  test('catalog has stable ids', () {
    expect(EffectCatalog.filters.any((f) => f.id == FilterId.grayscale), true);
    final wipe = EffectCatalog.transitions
        .where((t) => t.id == TransitionId.wipeLeft)
        .first;
    // wipeLeft is export-backed via FFmpeg xfade wipeleft
    expect(wipe.exportReady, true);
    expect(EffectCatalog.transitions.any((t) => t.id == TransitionId.crossfade), true);
  });
}
