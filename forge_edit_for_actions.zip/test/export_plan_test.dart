import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/domain/export/export_filter_map.dart';
import 'package:forge_edit/domain/export/export_plan.dart';
import 'package:forge_edit/domain/models/clip_model.dart';
import 'package:forge_edit/domain/models/project_model.dart';

void main() {
  test('filter map none empty', () {
    expect(ExportFilterMap.videoFilter('none', 1), '');
    expect(ExportFilterMap.videoFilter('grayscale', 0), '');
    expect(ExportFilterMap.videoFilter('grayscale', 1).contains('hue'), true);
    expect(ExportFilterMap.videoFilter('sepia', 1).contains('colorchannelmixer'), true);
  });

  test('empty project cannot export', () async {
    final p = ProjectModel.create();
    final plan = await ExportPlan.build(p);
    expect(plan.canExport, false);
    expect(plan.issues, isNotEmpty);
  });

  test('segment commands for video include trim and filter', () {
    final v = ClipModel.fromImportedMedia(
      filePath: '/tmp/v.mp4',
      displayName: 'v',
      type: ClipType.video,
      sourceDurationMs: 5000,
      timelineStartMs: 0,
    ).copyWith(trimStartMs: 1000, trimEndMs: 4000, filterId: 'sepia');
    final project = ProjectModel.create().copyWith(clips: [v]);
    final plan = ExportPlan(
      project: project,
      settings: const ExportSettings(width: 1280, height: 720),
      videoTrack: [v],
      audioTrack: [],
      textTrack: [],
      issues: [],
    );
    final paths = <String>[];
    final cmds = plan.buildSegmentCommands(
      workDir: '/work',
      segmentPathsOut: paths,
    );
    expect(cmds.length, 1);
    expect(cmds.first.contains('-ss'), true);
    expect(cmds.first.contains('-t'), true);
    expect(cmds.first.contains('colorchannelmixer'), true);
    expect(paths.single, '/work/seg_0.mp4');
  });

  test('image segment uses loop and duration', () {
    final img = ClipModel.fromImportedMedia(
      filePath: '/tmp/i.jpg',
      displayName: 'i',
      type: ClipType.image,
      sourceDurationMs: 3000,
      timelineStartMs: 0,
    );
    final plan = ExportPlan(
      project: ProjectModel.create().copyWith(clips: [img]),
      settings: const ExportSettings(),
      videoTrack: [img],
      audioTrack: [],
      textTrack: [],
      issues: [],
    );
    final paths = <String>[];
    final cmds = plan.buildSegmentCommands(workDir: '/w', segmentPathsOut: paths);
    expect(cmds.first.contains('-loop 1'), true);
    expect(cmds.first.contains('-t '), true);
  });

  test('concat list format', () {
    final plan = ExportPlan(
      project: ProjectModel.create(),
      settings: const ExportSettings(),
      videoTrack: [],
      audioTrack: [],
      textTrack: [],
      issues: [],
    );
    final list = plan.buildConcatListFile(['/a.mp4', '/b.mp4']);
    expect(list.contains("file '/a.mp4'"), true);
    expect(list.contains("file '/b.mp4'"), true);
  });

  test('drawtext escapes and timing', () {
    final t = ClipModel.text(
      content: "Merhaba: 'test'",
      durationMs: 2000,
      timelineStartMs: 500,
    );
    final plan = ExportPlan(
      project: ProjectModel.create().copyWith(clips: [t]),
      settings: const ExportSettings(width: 1280, height: 720),
      videoTrack: [],
      audioTrack: [],
      textTrack: [t],
      issues: [],
    );
    final f = plan.buildDrawtextFilter();
    expect(f, isNotNull);
    expect(f!.contains('between(t'), true);
    expect(f.contains('0.500'), true);
    expect(f.contains('2.500'), true);
  });

  test('missing media fails hard validation', () async {
    final v = ClipModel.fromImportedMedia(
      filePath: '/nonexistent/path/video_xyz.mp4',
      displayName: 'missing',
      type: ClipType.video,
      sourceDurationMs: 1000,
      timelineStartMs: 0,
    );
    final plan = await ExportPlan.build(
      ProjectModel.create().copyWith(clips: [v]),
    );
    expect(plan.canExport, false);
    expect(plan.issues.any((i) => i.message.contains('bulunamadı')), true);
  });

  test('timelineDurationMs uses max end not sum', () {
    final a = ClipModel.fromImportedMedia(
      filePath: '/a.mp4',
      displayName: 'a',
      type: ClipType.video,
      sourceDurationMs: 2000,
      timelineStartMs: 0,
    );
    final b = ClipModel.fromImportedMedia(
      filePath: '/b.mp4',
      displayName: 'b',
      type: ClipType.video,
      sourceDurationMs: 2000,
      timelineStartMs: 5000,
    );
    final plan = ExportPlan(
      project: ProjectModel.create().copyWith(clips: [a, b]),
      settings: const ExportSettings(),
      videoTrack: [a, b],
      audioTrack: [],
      textTrack: [],
      issues: [],
    );
    expect(plan.timelineDurationMs, 7000);
  });


  test('speed adds setpts and atempo', () {
    final v = ClipModel(
      id: 's',
      type: ClipType.video,
      filePath: '/tmp/s.mp4',
      displayName: 's',
      sourceDurationMs: 4000,
      trimStartMs: 0,
      trimEndMs: 4000,
      timelineStartMs: 0,
      speed: 2.0,
    );
    final plan = ExportPlan(
      project: ProjectModel.create().copyWith(clips: [v]),
      settings: const ExportSettings(),
      videoTrack: [v],
      audioTrack: [],
      textTrack: [],
      issues: [],
    );
    final paths = <String>[];
    final cmds = plan.buildSegmentCommands(workDir: '/w', segmentPathsOut: paths);
    expect(cmds.first.contains('setpts=PTS/'), true);
    expect(cmds.first.contains('atempo='), true);
    // output -t should reflect half duration (~2s)
    expect(cmds.first.contains('-t 2.000'), true);
  });

  test('rotation adds rotate filter', () {
    final v = ClipModel(
      id: 'r',
      type: ClipType.video,
      filePath: '/tmp/r.mp4',
      displayName: 'r',
      sourceDurationMs: 1000,
      trimEndMs: 1000,
      timelineStartMs: 0,
      rotationDegrees: 90,
    );
    final plan = ExportPlan(
      project: ProjectModel.create().copyWith(clips: [v]),
      settings: const ExportSettings(),
      videoTrack: [v],
      audioTrack: [],
      textTrack: [],
      issues: [],
    );
    final paths = <String>[];
    final cmds = plan.buildSegmentCommands(workDir: '/w', segmentPathsOut: paths);
    expect(cmds.first.contains('rotate='), true);
  });

  test('xfade helpers', () {
    expect(ExportPlan.isXfadeTransition('crossfade'), true);
    expect(ExportPlan.isXfadeTransition('fadeBlack'), true);
    expect(ExportPlan.isXfadeTransition('none'), false);
    expect(ExportPlan.xfadeName('fadeBlack'), 'fadeblack');
    expect(ExportPlan.xfadeName('crossfade'), 'fade');
  });

  test('opacity adds colorchannelmixer aa', () {
    final v = ClipModel(
      id: 'o',
      type: ClipType.video,
      filePath: '/tmp/o.mp4',
      displayName: 'o',
      sourceDurationMs: 1000,
      trimEndMs: 1000,
      timelineStartMs: 0,
      opacity: 0.5,
    );
    final plan = ExportPlan(
      project: ProjectModel.create().copyWith(clips: [v]),
      settings: const ExportSettings(),
      videoTrack: [v],
      audioTrack: [],
      textTrack: [],
      issues: [],
    );
    final paths = <String>[];
    final cmds = plan.buildSegmentCommands(workDir: '/w', segmentPathsOut: paths);
    expect(cmds.first.contains('colorchannelmixer=aa=0.500'), true);
  });

  test('wipeLeft is xfade wipeleft', () {
    expect(ExportPlan.isXfadeTransition('wipeLeft'), true);
    expect(ExportPlan.xfadeName('wipeLeft'), 'wipeleft');
    expect(ExportPlan.supportedTransitionExport.contains('wipeLeft'), true);
  });
}
