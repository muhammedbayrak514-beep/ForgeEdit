
import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/domain/export/export_plan.dart';
import 'package:forge_edit/domain/export/export_text_style.dart';
import 'package:forge_edit/domain/export/export_filter_map.dart';
import 'package:forge_edit/domain/export/export_error_messages.dart';
import 'package:forge_edit/domain/models/clip_model.dart';
import 'package:forge_edit/domain/models/project_model.dart';

void main() {
  test('opacity segment filter includes colorchannelmixer aa', () {
    final v = ClipModel(
      id: 'o',
      type: ClipType.video,
      filePath: '/tmp/o.mp4',
      displayName: 'o',
      sourceDurationMs: 1000,
      trimEndMs: 1000,
      timelineStartMs: 0,
      opacity: 0.5,
    );
    final plan = ExportPlan(
      project: ProjectModel.create().copyWith(clips: [v]),
      settings: const ExportSettings(),
      videoTrack: [v],
      audioTrack: [],
      textTrack: [],
      issues: [],
    );
    final paths = <String>[];
    final cmds = plan.buildSegmentCommands(workDir: '/w', segmentPathsOut: paths);
    expect(cmds.first.contains('colorchannelmixer=aa=0.500'), true);
  });

  test('wipeLeft and crossfade are xfade-capable', () {
    expect(ExportPlan.isXfadeTransition('wipeLeft'), true);
    expect(ExportPlan.isXfadeTransition('crossfade'), true);
    expect(ExportPlan.xfadeName('wipeLeft'), 'wipeleft');
  });

  test('drawtext includes caption box', () {
    final t = ClipModel.text(
      content: 'Merhaba',
      durationMs: 2000,
      timelineStartMs: 0,
    );
    final style = ExportTextStyle.fromClip(t, frameWidth: 1280, frameHeight: 720);
    final dt = style.toDrawtext(fontFile: '/system/fonts/Roboto-Regular.ttf');
    expect(dt.contains('box=1'), true);
    expect(dt.contains('drawtext='), true);
  });

  test('muteOriginalAudio flag on settings', () {
    const s = ExportSettings(muteOriginalAudio: true);
    expect(s.muteOriginalAudio, true);
    expect(s.copyWith(muteOriginalAudio: false).muteOriginalAudio, false);
  });

  test('audio mix without original when muted', () {
    final a = ClipModel(
      id: 'a',
      type: ClipType.audio,
      filePath: '/tmp/a.mp3',
      displayName: 'a',
      sourceDurationMs: 3000,
      trimEndMs: 3000,
      timelineStartMs: 0,
      volume: 1,
    );
    final withOrig = ExportAudioMix.build(
      clips: [a],
      videoDurSec: 3,
      includeOriginal: true,
    );
    final noOrig = ExportAudioMix.build(
      clips: [a],
      videoDurSec: 3,
      includeOriginal: false,
    );
    expect(withOrig.contains('[0:a]'), true);
    expect(noOrig.contains('[0:a]'), false);
  });

  test('filter map grayscale produces hue', () {
    expect(ExportFilterMap.videoFilter('grayscale', 1).contains('hue'), true);
  });

  test('error humanize covers common ffmpeg failures', () {
    expect(
      ExportErrorMessages.humanize('Error: xfade failed offset'),
      contains('Geçiş'),
    );
    expect(
      ExportErrorMessages.humanize('amix: Error while filtering'),
      contains('Ses'),
    );
    expect(
      ExportErrorMessages.humanize('No space left on device'),
      contains('Depolama'),
    );
  });
}
