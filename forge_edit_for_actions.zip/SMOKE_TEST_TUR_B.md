# Tur B smoke

1. Timeline bayrak: işaret ekle / sil; scrub işarete yapışır mı?
2. Metin seç → playhead hareket → Keyframe ekle (2 nokta) → play: opacity/konum animasyon
3. Ses klibi waveform daha dolgun görünüyor mu?
4. Export → "Sadece işaret aralığı" → 2 marker ile In/Out kesim
