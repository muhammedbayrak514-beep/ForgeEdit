# Tur C smoke

1. Şablon seç → slot sihirbazı adımları → medya doldur → editör
2. Export → TikTok/Reels, Instagram, YouTube preset
3. Altyazı → Stil paketi → Alt bant / Reels kalın
4. Dar ekran (telefon): timeline yüksekliği küçülür, editör kullanılabilir
