# Tur A — Güven (smoke)

1. Proje aç → düzenle → üstte kayıt ikonu (cloud_done) görünür mü?
2. Ses ekle → Play → müzik duyuluyor mu? Scrub ederken ses zamanı kayıyor mu?
3. Export → bilerek bozuk yol / boş proje → Türkçe anlamlı hata
4. Export normal → geçiş + yazı + müzik + opacity bir arada
5. Uygulamayı zorla kapat → yeniden aç → proje duruyor mu? (project.json.bak)
6. "Orijinal video sesini kapat" açık export → sadece müzik

Unit: `flutter test test/export_parity_tur_a_test.dart`
